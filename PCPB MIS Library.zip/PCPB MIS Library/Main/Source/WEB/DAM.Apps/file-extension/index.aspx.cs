﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using log4net;
using DAM.Apps.CommonClasses;
using System.Configuration;
using System.IO;
using System.Web.Configuration;

namespace DAM.Apps.file_extension
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));
        private Int32 UserId;
        String UniqueFileName = String.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "System Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {
                PopulateFileExtensionMasterList();
            }
        }
        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }

        protected void PopulateFileExtensionMasterList()
        {
            DAMServices.ServiceContractClient obje;
            try
            {
                obje = new DAMServices.ServiceContractClient();
                gdvFileExtension.DataSource = obje.GetAllFileExtension();
                gdvFileExtension.DataBind();
                gdvFileExtension.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
            }
        }
        

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                gdvFileExtension.DataSource = objDAM.GetFileExtensionMasterSearch(Server.HtmlEncode(txtSearchFileExtension.Value.Trim()));
                gdvFileExtension.DataBind();
                gdvFileExtension.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            txtFileExtension.Value = "";
            txtDescription.Value = "";
            hdnSelectFileExtensionId.Value = "";
            imgLogo.ImageUrl = "../img/file-icons/noImageAvailable.jpg";
            gdvFileExtension.HeaderRow.TableSection = TableRowSection.TableHeader;
            popup.Show();
        }

        protected void gdvFileExtension_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnActive = (HiddenField)e.Row.FindControl("hdnActive");
                    Image imgActive = (Image)e.Row.FindControl("imgActive");
                    Image imgDeactive = (Image)e.Row.FindControl("imgDeactive");
                    imgActive.Visible = (hdnActive.Value == "True") ? true : false;
                    imgDeactive.Visible = (hdnActive.Value == "True") ? false : true;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {

            }
        }

        protected void gdvFileExtension_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.FileExtensionInfo mData;
            try
            {
                if (UserId != 0)
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    mData = new DAMServices.FileExtensionInfo();

                    if (e.CommandName == "_ActiveDeactive")
                    {
                        String[] CommandArgs = e.CommandArgument.ToString().Split(new char[] { '|' });
                        Int32 RowAFileExtensionId = Convert.ToInt32(CommandArgs[0]);
                        Boolean Status = Convert.ToBoolean(CommandArgs[1]);

                        mData.FileExtensionId = RowAFileExtensionId;
                        mData.ModifiedBy = UserId;
                        mData.IPAddress = GetIPAddress();
                        mData.IsActive = (Status) ? false : true;
                        Int32 r = objDAM.ActivateDeactivateFileExtensionMaster(mData);
                        if (r > 0)
                        {
                            PopulateFileExtensionMasterList();
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }

                    }
                    if (e.CommandName == "_Edit")
                    {
                        Int32 RowFileExtensionId = Convert.ToInt32(e.CommandArgument);
                        gdvFileExtension.HeaderRow.TableSection = TableRowSection.TableHeader;
                        var mList = objDAM.GetFileExtensionMasterById(RowFileExtensionId);
                        hdnSelectFileExtensionId.Value = mList[0].FileExtensionId.ToString();
                        txtFileExtension.Value = Server.HtmlDecode(mList[0].FileExtension);
                        txtDescription.Value = Server.HtmlDecode(mList[0].Description);
                        if (mList[0].PreviewImage != "")
                            imgLogo.ImageUrl = "../img/file-icons/" + mList[0].PreviewImage;
                        else
                            imgLogo.ImageUrl = "../img/file-icons/noImageAvailable.jpg";
                        popup.Show();
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
                mData = null;
            }
        }

        private static readonly string[] _validExtensions = { ".PNG", ".JPG", ".JPEG" }; //  etc

        public static bool IsValidExtension(string ext)
        {
            return _validExtensions.Contains(ext);
        }

        protected void FileUploadProcess()
        {
            try
            {
                divConfirm.Attributes.Add("style", "display:none");
                divError.Attributes.Add("style", "display:none");
                confirmMsg.InnerHtml = "";
                errorMsg.InnerHtml = "";

                string FileName = logoUpload.FileName.ToString();
                int flen = logoUpload.PostedFile.ContentLength;
                string path = ConfigurationManager.AppSettings["FilePreview"].ToString();
                String fext = CheckMimeType.getMimeFromFile(logoUpload.PostedFile);
                String ext = System.IO.Path.GetExtension(logoUpload.PostedFile.FileName);

                if (!CheckMimeType.IsValidExtension(ext.ToUpper()))
                {
                    divError.Attributes.Add("style", "display:block");
                    errorMsg.InnerHtml = Constant.FILE_INVALID;
                    return;
                }
                if (!CheckMimeType.CheckExe(fext))
                {
                    divError.Attributes.Add("style", "display:block");
                    errorMsg.InnerHtml = Constant.FILE_CORRUPT;
                    return;
                }
                if (flen <= Convert.ToInt64(ConfigurationManager.AppSettings["MaxFileSize"]))
                {
                    String path1 = path;
                    String path2 = String.Empty;
                    UniqueFileName = Guid.NewGuid().ToString() + ext;
                    path2 = path1 + UniqueFileName;
                    if (path2.Length < 260)
                    {
                        try
                        {
                            logoUpload.SaveAs(path2);
                            divError.Attributes.Add("style", "display:none");
                            divConfirm.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = Constant.FILE_UPLOAD_SUCCESS;
                        }
                        catch (Exception ex)
                        {
                            log.Error(ex.Message);
                        }
                    }
                    else
                    {
                        divConfirm.Attributes.Add("style", "display:none");
                        divError.Attributes.Add("style", "display:block");
                        errorMsg.InnerHtml = Constant.FILE_UPLOAD_FAILURE;
                        return;
                    }
                }
                else
                {
                    divConfirm.Attributes.Add("style", "display:none");
                    divError.Attributes.Add("style", "display:block");
                    errorMsg.InnerHtml = Constant.FILE_SIZE_FAILURE;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            { }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient obje;
            DAMServices.FileExtensionInfo dList;
            try
            {
                if (txtFileExtension.Value != "")
                {
                    obje = new DAMServices.ServiceContractClient();
                    dList = new DAMServices.FileExtensionInfo();
                    if (logoUpload.HasFile)
                        FileUploadProcess();

                    if (hdnSelectFileExtensionId.Value != "")
                        dList.FileExtensionId = Convert.ToInt32(hdnSelectFileExtensionId.Value);
                    dList.FileExtension = Server.HtmlEncode(txtFileExtension.Value);
                    dList.Description = Server.HtmlEncode(txtDescription.Value);
                    dList.CreatedBy = UserId;
                    dList.PreviewImage = UniqueFileName;
                    dList.IPAddress = GetIPAddress();
                    if (dList.FileExtensionId == 0)
                    {
                        Int32 Returnval = obje.InsertFileExtensionMaster(dList);
                        if (Returnval > 0)
                        {
                            PopulateFileExtensionMasterList();
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.DUPLICATE;
                        }
                    }
                    else
                    {
                        Int32 Returnval = obje.UpdateFileExtensionMaster(dList);
                        if (Returnval > 0)
                        {
                            PopulateFileExtensionMasterList();
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }
                    }
                }
                else
                {
                    popup.Show();
                    lblPopupMsg.InnerText = "Enter FileExtension Name.";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
                dList = null;
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (gdvFileExtension.Rows.Count > 0)
                {
                    Response.ClearContent();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "FileExtension.xls"));
                    Response.ContentType = "application/ms-excel";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter htw = new HtmlTextWriter(sw);
                    gdvFileExtension.AllowPaging = false;
                    //Change the Header Row back to white color
                    gdvFileExtension.HeaderRow.Style.Add("background-color", "#FFFFFF");
                    gdvFileExtension.HeaderRow.Style.Add("color", "#fff");
                    for (int i = 0; i < gdvFileExtension.HeaderRow.Cells.Count; i++)
                        gdvFileExtension.HeaderRow.Cells[i].Style.Add("background-color", "#1B1BBA");
                    for (int i = 0; i < gdvFileExtension.Columns.Count; i++)
                    {
                        if (gdvFileExtension.Columns[i].HeaderText == "Active" || gdvFileExtension.Columns[i].HeaderText == "Edit")
                            gdvFileExtension.Columns[i].Visible = false;
                        if (gdvFileExtension.Columns[i].HeaderText == "IsActive")
                            gdvFileExtension.Columns[i].Visible = true;
                    }
                    gdvFileExtension.RenderControl(htw);
                    Response.Write(sw.ToString());
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
    }
}