﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using log4net;
using System.Text;
using DAM.Apps.CommonClasses;
using QueryStringEncryption;
using System.Web.Configuration;

namespace DAM.Apps.team_with_privilege
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));
        private Int32 UserId;
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "System Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {
                PopulateLibraryListDropDown();
                PopulateTeamMasterList();
                PopulatePrivilegeListNotInTeamPrivilege();
            }
        }
        protected void PopulateLibraryListDropDown()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                ddlLibraryList.DataSource = objDAM.GetAllActiveLibraryMaster();
                ddlLibraryList.DataValueField = "LibId";
                ddlLibraryList.DataTextField = "LibName";
                ddlLibraryList.DataBind();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void PopulateTeamMasterList()
        {
            DAMServices.ServiceContractClient obje;
            try
            {
                obje = new DAMServices.ServiceContractClient();
                var list = obje.GetAllTeamMaster();
                gdvTeamMaster.DataSource = list.Where(x => x.TeamName != "System Administrator" && x.TeamName != "Application Administrator").ToList();
                gdvTeamMaster.DataBind();
                if(gdvTeamMaster.Rows.Count>0)
                    gdvTeamMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
                if(gdvPrivilegeMaster.Rows.Count>0)
                    gdvPrivilegeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
            }
        }
        protected void rdoSelect_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow row = ((GridViewRow)((CheckBox)sender).NamingContainer);
            HiddenField teamId = (HiddenField)row.FindControl("hdnTeam");
            hdnSelectedTeam.Value = teamId.Value;
            if (gdvTeamMaster.Rows.Count > 0)
                gdvTeamMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            if (gdvPrivilegeMaster.Rows.Count > 0)
                gdvPrivilegeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
        }
        protected void chkCSelf_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow Row = ((GridViewRow)((Control)sender).Parent.Parent);
            CheckBox chkCSelf = (CheckBox)Row.FindControl("chkCSelf");
            CheckBox chkCOther = (CheckBox)Row.FindControl("chkCOther");
            if (!chkCSelf.Checked)
                chkCOther.Checked = false;
            if (gdvTeamMaster.Rows.Count > 0)
                gdvTeamMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            if (gdvPrivilegeMaster.Rows.Count > 0)
                gdvPrivilegeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
        }

        protected void chkCOther_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow Row = ((GridViewRow)((Control)sender).Parent.Parent);
            CheckBox chkCSelf = (CheckBox)Row.FindControl("chkCSelf");
            CheckBox chkCOther = (CheckBox)Row.FindControl("chkCOther");
            if (chkCOther.Checked)
                chkCSelf.Checked = true;
            if (gdvTeamMaster.Rows.Count > 0)
                gdvTeamMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            if (gdvPrivilegeMaster.Rows.Count > 0)
                gdvPrivilegeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
        }

        protected void chkGSelf_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow Row = ((GridViewRow)((Control)sender).Parent.Parent);
            CheckBox chkGSelf = (CheckBox)Row.FindControl("chkGSelf");
            CheckBox chkGOther = (CheckBox)Row.FindControl("chkGOther");
            if (!chkGSelf.Checked)
                chkGOther.Checked = false;
            if (gdvTeamMaster.Rows.Count > 0)
                gdvTeamMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            if (gdvPrivilegeMaster.Rows.Count > 0)
                gdvPrivilegeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
        }

        protected void chkGOther_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow Row = ((GridViewRow)((Control)sender).Parent.Parent);
            CheckBox chkGSelf = (CheckBox)Row.FindControl("chkGSelf");
            CheckBox chkGOther = (CheckBox)Row.FindControl("chkGOther");
            if (chkGOther.Checked)
                chkGSelf.Checked = true;
            if (gdvTeamMaster.Rows.Count > 0)
                gdvTeamMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            if (gdvPrivilegeMaster.Rows.Count > 0)
                gdvPrivilegeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
        }
        protected void PopulatePrivilegeListNotInTeamPrivilege()
        {
                DAMServices.ServiceContractClient objDAM;
                try
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    gdvPrivilegeMaster.DataSource = objDAM.GetAllPrivilegeMasterRowsNotInTeamInPrivilegeServ(0,0);
                    gdvPrivilegeMaster.DataBind();
                    if (gdvTeamMaster.Rows.Count > 0)
                        gdvTeamMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
                    if (gdvPrivilegeMaster.Rows.Count > 0)
                        gdvPrivilegeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
            
        }
        protected void gdvPrivilegeMaster_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    CheckBox chkGSelf = (CheckBox)e.Row.FindControl("chkGSelf");
                    CheckBox chkGOther = (CheckBox)e.Row.FindControl("chkGOther");
                    CheckBox chkCOther = (CheckBox)e.Row.FindControl("chkCOther");
                    Label lblPrivilegeName = (Label)e.Row.FindControl("lblPrivilegeName");
                    chkGSelf.Checked = (lblPrivilegeName.Text != "Search") ? false : true;
                    chkGSelf.Enabled = (lblPrivilegeName.Text == "Search") ? false : true;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {

            }
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("../team-in-privilege/index.aspx");
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            if (gdvPrivilegeMaster.Rows.Count > 0)
            {
                try
                {
                    CommonClass objCommon = new CommonClass();
                    String strtmInPrvDetails = String.Empty;
                    objDAM = new DAMServices.ServiceContractClient();
                    var contentList = objDAM.GetContentTypeByLibId(Convert.ToInt32(ddlLibraryList.SelectedValue));
                    if (contentList.Count() > 0)
                    {
                        for (int x = 0; x < contentList.Count(); x++)
                        {
                            for (int i = 0; i < gdvPrivilegeMaster.Rows.Count; i++)
                            {
                                Int32 Permission = 0;
                                String BinaryCode = String.Empty;
                                CheckBox chkCSelf = (CheckBox)gdvPrivilegeMaster.Rows[i].FindControl("chkCSelf");
                                CheckBox chkCOther = (CheckBox)gdvPrivilegeMaster.Rows[i].FindControl("chkCOther");
                                CheckBox chkGSelf = (CheckBox)gdvPrivilegeMaster.Rows[i].FindControl("chkGSelf");
                                CheckBox chkGOther = (CheckBox)gdvPrivilegeMaster.Rows[i].FindControl("chkGOther");
                                Label lblPrivilegeId = (Label)gdvPrivilegeMaster.Rows[i].FindControl("lblPrivilegeId");
                                BinaryCode = (chkCSelf.Checked) ? "1" : "0";
                                BinaryCode += (chkCOther.Checked) ? "1" : "0";
                                BinaryCode += (chkGSelf.Checked) ? "1" : "0";
                                BinaryCode += (chkGOther.Checked) ? "1" : "0";
                                Permission = objCommon.BinaryToInteger(BinaryCode);

                                strtmInPrvDetails += hdnSelectedTeam.Value + "," + lblPrivilegeId.Text + "," + Permission + "," + contentList[x].ContentTypeId + "," + ddlLibraryList.SelectedValue + "," + chkIsBrandCategoryEdit.Checked + "," + UserId + "," + GetIPAddress() + "|";
                            }
                        }
                    }
                    if (strtmInPrvDetails != "")
                    {
                        strtmInPrvDetails = strtmInPrvDetails.Remove(strtmInPrvDetails.Length - 1);
                        if (strtmInPrvDetails != "")
                        {
                            objDAM.InsertTeamInPrivilege(strtmInPrvDetails);
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            confirmMsg.InnerHtml = "";
                            divError.Attributes.Add("style", "display:block");
                            divConfirm.Attributes.Add("style", "display:none");
                            errorMsg.InnerHtml = Constant.ADD_ERROR;
                        }
                        if (gdvTeamMaster.Rows.Count > 0)
                            gdvTeamMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
                        if (gdvPrivilegeMaster.Rows.Count > 0)
                            gdvPrivilegeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
                    }
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
            }
            else
            {
                confirmMsg.InnerHtml = "";
                divError.Attributes.Add("style", "display:block");
                divConfirm.Attributes.Add("style", "display:none");
                errorMsg.InnerHtml = Constant.DATA_NOT_FOUND;
            }
        }
        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }
    }
}