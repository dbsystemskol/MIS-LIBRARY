﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using log4net;
using System.Configuration;
using DAM.Apps.CommonClasses;
using System.IO;
using System.Web.Configuration;

namespace DAM.Apps.lookup_master
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));
        private Int32 UserId;
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "System Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {                
                PopulateLookupList();
                PopulateAttributeFieldListDropDown();
                PopulateLibraryListDropDown();
            }
        }
        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }

        protected void PopulateLookupList()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                gdvLookupMaster.DataSource = objDAM.GetAllActiveAttributeMasterLookupList();
                gdvLookupMaster.DataBind();
                gdvLookupMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void PopulateAttributeFieldListDropDown()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var mList = objDAM.GetAllActiveListTypeAttributeMaster();
                ddlFieldCaption.DataSource = mList;
                ddlFieldCaption.DataValueField = "FieldId";
                ddlFieldCaption.DataTextField = "FieldCaption";
                ddlFieldCaption.DataBind();
                lblValueCaption.InnerText = (mList.Count() > 0) ? ddlFieldCaption.SelectedItem + " Value:" : "Value:";
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void PopulateLibraryListDropDown()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                ddlLibrary.DataSource = objDAM.GetAllActiveLibraryMaster();
                ddlLibrary.DataValueField = "LibId";
                ddlLibrary.DataTextField = "LibName";
                ddlLibrary.DataBind();
                ddlLibrary.Items.Insert(0, new ListItem("All Library", "0"));
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void gdvLookupMaster_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnActive = (HiddenField)e.Row.FindControl("hdnActive");
                    LinkButton btnActive = (LinkButton)e.Row.FindControl("btnActive");
                    LinkButton btnDeactive = (LinkButton)e.Row.FindControl("btnDeactive");
                    Image imgActive = (Image)e.Row.FindControl("imgActive");
                    Image imgDeactive = (Image)e.Row.FindControl("imgDeactive");
                    if (hdnActive.Value == "True")
                    {
                        btnActive.Visible = true;
                        btnDeactive.Visible = false;
                        imgActive.Visible = true;
                        imgDeactive.Visible = false;
                    }
                    else
                    {
                        btnActive.Visible = false;
                        btnDeactive.Visible = true;
                        imgActive.Visible = false;
                        imgDeactive.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {

            }
        }

        protected void gdvLookupMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.LookupMasterInfo mData;
            try
            {
                if (UserId != 0)
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    mData = new DAMServices.LookupMasterInfo();

                    if (e.CommandName == "_Active")
                    {
                        Int32 RowALookupId = Convert.ToInt32(e.CommandArgument);
                        mData.LookupId = RowALookupId;
                        mData.ModifiedBy = UserId;
                        mData.IPAddress = GetIPAddress();
                        mData.IsActive = false;
                        Int32 r = objDAM.ActivateDeactivateLookupMaster(mData);
                        if (r > 0)
                        {
                            PopulateLookupList();
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }

                    }
                    if (e.CommandName == "_Deactive")
                    {
                        Int32 RowALookupId = Convert.ToInt32(e.CommandArgument);
                        mData.LookupId = RowALookupId;
                        mData.ModifiedBy = UserId;
                        mData.IPAddress = GetIPAddress();
                        mData.IsActive = true;
                        Int32 r = objDAM.ActivateDeactivateLookupMaster(mData);
                        if (r > 0)
                        {
                            PopulateLookupList();
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }

                    }
                    if (e.CommandName == "_Edit")
                    {
                        Int32 RowLookupId = Convert.ToInt32(e.CommandArgument);
                        gdvLookupMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
                        var mList = objDAM.GetLookupMasterById(RowLookupId);
                        hdnSelectLookupId.Value = mList[0].LookupId.ToString();
                        ddlFieldCaption.SelectedValue = mList[0].FieldId.ToString();
                        txtFieldCode.Value = Server.HtmlDecode(mList[0].FieldCode);
                        txtFieldValue.Value = Server.HtmlDecode(mList[0].FieldValue);
                        ddlLibrary.SelectedValue = mList[0].LibId.ToString();
                        popup.Show();
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
                mData = null;
            }
        }

        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            try
            {
                txtFieldCode.Value = "";
                txtFieldValue.Value = "";
                hdnSelectLookupId.Value = "";
                popup.Show();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient obje;
            DAMServices.LookupMasterInfo dList;
            try
            {
                obje = new DAMServices.ServiceContractClient();
                dList = new DAMServices.LookupMasterInfo();
                dList.LookupId = (hdnSelectLookupId.Value!="") ? Convert.ToInt32(hdnSelectLookupId.Value) : 0;
                dList.FieldId = Convert.ToInt32(ddlFieldCaption.SelectedValue);
                dList.FieldCode = Server.HtmlEncode(txtFieldCode.Value);
                dList.FieldValue = Server.HtmlEncode(txtFieldValue.Value);
                dList.LibId = Convert.ToInt32(ddlLibrary.SelectedValue);
                dList.CreatedBy = UserId;
                dList.IPAddress = GetIPAddress();
                if (dList.LookupId == 0)
                {
                    Int32 Returnval = obje.InsertLookupMaster(dList);
                    if (Returnval > 0)
                    {
                        PopulateLookupList();
                        divConfirm.Attributes.Add("style", "display:block");
                        divError.Attributes.Add("style", "display:none");
                        confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                        errorMsg.InnerHtml = "";
                    }
                    else
                    {
                        divConfirm.Attributes.Add("style", "display:none");
                        divError.Attributes.Add("style", "display:block");
                        confirmMsg.InnerHtml = "";
                        errorMsg.InnerHtml = Constant.DUPLICATE;
                    }
                }
                else
                {
                    Int32 Returnval = obje.UpdateLookupMaster(dList);
                    if (Returnval > 0)
                    {
                        PopulateLookupList();
                        divConfirm.Attributes.Add("style", "display:block");
                        divError.Attributes.Add("style", "display:none");
                        confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                        errorMsg.InnerHtml = "";
                    }
                    else
                    {
                        divConfirm.Attributes.Add("style", "display:none");
                        divError.Attributes.Add("style", "display:block");
                        confirmMsg.InnerHtml = "";
                        errorMsg.InnerHtml = Constant.DUPLICATE;
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
                dList = null;
            }
        }

        protected void ddlFieldCaption_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblValueCaption.InnerText = (Convert.ToInt32(ddlFieldCaption.SelectedValue) > 0) ? ddlFieldCaption.SelectedItem + " Value:" : "Value:";
            popup.Show();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                gdvLookupMaster.DataSource = objDAM.GetAttributeMasterLookupListSearch(Server.HtmlEncode(txtSearchTeam.Value));
                gdvLookupMaster.DataBind();
                gdvLookupMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (gdvLookupMaster.Rows.Count > 0)
                {
                    Response.ClearContent();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "Lookup.xls"));
                    Response.ContentType = "application/ms-excel";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter htw = new HtmlTextWriter(sw);
                    gdvLookupMaster.AllowPaging = false;
                    //Change the Header Row back to white color
                    gdvLookupMaster.HeaderRow.Style.Add("background-color", "#FFFFFF");
                    gdvLookupMaster.HeaderRow.Style.Add("color", "#fff");
                    for (int i = 0; i < gdvLookupMaster.HeaderRow.Cells.Count; i++)
                        gdvLookupMaster.HeaderRow.Cells[i].Style.Add("background-color", "#1B1BBA");
                    for (int i = 0; i < gdvLookupMaster.Columns.Count; i++)
                    {
                        if (gdvLookupMaster.Columns[i].HeaderText == "Active" || gdvLookupMaster.Columns[i].HeaderText == "Edit")
                            gdvLookupMaster.Columns[i].Visible = false;
                        if (gdvLookupMaster.Columns[i].HeaderText == "IsActive")
                            gdvLookupMaster.Columns[i].Visible = true;
                    }
                    gdvLookupMaster.RenderControl(htw);
                    Response.Write(sw.ToString());
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }

        protected void chkActiveAll_CheckedChanged(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.LookupMasterInfo mData;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                mData = new DAMServices.LookupMasterInfo();
                CheckBox chkActiveAll = (CheckBox)gdvLookupMaster.HeaderRow.FindControl("chkActiveAll");
                mData.ModifiedBy = UserId;
                mData.IPAddress = GetIPAddress();
                mData.IsActive = (chkActiveAll.Checked) ? true : false;
                Int32 r = objDAM.ActivateDeactivateLookupMasterAll(mData);
                if (r > 0)
                {
                    foreach (GridViewRow row in gdvLookupMaster.Rows)
                    {
                        Image imgActive = (Image)row.FindControl("imgActive");
                        Image imgDeactive = (Image)row.FindControl("imgDeactive");
                        LinkButton btnActive = (LinkButton)row.FindControl("btnActive");
                        LinkButton btnDeactive = (LinkButton)row.FindControl("btnDeactive");

                        imgActive.Visible = (chkActiveAll.Checked) ? true : false;
                        imgDeactive.Visible = (chkActiveAll.Checked) ? false : true;
                        btnActive.Visible = (chkActiveAll.Checked) ? true : false;
                        btnDeactive.Visible = (chkActiveAll.Checked) ? false : true;
                    }
                    confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                    errorMsg.InnerHtml = "";
                }
                else
                {
                    confirmMsg.InnerHtml = "";
                    errorMsg.InnerHtml = Constant.EDIT_ERROR;
                }
                gdvLookupMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
                mData = null;
            }
        }
    }
}