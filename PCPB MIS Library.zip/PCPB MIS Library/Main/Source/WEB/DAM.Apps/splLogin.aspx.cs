﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Security.Principal;
using System.Configuration;
using System.Text;
using log4net;
using log4net.Config;
using System.Globalization;
using System.Web.Configuration;

namespace DAM.Apps
{
    public partial class splLogin : System.Web.UI.Page
    {
        static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            if (HttpContext.Current.User.Identity.Name != "")
            {
                IPrincipal GenPrincipal;
                GenPrincipal = HttpContext.Current.User;
                String IdentityName = GenPrincipal.Identity.Name;
                Int32 _Pos = HttpContext.Current.User.Identity.Name.IndexOf("\\");
                String _UserName = HttpContext.Current.User.Identity.Name.Substring(_Pos + 1, HttpContext.Current.User.Identity.Name.Length - (_Pos + 1));
                DAMServices.ServiceContractClient objDAM = new DAMServices.ServiceContractClient();
                var mInfo = objDAM.GetUserMasterByUserName(_UserName);
                if (mInfo.Count() > 0)
                {
                    Session["FirstName"] = mInfo[0].FirstName;
                    Session["LastName"] = mInfo[0].LastName;
                    Session["UserName"] = _UserName;
                    Session["UserId"] = mInfo[0].UserId.ToString();
                    var mList = objDAM.GetTeamMasterByUserId(mInfo[0].UserId).Where(x => x.TeamName == "System Administrator").ToList();
                    if (mList.Count() > 0)
                    {
                    }
                    else
                    {
                        Response.Redirect("~/user-login.aspx");
                    }
                }
                else
                {
                    Response.Redirect("~/authorization-msg/index.htm", false);
                }
            }
            if (!IsPostBack)
            {
                BindActiveUser();
            }
        }

        private void BindActiveUser()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var mList = objDAM.GetAllActiveUserMaster();
                ddlUser.DataSource = mList;
                ddlUser.DataTextField = "UserName";
                ddlUser.DataValueField = "UserID";
                ddlUser.DataBind();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            //log.Info("login clicked");
            ErrorLabel.Text = "";
            DAMServices.ServiceContractClient objDAM = new DAMServices.ServiceContractClient();
            var mInfo = objDAM.GetUserMasterById(Convert.ToInt32(ddlUser.SelectedValue));

            Session["FirstName"] = mInfo[0].FirstName;
            Session["LastName"] = mInfo[0].LastName;
            Session["UserName"] = mInfo[0].UserName;
            Session["UserId"] = mInfo[0].UserId.ToString();
            //log.Info("Going to user login page");
            Response.Redirect("~/user-login.aspx", false);
        }
    }
}