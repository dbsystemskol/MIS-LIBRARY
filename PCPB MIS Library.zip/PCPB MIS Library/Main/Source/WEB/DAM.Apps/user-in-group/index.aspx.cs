﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using log4net;
using System.Configuration;
using DAM.Apps.CommonClasses;
using System.IO;
using System.Text;
using QueryStringEncryption;
using System.Web.Configuration;

namespace DAM.Apps.user_in_group
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));
        private Int32 UserId;
        private Int32 LibId;
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            ////HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "Application Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                UserId = Convert.ToInt32(Session["UserId"].ToString());
                LibId = Convert.ToInt32(Session["LibId"].ToString());
                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {
                BindMenu(LibId);
                PopulateActiveUserInGroupList();
            }
        }
        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }
        protected void PopulateActiveUserInGroupList()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var list = objDAM.GetAllUserInGroupSearch(Server.HtmlEncode(txtSearchTeam.Value));
                gdvUserInGroup.DataSource = list.ToList();
                gdvUserInGroup.DataBind();
                gdvUserInGroup.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void PopulateGroupListDropDown()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var list = objDAM.GetAllActiveGroupMaster();
                ddlGroup.DataSource = list.ToList();
                ddlGroup.DataValueField = "GroupId";
                ddlGroup.DataTextField = "GroupName";
                ddlGroup.DataBind();
                ddlGroup.Items.Insert(0, new ListItem("---- Select Group ----", "0"));
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        private void BindMenu(Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                StringBuilder sb = new StringBuilder();
                var list = objDAM.GetAllActiveAttributeMasterLookupList()
                                    .Where(x => x.LibId == 0 || x.LibId == LibId)
                                    .GroupBy(g => g.FieldId)
                                    .Select(g => new
                                    {
                                        FieldId = g.Key,
                                        FieldCaption = g.First().FieldCaption
                                    });
                sb.Append("<ul>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../sys-user-master/index.aspx'>Manage User</a></li>");
                sb.Append("<li><img src='../img/nav-icons/file-type.png' alt='' /><a href='../sys-user-in-team/index.aspx'>User with Team</a></li>");
                sb.Append("<li><img src='../img/nav-icons/team.png' alt='' /><a href='../department-master/index.aspx'>Manage Department</a></li>");
                sb.Append("<li><img src='../img/nav-icons/team.png' alt='' /><a href='../designation-master/index.aspx'>Manage Designation</a></li>");
                sb.Append("<li><img src='../img/nav-icons/team.png' alt='' /><a href='../location-master/index.aspx'>Manage Location</a></li>");
                int i = 0;
                foreach (var l in list)
                {
                    if (l.FieldCaption != "Confidential")
                    {
                        if (i == 0)
                            hdnFieldId.Value = l.FieldId.ToString();
                        sb.AppendFormat("<li><img src='../img/nav-icons/brand.png' alt='' /><a href='../sys-admin/index.aspx?{1}'>{0}</a></li>", l.FieldCaption, EncryptQueryString(String.Format("fid={0}^fname={1}", l.FieldId, l.FieldCaption)));
                        i++;
                    }
                }
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../group-master/index.aspx'>Group</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../user-in-group/index.aspx'>User with Group</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../document-log/index.aspx'>Document Activity Log</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../brand-category-mapping/index.aspx'>Brand Category Mapping</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../email-template/index.aspx'>Manage Email Template</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-master/index.aspx'>Manage Email Event</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-in-template/index.aspx'>Manage Event with template</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-object-mapping/index.aspx'>Manage Event with lookup</a></li>");
                //sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../others-to-master/index.aspx'>Post Others value to master</a></li>");
                sb.Append("</ul>");
                divMenu.InnerHtml = sb.ToString();
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }
        }
        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
        protected void gdvUserInGroup_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnActive = (HiddenField)e.Row.FindControl("hdnActive");
                    Image imgActive = (Image)e.Row.FindControl("imgActive");
                    Image imgDeactive = (Image)e.Row.FindControl("imgDeactive");
                    imgActive.Visible = (hdnActive.Value == "True") ? true : false;
                    imgDeactive.Visible = (hdnActive.Value == "True") ? false : true;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {

            }
        }
        protected void gdvUserInGroup_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.UserInGroupInfo mData;
            try
            {
                if (UserId != 0)
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    mData = new DAMServices.UserInGroupInfo();
                    if (e.CommandName == "_ActiveDeactive")
                    {
                        String[] CommandArgs = e.CommandArgument.ToString().Split(new char[] { '|' });
                        Int32 RowUserGroupId = Convert.ToInt32(CommandArgs[0]);
                        Boolean Status = Convert.ToBoolean(CommandArgs[1]);
                        mData.UserGroupId = RowUserGroupId;
                        mData.ModifiedBy = UserId;
                        mData.IsActive = (Status) ? false : true;
                        Int32 r = objDAM.ActivateDeactivateUserInGroupMaster(mData);
                        if (r > 0)
                        {
                            PopulateActiveUserInGroupList();
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
                mData = null;
            }
        }
        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            PopulateGroupListDropDown();
            ddlGroup.SelectedValue = "0";
            gdvUserList.DataSource = null;
            gdvUserList.DataBind();
            if(gdvUserInGroup.Rows.Count > 0)
                gdvUserInGroup.HeaderRow.TableSection = TableRowSection.TableHeader;
            popup.Show();
        }
        protected void ddlGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            if (ddlGroup.SelectedIndex > 0)
            {
                try
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    gdvUserList.DataSource = objDAM.GetUserListNotInParticularGroup(Convert.ToInt32(ddlGroup.SelectedValue));
                    gdvUserList.DataBind();
                    if(gdvUserList.Rows.Count>0)
                        gdvUserList.HeaderRow.TableSection = TableRowSection.TableHeader;
                    if(gdvUserInGroup.Rows.Count>0)
                        gdvUserInGroup.HeaderRow.TableSection = TableRowSection.TableHeader;
                    popup.Show();
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
            }
            else
            {
                gdvUserList.DataSource = null;
                gdvUserList.DataBind();
                popup.Show();
            }
        }
        protected void chkSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkSelectAll = (CheckBox)gdvUserList.HeaderRow.FindControl("chkSelectAll");
            foreach (GridViewRow row in gdvUserList.Rows)
            {
                CheckBox chkAdd = (CheckBox)row.FindControl("chkAdd");
                if (chkSelectAll.Checked == true)
                {
                    chkAdd.Checked = true;
                }
                else
                {
                    chkAdd.Checked = false;
                }
            }
            gdvUserList.HeaderRow.TableSection = TableRowSection.TableHeader;
            popup.Show();
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            if (gdvUserList.Rows.Count > 0)
            {
                try
                {
                    String strUsrInGrDetails = String.Empty;
                    for (int i = 0; i < gdvUserList.Rows.Count; i++)
                    {
                        CheckBox chkAdd = (CheckBox)gdvUserList.Rows[i].FindControl("chkAdd");
                        HiddenField hdnUserId = (HiddenField)gdvUserList.Rows[i].FindControl("hdnUserId");
                        if (chkAdd.Checked)
                        {
                            strUsrInGrDetails += hdnUserId.Value + "," + ddlGroup.SelectedValue + "," + UserId + "," + GetIPAddress() + "|";
                        }
                    }
                    if (strUsrInGrDetails != "")
                    {
                        strUsrInGrDetails = strUsrInGrDetails.Remove(strUsrInGrDetails.Length - 1);
                        if (strUsrInGrDetails != "")
                        {
                            objDAM = new DAMServices.ServiceContractClient();
                            objDAM.InsertUserInGroup(strUsrInGrDetails);
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divError.Attributes.Add("style", "display:block");
                            divConfirm.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.ADD_ERROR;
                        }
                        PopulateActiveUserInGroupList();
                    }
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
            }
            else
            {
                divError.Attributes.Add("style", "display:block");
                divConfirm.Attributes.Add("style", "display:none");
                confirmMsg.InnerHtml = "";
                errorMsg.InnerHtml = Constant.DATA_NOT_FOUND;
            }
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var list = objDAM.GetAllUserInGroupSearch(Server.HtmlEncode(txtSearchTeam.Value));
                gdvUserInGroup.DataSource = list.ToList();
                gdvUserInGroup.DataBind();
                gdvUserInGroup.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (gdvUserInGroup.Rows.Count > 0)
                {
                    Response.ClearContent();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "UserWithTeam.xls"));
                    Response.ContentType = "application/ms-excel";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter htw = new HtmlTextWriter(sw);
                    gdvUserInGroup.AllowPaging = false;
                    //Change the Header Row back to white color
                    gdvUserInGroup.HeaderRow.Style.Add("background-color", "#FFFFFF");
                    gdvUserInGroup.HeaderRow.Style.Add("color", "#fff");
                    for (int i = 0; i < gdvUserInGroup.HeaderRow.Cells.Count; i++)
                        gdvUserInGroup.HeaderRow.Cells[i].Style.Add("background-color", "#1B1BBA");
                    for (int i = 0; i < gdvUserInGroup.Columns.Count; i++)
                    {
                        if (gdvUserInGroup.Columns[i].HeaderText == "Active")
                            gdvUserInGroup.Columns[i].Visible = false;
                        if (gdvUserInGroup.Columns[i].HeaderText == "IsActive")
                            gdvUserInGroup.Columns[i].Visible = true;
                    }
                    gdvUserInGroup.RenderControl(htw);
                    Response.Write(sw.ToString());
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }
        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
    }
}