﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using log4net;
using System.Configuration;
using DAM.Apps.CommonClasses;
using System.IO;
using System.Text;
using QueryStringEncryption;

namespace DAM.Apps.event_in_template
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));
        private Int32 UserId;
        private Int32 LibId;

        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }

        protected void PopulateActiveEventInTemplateList()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var list = objDAM.GetAllEventInTemplate();
                gdvEventInTemplate.DataSource = list;
                gdvEventInTemplate.DataBind();
                gdvEventInTemplate.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void PopulateEvent()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var list = objDAM.GetAllActiveEventMaster();
                ddlEvent.DataSource = list;
                ddlEvent.DataValueField = "EventId";
                ddlEvent.DataTextField = "EventName";
                ddlEvent.DataBind();
                //ddlEvent.Items.Insert(0, new ListItem("---- Select Event ----", "0"));
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void PopulateTemplate()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var list = objDAM.GetAllEmailTemplate();
                ddlTemplate.DataSource = list;
                ddlTemplate.DataValueField = "TemplateId";
                ddlTemplate.DataTextField = "TemplateName";
                ddlTemplate.DataBind();
                //ddlTemplate.Items.Insert(0, new ListItem("---- Select Template ----", "0"));
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                UserId = Convert.ToInt32(Session["UserId"].ToString());
                LibId = Convert.ToInt32(Session["LibId"].ToString());
                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "System Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());
            }
            else
            {
                Response.Redirect("~/Default.aspx", false);
            }
            if (!IsPostBack)
            {
                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                //BindMenu(LibId);
                PopulateActiveEventInTemplateList();
                PopulateEvent();
                PopulateTemplate();
            }
        }
        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
        private void BindMenu(Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                StringBuilder sb = new StringBuilder();
                var list = objDAM.GetAllActiveAttributeMasterLookupList()
                                    .Where(x => x.LibId == 0 || x.LibId == LibId)
                                    .GroupBy(g => g.FieldId)
                                    .Select(g => new
                                    {
                                        FieldId = g.Key,
                                        FieldName = g.First().FieldName
                                    });
                sb.Append("<ul>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../sys-user-master/index.aspx'>Manage User</a></li>");
                sb.Append("<li><img src='../img/nav-icons/file-type.png' alt='' /><a href='../sys-user-in-team/index.aspx'>User with Team</a></li>");
                int i = 0;
                foreach (var l in list)
                {
                    if (l.FieldName != "Confidential")
                    {
                        if (i == 0)
                            hdnFieldId.Value = l.FieldId.ToString();
                        sb.AppendFormat("<li><img src='../img/nav-icons/brand.png' alt='' /><a href='../sys-admin/index.aspx?{1}'>{0}</a></li>", l.FieldName, EncryptQueryString(String.Format("fid={0}^fname={1}", l.FieldId, l.FieldName)));
                        i++;
                    }
                }
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../email-setting/index.aspx'>Manage Email Setting</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../email-template/index.aspx'>Manage Email Template</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-master/index.aspx'>Manage Email Event</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-in-template/index.aspx'>Manage Event with template</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-object-mapping/index.aspx'>Manage Event with lookup</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../email-log/index.aspx'>Email Log</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../others-to-master/index.aspx'>Post Others value to master</a></li>");
                sb.Append("</ul>");
                divMenu.InnerHtml = sb.ToString();
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void gdvEventInTemplate_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnActive = (HiddenField)e.Row.FindControl("hdnActive");
                    Image imgActive = (Image)e.Row.FindControl("imgActive");
                    Image imgDeactive = (Image)e.Row.FindControl("imgDeactive");
                    imgActive.Visible = (hdnActive.Value == "True") ? true : false;
                    imgDeactive.Visible = (hdnActive.Value == "True") ? false : true;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {

            }
        }

        protected void gdvEventInTemplate_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                if (UserId != 0)
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    if (e.CommandName == "_ActiveDeactive")
                    {
                        String[] CommandArgs = e.CommandArgument.ToString().Split(new char[] { '|' });
                        Int32 EventInTemplateId = Convert.ToInt32(CommandArgs[0]);
                        Boolean Status = Convert.ToBoolean(CommandArgs[1]);
                        Int32 r = objDAM.ActivateDeactivateEventInTemplate(EventInTemplateId, (Status) ? false : true,UserId);
                        if (r > 0)
                        {
                            PopulateActiveEventInTemplateList();
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            PopulateEvent();
            PopulateTemplate();
            popup.Show();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Int32 returnVal = 0;
            DAMServices.ServiceContractClient objDAM;
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                returnVal = objDAM.InsertEventInTemplate(Convert.ToInt32(ddlEvent.SelectedValue), Convert.ToInt32(ddlTemplate.SelectedValue),1, UserId);
                if (returnVal > 0)
                {
                    divConfirm.Attributes.Add("style", "display:block");
                    divError.Attributes.Add("style", "display:none");
                    confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                    errorMsg.InnerHtml = "";
                }
                else
                {
                    divError.Attributes.Add("style", "display:block");
                    divConfirm.Attributes.Add("style", "display:none");
                    confirmMsg.InnerHtml = "";
                    errorMsg.InnerHtml = Constant.DUPLICATE;
                }
                PopulateActiveEventInTemplateList();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var list = objDAM.GetEventInTemplateSearch(LibId,Server.HtmlEncode(txtSearch.Value));
                gdvEventInTemplate.DataSource = list;
                gdvEventInTemplate.DataBind();
                gdvEventInTemplate.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (gdvEventInTemplate.Rows.Count > 0)
                {
                    Response.ClearContent();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "UserWithTeam.xls"));
                    Response.ContentType = "application/ms-excel";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter htw = new HtmlTextWriter(sw);
                    gdvEventInTemplate.AllowPaging = false;
                    //Change the Header Row back to white color
                    gdvEventInTemplate.HeaderRow.Style.Add("background-color", "#FFFFFF");
                    gdvEventInTemplate.HeaderRow.Style.Add("color", "#fff");
                    for (int i = 0; i < gdvEventInTemplate.HeaderRow.Cells.Count; i++)
                        gdvEventInTemplate.HeaderRow.Cells[i].Style.Add("background-color", "#1B1BBA");
                    for (int i = 0; i < gdvEventInTemplate.Columns.Count; i++)
                    {
                        if (gdvEventInTemplate.Columns[i].HeaderText == "Active")
                            gdvEventInTemplate.Columns[i].Visible = false;
                        if (gdvEventInTemplate.Columns[i].HeaderText == "IsActive")
                            gdvEventInTemplate.Columns[i].Visible = true;
                    }
                    gdvEventInTemplate.RenderControl(htw);
                    Response.Write(sw.ToString());
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
    }
}