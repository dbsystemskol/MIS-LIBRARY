﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using log4net;
using System.Configuration;
using DAM.Apps.CommonClasses;
using System.IO;
using System.Web.Configuration;
using System.Text;
using QueryStringEncryption;

namespace DAM.Apps.brand_category_mapping
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));
        private Int32 UserId;
        private Int32 LibId;
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "Application Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
                LibId = Convert.ToInt32(Session["LibId"].ToString());
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {
                BindMenu(LibId);
                PopulateBrandCategoryMapping();
            }
        }
        private void BindMenu(Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                StringBuilder sb = new StringBuilder();
                var list = objDAM.GetAllActiveAttributeMasterLookupList()
                                    .Where(x => x.LibId == 0 || x.LibId == LibId)
                                    .GroupBy(g => g.FieldId)
                                    .Select(g => new
                                    {
                                        FieldId = g.Key,
                                        FieldName = g.First().FieldName
                                    });
                sb.Append("<ul>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../sys-user-master/index.aspx'>Manage User</a></li>");
                sb.Append("<li><img src='../img/nav-icons/file-type.png' alt='' /><a href='../sys-user-in-team/index.aspx'>User with Team</a></li>");
                int i = 0;
                foreach (var l in list)
                {
                    if (l.FieldName != "Confidential")
                    {
                        if (i == 0)
                            hdnFieldId.Value = l.FieldId.ToString();
                        sb.AppendFormat("<li><img src='../img/nav-icons/brand.png' alt='' /><a href='../sys-admin/index.aspx?{1}'>{0}</a></li>", l.FieldName, EncryptQueryString(String.Format("fid={0}^fname={1}", l.FieldId, l.FieldName)));
                        i++;
                    }
                }
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../brand-category-mapping/index.aspx'>Brand Category Mail Mapping</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../user-brand-category-mapping/index.aspx'>User Brand Category Mapping</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../email-log/index.aspx'>Email Log</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../document-log/index.aspx'>Document Log</a></li>");
                
                sb.Append("</ul>");
                divMenu.InnerHtml = sb.ToString();
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }
        }
        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }

        protected void PopulateBrandCategoryMapping()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                gdvBrandCategory.DataSource = objDAM.GetAllBrandCategoryMapping();
                gdvBrandCategory.DataBind();
                gdvBrandCategory.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void PopulateBrand()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                ddlBrand.DataSource = objDAM.GetLookupMasterByFieldId(1, 1);
                ddlBrand.DataValueField = "LookupId";
                ddlBrand.DataTextField = "FieldValue";
                ddlBrand.DataBind();
                ddlBrand.Items.Insert(0, new ListItem("---- Select Brand ----", "0"));
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void PopulateCategory()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                ddlCategory.DataSource = objDAM.GetLookupMasterByFieldId(2, 1);
                ddlCategory.DataValueField = "LookupId";
                ddlCategory.DataTextField = "FieldValue";
                ddlCategory.DataBind();
                ddlCategory.Items.Insert(0, new ListItem("---- Select Category ----", "0"));
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }



        protected void gdvBrandCategory_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnActive = (HiddenField)e.Row.FindControl("hdnActive");
                    HiddenField hdnPermission = (HiddenField)e.Row.FindControl("hdnPermission");
                    Image imgActive = (Image)e.Row.FindControl("imgActive");
                    Image imgDeactive = (Image)e.Row.FindControl("imgDeactive");
                    imgActive.Visible = (hdnActive.Value == "True") ? true : false;
                    imgDeactive.Visible = (hdnActive.Value == "True") ? false : true;

                    Image ImgNonconfActive = (Image)e.Row.FindControl("ImgNonconfActive");
                    Image ImgNonconfDeactive = (Image)e.Row.FindControl("ImgNonconfDeactive");
                    Image ImgConfActive = (Image)e.Row.FindControl("ImgConfActive");
                    Image ImgConfDeactive = (Image)e.Row.FindControl("ImgConfDeactive");

                    Label lblConfidential = (Label)e.Row.FindControl("lblConfidential");
                    Label lblNonConfidential = (Label)e.Row.FindControl("lblNonConfidential");
                    switch (hdnPermission.Value)
                    {
                        case "0":
                            ImgConfActive.Visible = false;
                            ImgConfDeactive.Visible = true;
                            ImgNonconfActive.Visible = false;
                            ImgNonconfDeactive.Visible = true;
                            lblConfidential.Text = "False";
                            lblNonConfidential.Text = "False";
                            break;
                        case "1":
                            ImgConfActive.Visible = false;
                            ImgConfDeactive.Visible = true;
                            ImgNonconfActive.Visible = true;
                            ImgNonconfDeactive.Visible = false;
                            lblConfidential.Text = "False";
                            lblNonConfidential.Text = "True";
                            break;
                        case "2":
                            ImgConfActive.Visible = true;
                            ImgConfDeactive.Visible = false;
                            ImgNonconfActive.Visible = false;
                            ImgNonconfDeactive.Visible = true;
                            lblConfidential.Text = "True";
                            lblNonConfidential.Text = "False";
                            break;
                        case "3":
                            ImgConfActive.Visible = true;
                            ImgConfDeactive.Visible = false;
                            ImgNonconfActive.Visible = true;
                            ImgNonconfDeactive.Visible = false;
                            lblConfidential.Text = "True";
                            lblNonConfidential.Text = "True";
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {

            }
        }

        protected void gdvBrandCategory_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.BrandCategoryMappingInfo mData;
            try
            {
                if (UserId != 0)
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    mData = new DAMServices.BrandCategoryMappingInfo();
                    if (e.CommandName == "_ActiveDeactive")
                    {
                        String[] CommandArgs = e.CommandArgument.ToString().Split(new char[] { '|' });
                        Int32 RowTeamId = Convert.ToInt32(CommandArgs[0]);
                        Boolean Status = Convert.ToBoolean(CommandArgs[1]);
                        mData.BrandCategoryMappingId = RowTeamId;
                        mData.ModifiedBy = UserId;
                        mData.IsActive = (Status) ? false : true;
                        Int32 r = objDAM.ActivateDeactivateBrandCategoryMapping(mData);
                        if (r > 0)
                        {
                            PopulateBrandCategoryMapping();
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }
                    }
                    else if (e.CommandName == "_Edit")
                    {
                        String BrandCategoryId = e.CommandArgument.ToString();
                        GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                        HiddenField hdnBrand = (HiddenField)row.FindControl("hdnBrand");
                        HiddenField hdnCategory = (HiddenField)row.FindControl("hdnCategory");
                        HiddenField hdnUserName = (HiddenField)row.FindControl("hdnUserName");
                        HiddenField hdnName = (HiddenField)row.FindControl("hdnName");
                        HiddenField hdnPermission = (HiddenField)row.FindControl("hdnPermission");
                        hdnBrandCategoryId.Value = BrandCategoryId;
                        lblBrand.Text = hdnBrand.Value;
                        lblCategory.Text = hdnCategory.Value;
                        lblName.Text = hdnName.Value;
                        lblUserName.Text = hdnUserName.Value;
                        switch(hdnPermission.Value)
                        {
                            case "0":
                                chkConf.Checked = false;
                                chkNonConf.Checked = false;
                                break;
                            case "1":
                                chkConf.Checked = false;
                                chkNonConf.Checked = true;
                                break;
                            case "2":
                                chkConf.Checked = true;
                                chkNonConf.Checked = false;
                                break;
                            case "3":
                                chkConf.Checked = true;
                                chkNonConf.Checked = true;
                                break;
                        }
                        editPopup.Show();
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
                mData = null;
            }
        }

        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            PopulateBrand();
            PopulateCategory();
            ddlBrand.SelectedValue = "0";
            ddlCategory.SelectedValue = "0";
            gdvUserList.DataSource = null;
            gdvUserList.DataBind();
            popup.Show();
        }

        protected void ddlBrand_SelectedIndexChanged(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            if (ddlBrand.SelectedIndex > 0 && ddlCategory.SelectedIndex > 0)
            {
                try
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    gdvUserList.DataSource = objDAM.GetUserNotInBrandCategory(Convert.ToInt32(ddlBrand.SelectedValue),Convert.ToInt32(ddlCategory.SelectedValue));
                    gdvUserList.DataBind();
                    gdvUserList.HeaderRow.TableSection = TableRowSection.TableHeader;
                    popup.Show();
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
            }
            else
            {
                gdvUserList.DataSource = null;
                gdvUserList.DataBind();
                popup.Show();
            }
        }

        protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            if (ddlCategory.SelectedIndex > 0 && ddlBrand.SelectedIndex > 0)
            {
                try
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    gdvUserList.DataSource = objDAM.GetUserNotInBrandCategory(Convert.ToInt32(ddlBrand.SelectedValue), Convert.ToInt32(ddlCategory.SelectedValue));
                    gdvUserList.DataBind();
                    gdvUserList.HeaderRow.TableSection = TableRowSection.TableHeader;
                    popup.Show();
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
            }
            else
            {
                gdvUserList.DataSource = null;
                gdvUserList.DataBind();
                popup.Show();
            }
        }
        
        protected void chkSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkSelectAll = (CheckBox)gdvUserList.HeaderRow.FindControl("chkSelectAll");
            foreach (GridViewRow row in gdvUserList.Rows)
            {
                CheckBox chkAdd = (CheckBox)row.FindControl("chkAdd");
                CheckBox chkConf = (CheckBox)row.FindControl("chkConf");
                CheckBox chkNonConf = (CheckBox)row.FindControl("chkNonConf");
                if (chkSelectAll.Checked == true)
                {
                    chkAdd.Checked = true;
                    chkConf.Enabled = true;
                    chkNonConf.Enabled = true;
                }
                else
                {
                    chkAdd.Checked = false;
                    chkConf.Enabled = false;
                    chkNonConf.Enabled = false;
                    chkConf.Checked = false;
                    chkNonConf.Checked = false;
                }
            }
            
            gdvUserList.HeaderRow.TableSection = TableRowSection.TableHeader;
            popup.Show();
        }
        protected void chkAdd_CheckedChanged(object sender, EventArgs e)
        {
            foreach (GridViewRow row in gdvUserList.Rows)
            {
                CheckBox chkAdd = (CheckBox)row.FindControl("chkAdd");
                CheckBox chkConf = (CheckBox)row.FindControl("chkConf");
                CheckBox chkNonConf = (CheckBox)row.FindControl("chkNonConf");
                if (chkAdd.Checked == true)
                {
                    chkConf.Enabled = true;
                    chkNonConf.Enabled = true;
                }
                else
                {
                    chkConf.Enabled = false;
                    chkNonConf.Enabled = false;
                    chkConf.Checked = false;
                    chkNonConf.Checked = false;
                }
            }
            gdvUserList.HeaderRow.TableSection = TableRowSection.TableHeader;
            popup.Show();
        }

        protected void btnEditSave_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.BrandCategoryMappingInfo dList;
            CommonClass objCommon;
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            try
            {
                objCommon = new CommonClass();
                objDAM = new DAMServices.ServiceContractClient();
                dList = new DAMServices.BrandCategoryMappingInfo();
                Int32 Permission = 0;
                String BinaryCode = String.Empty;
                dList.BrandCategoryMappingId = Convert.ToInt32(hdnBrandCategoryId.Value);
                BinaryCode = (chkConf.Checked) ? "1" : "0";
                BinaryCode += (chkNonConf.Checked) ? "1" : "0";
                Permission = objCommon.BinaryToInteger(BinaryCode);
                dList.Permission = Convert.ToInt16(Permission);
                dList.ModifiedBy = UserId;
                Int32 Returnval = objDAM.UpdateBrandCategoryMapping(dList);
                if (Returnval > 0)
                {
                    divConfirm.Attributes.Add("style", "display:block");
                    divError.Attributes.Add("style", "display:none");
                    confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                    errorMsg.InnerHtml = "";
                    PopulateBrandCategoryMapping();
                }
                else
                {
                    divConfirm.Attributes.Add("style", "display:none");
                    divError.Attributes.Add("style", "display:block");
                    confirmMsg.InnerHtml = "";
                    errorMsg.InnerHtml = Constant.EDIT_ERROR;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            if (gdvUserList.Rows.Count > 0)
            {
                try
                {
                    CommonClass objCommon = new CommonClass();
                    String strUsrInTmDetails = String.Empty;
                    for (int i = 0; i < gdvUserList.Rows.Count; i++)
                    {
                        CheckBox chkAdd = (CheckBox)gdvUserList.Rows[i].FindControl("chkAdd");                        
                        if (chkAdd.Checked)
                        {
                            Int32 Permission = 0;
                            String BinaryCode = String.Empty;
                            HiddenField hdnUserId = (HiddenField)gdvUserList.Rows[i].FindControl("hdnUserId");
                            HiddenField hdnEmailId = (HiddenField)gdvUserList.Rows[i].FindControl("hdnEmailId");
                            CheckBox chkIsAdmin = (CheckBox)gdvUserList.Rows[i].FindControl("chkIsAdmin");
                            CheckBox chkConf = (CheckBox)gdvUserList.Rows[i].FindControl("chkConf");
                            CheckBox chkNonConf = (CheckBox)gdvUserList.Rows[i].FindControl("chkNonConf");
                            BinaryCode = (chkConf.Checked) ? "1" : "0";
                            BinaryCode += (chkNonConf.Checked) ? "1" : "0";
                            Permission = objCommon.BinaryToInteger(BinaryCode);
                            strUsrInTmDetails += ddlBrand.SelectedValue + "," + ddlCategory.SelectedValue + "," + hdnUserId.Value + "," + hdnEmailId.Value + "," + Permission + "," + chkIsAdmin.Checked + "," + UserId + "|";
                        }
                    }
                    if (strUsrInTmDetails != "")
                    {
                        strUsrInTmDetails = strUsrInTmDetails.Remove(strUsrInTmDetails.Length - 1);
                        if (strUsrInTmDetails != "")
                        {
                            objDAM = new DAMServices.ServiceContractClient();
                            objDAM.InsertBrandCategoryMapping(strUsrInTmDetails);
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divError.Attributes.Add("style", "display:block");
                            divConfirm.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.ADD_ERROR;
                        }
                        PopulateBrandCategoryMapping();
                    }
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
            }
            else
            {
                divError.Attributes.Add("style", "display:block");
                divConfirm.Attributes.Add("style", "display:none");
                confirmMsg.InnerHtml = "";
                errorMsg.InnerHtml = Constant.DATA_NOT_FOUND;
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                gdvBrandCategory.DataSource = objDAM.BrandCategoryMappingInfoSearch(Server.HtmlEncode(txtSearchTeam.Value));
                gdvBrandCategory.DataBind();
                gdvBrandCategory.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (gdvBrandCategory.Rows.Count > 0)
                {
                    Response.ClearContent();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "BrandCategoryMapping.xls"));
                    Response.ContentType = "application/ms-excel";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter htw = new HtmlTextWriter(sw);
                    gdvBrandCategory.AllowPaging = false;
                    //Change the Header Row back to white color
                    gdvBrandCategory.HeaderRow.Style.Add("background-color", "#FFFFFF");
                    gdvBrandCategory.HeaderRow.Style.Add("color", "#fff");
                    for (int i = 0; i < gdvBrandCategory.HeaderRow.Cells.Count; i++)
                        gdvBrandCategory.HeaderRow.Cells[i].Style.Add("background-color", "#1B1BBA");
                    for (int i = 0; i < gdvBrandCategory.Columns.Count; i++)
                    {
                        if (gdvBrandCategory.Columns[i].HeaderText == "Active" || gdvBrandCategory.Columns[i].HeaderText == "Edit" || gdvBrandCategory.Columns[i].HeaderText == "Confidential" || gdvBrandCategory.Columns[i].HeaderText == "Non confidential")
                            gdvBrandCategory.Columns[i].Visible = false;
                        if (gdvBrandCategory.Columns[i].HeaderText == "IsActive")
                            gdvBrandCategory.Columns[i].Visible = true;
                        if (gdvBrandCategory.Columns[i].HeaderText == "IsConfidential")
                            gdvBrandCategory.Columns[i].Visible = true;
                        if (gdvBrandCategory.Columns[i].HeaderText == "IsNonConfidential")
                            gdvBrandCategory.Columns[i].Visible = true;
                    }
                    gdvBrandCategory.RenderControl(htw);
                    Response.Write(sw.ToString());
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
    }
}