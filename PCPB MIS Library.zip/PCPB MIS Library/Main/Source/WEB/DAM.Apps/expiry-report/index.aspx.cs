﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AjaxControlToolkit;
using DAM.Apps.CommonClasses;
using System.Configuration;
using log4net;
using log4net.Config;
using System.Collections;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Drawing.Imaging;
using System.Data;
using QueryStringEncryption;
using System.Text;
using System.Web.Configuration;
using System.Globalization;

namespace DAM.Apps.expiry_report
{
    public partial class index : System.Web.UI.Page
    {
        private Int32 UserId;
        private Int32 LibId;
        private Int32 TeamId;
        static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                UserId = Convert.ToInt32(Session["UserId"].ToString());
                LibId = Convert.ToInt32(Session["LibId"].ToString());
                TeamId = Convert.ToInt32(Session["TeamId"].ToString());
                lblTeamName.Text = "Role : " + Session["TeamName"].ToString();
                lblLibrary.Text = "Library : " + Session["Library"].ToString();
                if (Session["TeamName"] == null)
                {
                    Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                }
            }
            else
            {
                Response.Redirect("~/Default.aspx", false);
            }
            if (!IsPostBack)
            {
                //btnBack.NavigateUrl = HttpContext.Current.Request.UrlReferrer.ToString();
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);
                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                BindNotification(TeamId, UserId, LibId);
                PopulateExpiryList(System.DateTime.Now.ToString("dd-MM-yyyy"), System.DateTime.Now.AddDays(30).ToString("dd-MM-yyyy"));
                lblValue.Text = "Documents within 30 days";
            }
        }
        private void BindNotification(Int32 TeamId, Int32 VisiterUserId, Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            StringBuilder sb;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                sb = new StringBuilder();
                var mList = objDAM.GetUserNotification(TeamId, VisiterUserId, LibId);
                if (mList.Count() > 0)
                {
                    var list = mList.GroupBy(a => a.NotificationType)
                                .Select(n => new { Text = n.Key, Value = n.Count() }).ToList();
                    notificationCount.InnerText = list.Count().ToString();
                    sb.Append("<ul class='jq-dropdown-menu'>");

                    foreach (var l in list)
                    {
                        String encURL = String.Empty;
                        encURL = "../notification-list/index.aspx?" + EncryptQueryString(String.Format("sType={0}", l.Text));
                        sb.AppendFormat("<li><a href='{0}'>{1} ({2})</a></li>", encURL, l.Text, l.Value);
                    }
                    sb.Append("</ul>");
                    jqdropdown4.InnerHtml = sb.ToString();
                }
                else
                {
                    notificationCount.InnerText = "0";
                    jqdropdown4.InnerHtml = "";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
                sb = null;
            }
        }
        protected void PopulateExpiryList(String FromDate,String ToDate)
        {
            DAMServices.ServiceContractClient obje;
            try
            {
                obje = new DAMServices.ServiceContractClient();
                gdvExpiryReport.DataSource = obje.ExpiryReport(FromDate,ToDate);
                gdvExpiryReport.DataBind();
                gdvExpiryReport.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
            }
        }
        private string[] GetPrivilegeDetail(Int32 privilege)
        {
            string[] privilegeArray = new string[4];
            switch (privilege)
            {
                case 2:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 3:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = "0";
                    break;
                case 8:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 10:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 11:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = "0";
                    break;
                case 12:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = "0";
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 14:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = "0";
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 15:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = "0";
                    privilegeArray[2] = "No";
                    privilegeArray[3] = "0";
                    break;
            }
            return privilegeArray;
        }
        protected void btnNext1Month_Click(object sender, EventArgs e)
        {
            PopulateExpiryList(System.DateTime.Now.ToString("dd-MM-yyyy"), System.DateTime.Now.AddDays(30).ToString("dd-MM-yyyy"));
            lblValue.Text = "Documents within 30 days";
        }
        protected void btnLast30Days_Click(object sender, EventArgs e)
        {
            PopulateExpiryList(System.DateTime.Now.ToString("dd-MM-yyyy"), System.DateTime.Now.AddDays(-30).ToString("dd-MM-yyyy"));
            lblValue.Text = "Documents expired in last 30 days.";
        }
        protected void btnLast60Days_Click(object sender, EventArgs e)
        {
            PopulateExpiryList(System.DateTime.Now.ToString("dd-MM-yyyy"), System.DateTime.Now.AddDays(-60).ToString("dd-MM-yyyy"));
            lblValue.Text = "Documents expired in last 60 days.";
        }
        protected void btnCustomSearch_Click(object sender, EventArgs e)
        {
            Boolean fromflag;
            Boolean toflag;
            DateTime fromdate;
            DateTime todate;
            if (txtFromDate.Text.Length == 0)
            {
                divConfirm.Attributes.Add("style", "display:none");
                divError.Attributes.Add("style", "display:block");
                confirmMsg.InnerHtml = "";
                errorMsg.InnerHtml = "From date is blank.";
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "key", "<script>showcustom();</script>", false);
                return;
            }
            if (txtToDate.Text.Length == 0)
            {
                divConfirm.Attributes.Add("style", "display:none");
                divError.Attributes.Add("style", "display:block");
                confirmMsg.InnerHtml = "";
                errorMsg.InnerHtml = "To date is blank.";
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "key", "<script>showcustom();</script>", false);
                return;
            }
            if (txtFromDate.Text.Length > 0 && txtToDate.Text.Length > 0)
            {
                fromflag = DateTime.TryParse(Convert.ToDateTime(txtFromDate.Text, new CultureInfo("hi-IN").DateTimeFormat).ToString(), out fromdate);
                toflag = DateTime.TryParse(Convert.ToDateTime(txtToDate.Text, new CultureInfo("hi-IN").DateTimeFormat).ToString(), out todate);
                if (!fromflag)
                {
                    divConfirm.Attributes.Add("style", "display:none");
                    divError.Attributes.Add("style", "display:block");
                    confirmMsg.InnerHtml = "";
                    errorMsg.InnerHtml = "Invalid from date.";
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "key", "<script>showcustom();</script>", false);
                    return;
                }
                if (!toflag)
                {
                    divConfirm.Attributes.Add("style", "display:none");
                    divError.Attributes.Add("style", "display:block");
                    confirmMsg.InnerHtml = "";
                    errorMsg.InnerHtml = "Invalid to date";
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "key", "<script>showcustom();</script>", false);
                    return;
                }
                if (fromdate > todate)
                {
                    divConfirm.Attributes.Add("style", "display:none");
                    divError.Attributes.Add("style", "display:block");
                    confirmMsg.InnerHtml = "";
                    errorMsg.InnerHtml = "To date can not be greater than from date.";
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "key", "<script>showcustom();</script>", false);
                    return;
                }
                lblValue.Text = "Documents expire between " + txtFromDate.Text + " and " + txtToDate.Text;
                PopulateExpiryList(txtFromDate.Text, txtToDate.Text);
            }
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "key", "<script>showcustom();</script>", false);
        }
        protected void gdvExpiryReport_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    Label lblNoOfDaysLeft = (Label)e.Row.FindControl("lblNoOfDaysLeft");
                    if (Convert.ToInt32(lblNoOfDaysLeft.Text) < 0)
                        lblNoOfDaysLeft.Text = "";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {

            }
        }
        protected void gdvExpiryReport_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                Int32 RowDocId = Convert.ToInt32(e.CommandArgument);
                String encURL = String.Empty;
                if (e.CommandName == "_View")
                {
                    encURL = "../file-preview/index.aspx?" + EncryptQueryString(String.Format("fid={0}&docid={1}", 0, RowDocId));
                    Response.Redirect(encURL,false);
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }
        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
        private string DecryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Decrypt(strQueryString, "r0b1nr0y");
        }
    }
}