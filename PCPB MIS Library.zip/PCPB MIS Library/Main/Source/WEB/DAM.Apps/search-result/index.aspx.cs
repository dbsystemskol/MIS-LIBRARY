﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AjaxControlToolkit;
using DAM.Apps.CommonClasses;
using System.Configuration;
using log4net;
using log4net.Config;
using System.Collections;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Drawing.Imaging;
using System.Data;
using QueryStringEncryption;
using System.Text;
using System.Web.Configuration;

namespace DAM.Apps.search_result
{
    public partial class index : System.Web.UI.Page
    {
        private Int32 UserId;
        private Int32 LibId;
        private Int32 TeamId;
        static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() == "System Administrator" || Session["TeamName"].ToString() == "Application Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
                LibId = Convert.ToInt32(Session["LibId"].ToString());
                TeamId = Convert.ToInt32(Session["TeamId"].ToString());
                lblTeamName.Text = "Role : " + Session["TeamName"].ToString();
                lblLibrary.Text = "Library : " + Session["Library"].ToString();
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {
                btnBack.NavigateUrl = HttpContext.Current.Request.UrlReferrer.ToString();
                BindNotification(TeamId, UserId, LibId);
                String encURL = "";
                encURL = Request.RawUrl;  
                if (!encURL.Contains("?"))
                    return;
                encURL = encURL.Substring(encURL.IndexOf('?') + 1);
                if (!encURL.Equals(""))
                {
                    encURL = DecryptQueryString(encURL);
                    String[] queryStr = encURL.Split('^');
                    String[] sText = queryStr[0].Split(':');    // Search text
                    String[] cType = queryStr[1].Split(':');   //Content Type
                    
                    txtSearch.Value = sText[1].ToString();
                    BindSearchResult(sText[1].ToString(), Convert.ToInt32(cType[1]));
                    hdnContentTypeId.Value = cType[1].ToString();
                    hdnSearchText.Value = sText[1].ToString();
                }
                else
                {
                    String SearchText = String.Empty;
                    if (Session["SearchText"] != null)
                    {                        
                        SearchText = HttpContext.Current.Session["SearchText"].ToString();
                        txtSearch.Value = SearchText;
                        BindSearchResult(SearchText, 0);
                        hdnContentTypeId.Value = "0";
                        hdnSearchText.Value = SearchText;
                    }                 
                }
            }
        }        
        private void BindNotification(Int32 TeamId, Int32 VisiterUserId, Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            StringBuilder sb;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                sb = new StringBuilder();
                var mList = objDAM.GetUserNotification(TeamId, VisiterUserId, LibId);
                if (mList.Count() > 0)
                {
                    
                    var list = mList.GroupBy(a => a.NotificationType)
                                .Select(n => new { Text = n.Key, Value = n.Count() }).ToList();
                    notificationCount.InnerText = list.Count().ToString();
                    sb.Append("<ul class='jq-dropdown-menu'>");

                    foreach (var l in list)
                    {
                        String encURL = String.Empty;
                        encURL = "../notification-list/index.aspx?" + EncryptQueryString(String.Format("sType={0}", l.Text));
                        sb.AppendFormat("<li><a href='{0}'>{1} ({2})</a></li>", encURL, l.Text, l.Value);
                    }
                    sb.Append("</ul>");
                    jqdropdown4.InnerHtml = sb.ToString();
                }
                else
                {
                    notificationCount.InnerText = "0";
                    jqdropdown4.InnerHtml = "";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
                sb = null;
            }
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtSearch.Value.Trim().Length == 0)
                return;
            BindSearchResult(txtSearch.Value.Trim(),0);
        }
        private string[] GetPrivilegeDetail(Int32 privilege)
        {
            string[] privilegeArray = new string[4];
            switch (privilege)
            {
                case 2:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 3:
                     privilegeArray[0] = "Yes";
                     privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = "0";
                    break;
                case 8:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 10:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 11:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = "0";
                    break;
                case 12:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = "0";
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 14:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = "0";
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 15:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = "0";
                    privilegeArray[2] = "No";
                    privilegeArray[3] = "0";
                    break;
            }
            return privilegeArray;
        }
        private void BindSearchResult(String SearchText, Int32 ContentTypeId)
        {
            hdnContentTypeId.Value = ContentTypeId.ToString();
            hdnSearchText.Value = SearchText;
            divSearchText.InnerText = "";
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            DAMServices.ServiceContractClient objDAM;
            DAMServices.FreeTextSearchFiles dt;
            DAMServices.FreeTextSearchFiles dtTag;
            DAMServices.FreeTextSearchFiles dtC;
            DAMServices.FreeTextSearchFiles dtCTag;
            DAMServices.FreeTextSearchFiles dtG;
            DAMServices.FreeTextSearchFiles dtGTag;
            String html = String.Empty;
            String tagHtml = String.Empty;
           
            try
            {                
                objDAM = new DAMServices.ServiceContractClient();
                dt = new DAMServices.FreeTextSearchFiles();
                dtTag = new DAMServices.FreeTextSearchFiles();
                if (SearchText.Length > 0 && ContentTypeId > 0)
                {
                    var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                    var searchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search" && x.ContentTypeId == ContentTypeId).ToList();
                    var searchPrivilegeAll = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();
                    int counter = 0;
                    for (int a = 0; a < searchPrivilegeAll.Count(); a++)
                    {
                        dtCTag = new DAMServices.FreeTextSearchFiles();
                        dtGTag = new DAMServices.FreeTextSearchFiles();
                        string[] privilage = GetPrivilegeDetail(searchPrivilegeAll[a].Permission);
                        dtCTag = objDAM.GetFreeTextSearchFiles(SearchText, privilage[0], searchPrivilegeAll[a].ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[1]), searchPrivilegeAll[a].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]), UserId);
                        dtGTag = objDAM.GetFreeTextSearchFiles(SearchText, privilage[2], searchPrivilegeAll[a].ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[3]), searchPrivilegeAll[a].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]), UserId);

                        if (counter == 0 && dtCTag.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dtTag.FreeTextSearchTable = dtCTag.FreeTextSearchTable.Copy();
                            counter++;
                        }
                        else if (counter == 0 && dtGTag.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dtTag.FreeTextSearchTable = dtGTag.FreeTextSearchTable.Copy();
                            counter++;
                        }
                        else if (counter > 0 && dtCTag.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dtTag.FreeTextSearchTable.Merge(dtCTag.FreeTextSearchTable);
                        }
                        else if (counter > 0 && dtGTag.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dtTag.FreeTextSearchTable.Merge(dtGTag.FreeTextSearchTable);
                        }
                    }
                    counter = 0;
                    for (int i = 0; i < searchPrivilege.Count(); i++)
                    {
                        dtC = new DAMServices.FreeTextSearchFiles();                        
                        dtG = new DAMServices.FreeTextSearchFiles();                        
                        string[] privilage = GetPrivilegeDetail(searchPrivilege[i].Permission);
                        dtC = objDAM.GetFreeTextSearchFiles(SearchText, privilage[0], ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[1]), searchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]), UserId);
                        dtG = objDAM.GetFreeTextSearchFiles(SearchText, privilage[2], ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[3]), searchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]), UserId);

                        if (counter == 0 && dtC.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dt.FreeTextSearchTable = dtC.FreeTextSearchTable.Copy();
                            counter++;
                        }
                        else if (counter == 0 && dtG.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dt.FreeTextSearchTable = dtG.FreeTextSearchTable.Copy();
                            counter++;
                        }
                    }
                }
                else if (SearchText.Length > 0 && ContentTypeId == 0)
                {
                    var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                    var searchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();
                    int counter = 0;
                    for (int i = 0; i < searchPrivilege.Count(); i++)
                    {
                        dtC = new DAMServices.FreeTextSearchFiles();
                        dtCTag = new DAMServices.FreeTextSearchFiles();
                        dtG = new DAMServices.FreeTextSearchFiles();
                        dtGTag = new DAMServices.FreeTextSearchFiles();
                        string[] privilage = GetPrivilegeDetail(searchPrivilege[i].Permission);
                        dtC = objDAM.GetFreeTextSearchFiles(SearchText, privilage[0], searchPrivilege[i].ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[1]), searchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]), UserId);
                        if(dtC.FreeTextSearchTable.Rows.Count>0)
                            dtCTag = dtC;

                        dtG = objDAM.GetFreeTextSearchFiles(SearchText, privilage[2], searchPrivilege[i].ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[3]), searchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]), UserId);
                        if(dtG.FreeTextSearchTable.Rows.Count > 0)
                            dtGTag = dtG;

                        if (counter == 0 && dtC.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dt.FreeTextSearchTable = dtC.FreeTextSearchTable.Copy();
                            dtTag.FreeTextSearchTable = dtCTag.FreeTextSearchTable.Copy();
                            counter++;
                        }
                        else if (counter == 0 && dtG.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dt.FreeTextSearchTable = dtG.FreeTextSearchTable.Copy();
                            dtTag.FreeTextSearchTable = dtGTag.FreeTextSearchTable.Copy();
                            counter++;
                        }
                        else if (counter > 0 && dtC.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dtTag.FreeTextSearchTable.Merge(dtCTag.FreeTextSearchTable);
                        }
                        else if (counter > 0 && dtG.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dtTag.FreeTextSearchTable.Merge(dtGTag.FreeTextSearchTable);
                        }
                    }
                }
                if (dtTag.FreeTextSearchTable.Rows.Count > 0)
                {
                    var groupedData = from b in dtTag.FreeTextSearchTable.AsEnumerable()
                                      group b by new 
                                      { ContentType =  b.Field<string>("ContentType"),
                                        ContentTypeId = b.Field<int>("ContentTypeId")
                                      } into g
                                      select new
                                      {
                                          TagId = g.Key.ContentTypeId,
                                          TagName = g.Key.ContentType,
                                          Count = g.Count()
                                      };
                    String encThisURL = String.Empty;
                    int counter = 0;
                    foreach (var item in groupedData)
                    {
                        encThisURL = "../search-result/index.aspx?" + EncryptQueryString(String.Format("sText:{0}^cType:{1}", SearchText, item.TagId));
                        if (ContentTypeId == 0 && counter == 0)
                        {
                            tagHtml += String.Format("<li><a style='background: rgb(7, 124, 150) none repeat scroll 0px 0px;' href='{2}' >{0} ({1})</a></li>", item.TagName, item.Count, encThisURL);
                            counter++;
                        }
                        else if (ContentTypeId == item.TagId && counter == 0)
                        {
                            tagHtml += String.Format("<li><a style='background: rgb(7, 124, 150) none repeat scroll 0px 0px;' href='{2}' >{0} ({1})</a></li>", item.TagName, item.Count, encThisURL);
                            counter++;
                        }
                        else
                            tagHtml += String.Format("<li><a href='{2}' >{0} ({1})</a></li>", item.TagName, item.Count, encThisURL);
                    }
                    ulTag.InnerHtml = tagHtml;
                }

                if (dt.FreeTextSearchTable.Rows.Count > 0)
                {
                    html = "<table id='tblSearchResult' width='100%' cellpadding='0' cellspacing='0' ><thead><tr>";
                    foreach (DataColumn dcol in dt.FreeTextSearchTable.Columns)
                    {
                        if (dcol.ColumnName == "Confidential" || dcol.ColumnName == "ContentTypeId" || dcol.ColumnName == "LinkCount" || dcol.ColumnName == "DocId")
                        { }
                        else if (dcol.ColumnName == "SerialNo")
                        {
                            html += String.Format("<th>{0}</th>", "Doc No.");
                        }
                        //else if (dcol.ColumnName == "ContentType")
                        //{
                        //    html += String.Format("<th style='display:none'>{0}</th>", dcol.ColumnName);
                        //}
                        else
                            html += String.Format("<th>{0}</th>", dcol.ColumnName);
                    }
                    html += String.Format("<th>{0}</th>", "");
                    html += "</tr></thead><tbody id='tbltbody'>";
                    String encURL = String.Empty;
                    foreach (DataRow row in dt.FreeTextSearchTable.Rows)
                    {
                        html += "<tr>";
                        foreach (DataColumn column in dt.FreeTextSearchTable.Columns)
                        {
                            if (column.ColumnName == "Confidential" || column.ColumnName == "ContentTypeId" || column.ColumnName == "LinkCount" || column.ColumnName == "DocId")
                            { }
                            //else if (column.ColumnName == "SerialNo")
                            //{
                            //    html += "<td>";
                            //    html += row[column.ColumnName];
                            //    html += "</td>";
                            //}
                            else if (column.ColumnName == "SerialNo")
                            {
                                if (row["Confidential"].ToString() == "Yes")
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += " &nbsp;<img class='lock' title='Locked' alt='Locked' src='../img/nav-icons/icon_lock.png'></td>";
                                }
                                else if (row["Confidential"].ToString() == "No")
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += "</td>";
                                }
                                else
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += "</td>";
                                }
                            }
                            else
                            {
                                html += "<td>";
                                html += row[column.ColumnName];
                                html += "</td>";
                            }
                        }
                        encURL = "../file-preview/index.aspx?" + EncryptQueryString(String.Format("fid={0}&docid={1}", 0, row["DocId"]));
                        html += "<td>";
                        html += String.Format("<a href='{0}'><img src='../img/nav-icons/view.png' alt=''></a>", encURL);
                        html += "</td>";
                        html += "</tr>";
                    }
                    html += "</tbody></table>";
                    divSearch.InnerHtml = html;
                }
                else
                {
                    divSearch.InnerHtml = "";
                    ulTag.InnerHtml = "";
                    divConfirm.Attributes.Add("style", "display:none");
                    divError.Attributes.Add("style", "display:block");
                    confirmMsg.InnerHtml = "";
                    errorMsg.InnerHtml = "No data found.";
                }
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "Key", "<script>tableSorting();</script>", false);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void btnExport_Click(Object sender, EventArgs e)
        {
            divSearchText.InnerText = "";
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            DAMServices.ServiceContractClient objDAM;
            DAMServices.FreeTextSearchFiles dt;            
            DAMServices.FreeTextSearchFiles dtC;            
            DAMServices.FreeTextSearchFiles dtG;
            
            String html = String.Empty;
            String tagHtml = String.Empty;

            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = new DAMServices.FreeTextSearchFiles();
                
                if (hdnSearchText.Value.Length > 0 && Convert.ToInt32(hdnContentTypeId.Value) > 0)
                {
                    var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                    var searchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search" && x.ContentTypeId == Convert.ToInt32(hdnContentTypeId.Value)).ToList();
                    var searchPrivilegeAll = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();
                    for (int i = 0; i < searchPrivilege.Count(); i++)
                    {
                        dtC = new DAMServices.FreeTextSearchFiles();
                        dtG = new DAMServices.FreeTextSearchFiles();
                        string[] privilage = GetPrivilegeDetail(searchPrivilege[i].Permission);
                        dtC = objDAM.GetFreeTextSearchByContentType(hdnSearchText.Value, privilage[0], Convert.ToInt32(hdnContentTypeId.Value), LibId, TeamId, Convert.ToInt32(privilage[1]), searchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]),UserId);
                        dtG = objDAM.GetFreeTextSearchByContentType(hdnSearchText.Value, privilage[2], Convert.ToInt32(hdnContentTypeId.Value), LibId, TeamId, Convert.ToInt32(privilage[3]), searchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]),UserId);

                        if (i == 0)
                        {
                            dt.FreeTextSearchTable = dtC.FreeTextSearchTable.Copy();
                            dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);
                        }
                        else
                        {
                            dt.FreeTextSearchTable.Merge(dtC.FreeTextSearchTable);
                            dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);
                        }
                    }
                }
                else if (hdnSearchText.Value.Length > 0 && Convert.ToInt32(hdnContentTypeId.Value) == 0)
                {
                    var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                    var searchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();
                    for (int i = 0; i < searchPrivilege.Count(); i++)
                    {
                        dtC = new DAMServices.FreeTextSearchFiles();
                        
                        dtG = new DAMServices.FreeTextSearchFiles();
                        
                        string[] privilage = GetPrivilegeDetail(searchPrivilege[i].Permission);
                        dtC = objDAM.GetFreeTextSearchFiles(hdnSearchText.Value, privilage[0], searchPrivilege[i].ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[1]), searchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]), UserId);


                        dtG = objDAM.GetFreeTextSearchFiles(hdnSearchText.Value, privilage[2], searchPrivilege[i].ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[3]), searchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]), UserId);
                        

                        if (i == 0)
                        {
                            dt.FreeTextSearchTable = dtC.FreeTextSearchTable.Copy();
                            dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);
                        }
                        else
                        {
                            dt.FreeTextSearchTable.Merge(dtC.FreeTextSearchTable);
                            dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);
                        }
                    }
                }
                

                if (dt.FreeTextSearchTable.Rows.Count > 0)
                {
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ClearContent();
                    HttpContext.Current.Response.ClearHeaders();
                    HttpContext.Current.Response.Buffer = true;
                    HttpContext.Current.Response.ContentType = "application/ms-excel";
                    //HttpContext.Current.Response.ContentType = "application/ms-word";
                    HttpContext.Current.Response.Write(@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.0 Transitional//EN"">");
                    HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=Export.xls");
                    //HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=Reports.doc");
                    HttpContext.Current.Response.Charset = "utf-8";
                    HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("windows-1250");
                    HttpContext.Current.Response.Write("<font style='font-size:10.0pt; font-family:Calibri;'>");
                    HttpContext.Current.Response.Write("<BR><BR><BR>");
                    HttpContext.Current.Response.Write("<Table border='1' bgColor='#ffffff' borderColor='#000000' cellSpacing='0' cellPadding='0' style='font-size:10.0pt; font-family:Calibri; background:white;'> <TR>");
                    int columnscount = dt.FreeTextSearchTable.Columns.Count;
                    foreach (DataColumn column in dt.FreeTextSearchTable.Columns)
                    {
                        if (column.ColumnName == "DocId")
                        {

                        }
                        
                        else if (column.ColumnName == "ContentTypeId")
                        {

                        }
                        else if (column.ColumnName == "LinkCount")
                        {

                        }
                        else if (column.ColumnName == "SerialNo")
                        {
                            HttpContext.Current.Response.Write("<Td>");
                            HttpContext.Current.Response.Write("<B>");
                            HttpContext.Current.Response.Write("Doc No.");
                            HttpContext.Current.Response.Write("</B>");
                            HttpContext.Current.Response.Write("</Td>");
                        }
                        else
                        {
                            HttpContext.Current.Response.Write("<Td>");
                            HttpContext.Current.Response.Write("<B>");
                            HttpContext.Current.Response.Write(column.ColumnName);
                            HttpContext.Current.Response.Write("</B>");
                            HttpContext.Current.Response.Write("</Td>");
                        }
                    }
                    HttpContext.Current.Response.Write("</TR>");
                    foreach (DataRow row in dt.FreeTextSearchTable.Rows)
                    {
                        HttpContext.Current.Response.Write("<TR>");
                        foreach (DataColumn column in dt.FreeTextSearchTable.Columns)
                        {
                            if (column.ColumnName == "DocId")
                            {

                            }
                            
                            else if (column.ColumnName == "ContentTypeId")
                            {

                            }
                            else if (column.ColumnName == "LinkCount")
                            {

                            }
                            else if (column.ColumnName == "SerialNo")
                            {
                                HttpContext.Current.Response.Write("<Td>");
                                HttpContext.Current.Response.Write(row[column].ToString());
                                HttpContext.Current.Response.Write("</Td>");
                            }
                            else
                            {
                                HttpContext.Current.Response.Write("<Td>");
                                HttpContext.Current.Response.Write(row[column].ToString());
                                HttpContext.Current.Response.Write("</Td>");
                            }
                        }
                        
                        HttpContext.Current.Response.Write("</TR>");
                    }
                    HttpContext.Current.Response.Write("</Table>");
                    HttpContext.Current.Response.Write("</font>");
                    HttpContext.Current.Response.Flush();
                    HttpContext.Current.Response.End();
                }
                else
                {
                    divSearch.InnerHtml = "";
                    ulTag.InnerHtml = "";
                    divConfirm.Attributes.Add("style", "display:none");
                    divError.Attributes.Add("style", "display:block");
                    confirmMsg.InnerHtml = "";
                    errorMsg.InnerHtml = "No data found.";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
        private string DecryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Decrypt(strQueryString, "r0b1nr0y");
        }       
    }
}