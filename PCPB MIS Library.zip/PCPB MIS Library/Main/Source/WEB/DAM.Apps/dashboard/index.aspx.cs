﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AjaxControlToolkit;
using DAM.Apps.CommonClasses;
using System.Configuration;
using log4net;
using log4net.Config;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data;
using System.Security.Cryptography;
using QueryStringEncryption;
using System.Text;
using System.Web.Configuration; 

namespace DAM.Apps.dashboard
{
    public partial class index : System.Web.UI.Page
    {
        private Int32 UserId;
        private Int32 LibId;
        private Int32 TeamId;
        
        static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() == "System Administrator" || Session["TeamName"].ToString() == "Application Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                    else
                    {

                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());
                UserId = Convert.ToInt32(Session["UserId"].ToString());
                LibId = Convert.ToInt32(Session["LibId"].ToString());
                TeamId = Convert.ToInt32(Session["TeamId"].ToString());
                lblTeamName.Text = "Role : " + Session["TeamName"].ToString();
                lblLibrary.Text = "Library : " + Session["Library"].ToString();
                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {

                BindNotification(TeamId, UserId, LibId);
                 String encURL = "";
                encURL = Request.RawUrl;
                if (encURL.Contains("?"))
                {
                    encURL = encURL.Substring(encURL.IndexOf('?') + 1);
                    if (!encURL.Equals(""))
                    {
                        encURL = DecryptQueryString(encURL);
                        String[] queryStr = encURL.Split('^');
                        String[] fileType = queryStr[0].Split(':');    // New/Recent
                        String[] cType = queryStr[1].Split(':');   //Content Type
                        if (fileType[1].ToString() == "New")
                        {
                            PopulateFileNew(LibId, UserId, Convert.ToInt32(cType[1]));
                            PopulateFileRecent(LibId, UserId, 0);
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "tabKey", "<script>tabShowHide('My');</script>", false);
                        }
                        else if (fileType[1].ToString() == "Recent")
                        {
                            PopulateFileNew(LibId, UserId, 0);
                            PopulateFileRecent(LibId, UserId, Convert.ToInt32(cType[1]));
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "tabKey", "<script>tabShowHide('Recent');</script>", false);
                        }
                    }
                }
                else
                {
                    PopulateFileNew(LibId, UserId, 0);
                    PopulateFileRecent(LibId, UserId, 0);
                }
                
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "Key", "<script>tableSorting();</script>", false);
            }
        }

        protected void imgUpload_Click(object sender, EventArgs e)
        {
            Session["IsConfirm"] = 0;
            //Response.Redirect("~/document-upload/index.aspx");
            Response.Redirect("~/document-upload-new/index.aspx");
        }
        private void BindNotification(Int32 TeamId, Int32 VisiterUserId, Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            StringBuilder sb;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                sb = new StringBuilder();
                var mList = objDAM.GetUserNotification(TeamId, VisiterUserId, LibId);
                if (mList.Count() > 0)
                {
                    
                    var list = mList.GroupBy(a => a.NotificationType)
                                .Select(n => new { Text = n.Key, Value = n.Count() }).ToList();
                    notificationCount.InnerText = list.Count().ToString();
                    sb.Append("<ul class='jq-dropdown-menu'>");                    
                    
                    foreach (var l in list)
                    {
                        String encURL = String.Empty;
                        encURL = "../notification-list/index.aspx?" + EncryptQueryString(String.Format("sType={0}", l.Text));
                        sb.AppendFormat("<li><a href='{0}'>{1} ({2})</a></li>", encURL, l.Text, l.Value);
                    }
                    sb.Append("</ul>");
                    jqdropdown4.InnerHtml = sb.ToString();
                }
                else
                {
                    notificationCount.InnerText = "0";
                    String abc = String.Empty;
                    abc += abc + @"<ul class='jq-dropdown-menu'>
                                <li><a href='#'>Notification 1</a></li>
                                <li><a href='#'>Notification 2</a></li>
                                <li><a href='#'>Notification 3</a></li>
                                </ul>";
                    jqdropdown4.InnerHtml = "";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
                sb = null;
            }
        }
        private int GetSelfPrivilege(Int32 privilege)
        {
            int privilegeValue = 0;
            switch (privilege)
            {
                case 2:
                case 3:
                    privilegeValue = 1;                    
                    break;                
                case 8:
                case 12:
                    privilegeValue = 2;
                    break;
                case 10:
                case 11:
                case 14:
                case 15:
                    privilegeValue = 3;
                    break;
            }
            return privilegeValue;
        }
        private int GetOtherPrivilege(Int32 privilege)
        {
            int privilegeValue = 0;
            switch (privilege)
            {
                case 2:
                case 10:
                case 8:
                    privilegeValue = 0;
                    break;
                case 3:
                case 11:
                    privilegeValue = 1;
                    break;
                case 12:
                case 14:
                    privilegeValue = 2;
                    break;
                case 15:
                    privilegeValue = 3;
                    break;
            }
            return privilegeValue;
        }
        private void PopulateFileNew(Int32 LibId, Int32 UserId, Int32 ContentTypeId)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.DashboardNewFiles dt;
            DAMServices.DashboardNewFiles dtTemp;
            DAMServices.DashboardNewFiles dtTag;
            String tagHtml = String.Empty;
            String html = String.Empty;
            int count = 0;
            int tagCount = 0;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = new DAMServices.DashboardNewFiles();
                dtTag = new DAMServices.DashboardNewFiles();
                var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                var SearchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();
                for (int i = 0; i < SearchPrivilege.Count; i++)
                {
                    dtTemp = new DAMServices.DashboardNewFiles();
                    String confidential = String.Empty;
                    switch (GetSelfPrivilege(SearchPrivilege[i].Permission))
                    {
                        case 0:
                            confidential = "False";
                            break;
                        case 1:
                            confidential = "No";
                            break;
                        case 2:
                            confidential = "Yes";
                            break;
                        case 3:
                            confidential = "";
                            break;
                    }
                    if (confidential != "False")
                    {
                        dtTemp = objDAM.GetDashboardNewFiles(confidential, SearchPrivilege[i].ContentTypeId, LibId, UserId, TeamId, SearchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]));
                        if (count == 0 && dtTemp.DashboardNewFilesTable.Rows.Count > 0)
                        {
                            if (ContentTypeId == 0)
                            {
                                dt.DashboardNewFilesTable = dtTemp.DashboardNewFilesTable.Copy();
                                count++;
                            }

                            else if (ContentTypeId == SearchPrivilege[i].ContentTypeId)
                            {
                                dt.DashboardNewFilesTable = dtTemp.DashboardNewFilesTable.Copy();
                                count++;
                            }
                        }
                        else
                        {
                            //dt.DashboardNewFilesTable.Merge(dtTemp.DashboardNewFilesTable);
                            //dt.DashboardNewFilesTable = dtTemp.DashboardNewFilesTable.Copy();
                            //count++;
                        }
                        if (tagCount == 0)
                        {
                            dtTag.DashboardNewFilesTable = dtTemp.DashboardNewFilesTable.Copy();
                            tagCount++;
                        }
                        else
                        {
                            dtTag.DashboardNewFilesTable.Merge(dtTemp.DashboardNewFilesTable);
                        }
                    }
                }
                
                if (dt.DashboardNewFilesTable.Rows.Count > 0)
                {
                    var groupedData = from b in dtTag.DashboardNewFilesTable.AsEnumerable()
                                      group b by new
                                      {
                                          ContentType = b.Field<string>("Content Type"),
                                          ContentTypeId = b.Field<int>("ContentTypeId")
                                      } into g
                                      select new
                                      {
                                          TagId = g.Key.ContentTypeId,
                                          TagName = g.Key.ContentType,
                                          Count = g.Count()
                                      };
                    String encThisURL = String.Empty;
                    int counter = 0;
                    foreach (var item in groupedData)
                    {
                        encThisURL = "../dashboard/index.aspx?" + EncryptQueryString(String.Format("fileType:{0}^cType:{1}", "New", item.TagId));
                        if (ContentTypeId == 0 && counter == 0)
                        {
                            tagHtml += String.Format("<li><a style='background: rgb(7, 124, 150) none repeat scroll 0px 0px;' href='{2}' >{0} ({1})</a></li>", item.TagName, item.Count, encThisURL);
                            counter++;
                        }
                        else if (ContentTypeId == item.TagId && counter == 0)
                        {
                            tagHtml += String.Format("<li><a style='background: rgb(7, 124, 150) none repeat scroll 0px 0px;' href='{2}' >{0} ({1})</a></li>", item.TagName, item.Count, encThisURL);
                            counter++;
                        }
                        else
                            tagHtml += String.Format("<li><a href='{2}' >{0} ({1})</a></li>", item.TagName, item.Count, encThisURL);
                    }
                    ulNewTag.InnerHtml = tagHtml;
                    ////
                    dt.DashboardNewFilesTable = dt.DashboardNewFilesTable.AsEnumerable().Take(Convert.ToInt32(ConfigurationManager.AppSettings["DashboardRecordCount"].ToString())).CopyToDataTable();
                    html = "<table id='tblNew' width='100%' cellpadding='0' cellspacing='0' ><thead><tr>";
                    foreach (DataColumn dcol in dt.DashboardNewFilesTable.Columns)
                    {
                        if (dcol.ColumnName == "Confidential" || dcol.ColumnName == "DocId" || dcol.ColumnName == "ContentTypeId")
                        { }
                        else if (dcol.ColumnName == "SerialNo")
                        {
                            html += String.Format("<th>{0}</th>", "Doc No.");
                        }
                        else
                            html += String.Format("<th>{0}</th>", dcol.ColumnName);
                    }
                    html += String.Format("<th>{0}</th>", "");
                    html += "</tr></thead><tbody>";
                    String encURL = String.Empty;
                    foreach (DataRow row in dt.DashboardNewFilesTable.Rows)
                    {
                        html += "<tr>";
                        foreach (DataColumn column in dt.DashboardNewFilesTable.Columns)
                        {
                            if (column.ColumnName == "Confidential" || column.ColumnName == "DocId" || column.ColumnName == "ContentTypeId")
                            { }
                            //else if (column.ColumnName == "SerialNo")
                            //{
                            //    html += "<td>";
                            //    html += row[column.ColumnName];
                            //    html += "</td>";
                            //}
                            else if (column.ColumnName == "SerialNo")
                            {
                                if (row["Confidential"].ToString() == "Yes")
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += " &nbsp;<img class='lock' title='Locked' alt='Locked' src='../img/nav-icons/icon_lock.png'></td>";
                                }
                                else if (row["Confidential"].ToString() == "No")
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += "</td>";
                                }
                                else
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += "</td>";
                                }
                            }
                            else
                            {
                                html += "<td>";
                                html += row[column.ColumnName];
                                html += "</td>";
                            }
                        }
                        encURL = "../file-preview/index.aspx?" + EncryptQueryString(String.Format("fid={0}&docid={1}",0, row["DocId"]));
                        html += "<td>";
                        html += String.Format("<a href='{0}'><img src='../img/nav-icons/view.png' alt=''></a>", encURL);
                        html += "</td>";
                        html += "</tr>";
                    }
                    html += "</tbody></table>";
                    divNew.InnerHtml = html;
                }
                else
                {
                    //divConfirm.Attributes.Add("style", "display:none");
                    //divError.Attributes.Add("style", "display:block");
                    //confirmMsg.InnerHtml = "";
                    //errorMsg.InnerHtml = "No data found.";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        private void PopulateFileRecent(Int32 LibId, Int32 UserId, Int32 ContentTypeId)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.DashboardRecentFiles dt;
            DAMServices.DashboardRecentFiles dtTemp;
            DAMServices.DashboardRecentFiles dtTag;
            String html = String.Empty;
            String tagHtml = String.Empty;
            int count = 0;
            int tagCount = 0;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = new DAMServices.DashboardRecentFiles();
                dtTag = new DAMServices.DashboardRecentFiles();
                var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                var SearchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();
                for (int i = 0; i < SearchPrivilege.Count; i++)
                {
                    dtTemp = new DAMServices.DashboardRecentFiles();
                    String confidential = String.Empty;
                    switch (GetOtherPrivilege(SearchPrivilege[i].Permission))
                    {
                        case 0:
                            confidential = "False";
                            break;
                        case 1:
                            confidential = "No";
                            break;
                        case 2:
                            confidential = "Yes";
                            break;
                        case 3:
                            confidential = "";
                            break;
                    }
                    if (confidential != "False")
                    {
                        dtTemp = objDAM.GetDashboardRecentFiles(confidential, SearchPrivilege[i].ContentTypeId, LibId, UserId, TeamId, SearchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]));
                        if (count == 0 && dtTemp.DashboardRecentFilesTable.Rows.Count > 0)
                        {
                            if (ContentTypeId == 0)
                            {
                                dt.DashboardRecentFilesTable = dtTemp.DashboardRecentFilesTable.Copy();
                                count++;
                            }
                            else if (ContentTypeId == SearchPrivilege[i].ContentTypeId)
                            {
                                dt.DashboardRecentFilesTable = dtTemp.DashboardRecentFilesTable.Copy();
                                count++;
                            }
                        }
                        else
                        {
                            //dt.DashboardRecentFilesTable.Merge(dtTemp.DashboardRecentFilesTable);
                        }
                        if (tagCount == 0)
                        {
                            dtTag.DashboardRecentFilesTable = dtTemp.DashboardRecentFilesTable.Copy();
                            tagCount++;
                        }
                        else
                        {
                            dtTag.DashboardRecentFilesTable.Merge(dtTemp.DashboardRecentFilesTable);
                        }
                    }
                }
                
                if (dt.DashboardRecentFilesTable.Rows.Count > 0)
                {
                    var groupedData = from b in dtTag.DashboardRecentFilesTable.AsEnumerable()
                                      group b by new
                                      {
                                          ContentType = b.Field<string>("Content Type"),
                                          ContentTypeId = b.Field<int>("ContentTypeId")
                                      } into g
                                      select new
                                      {
                                          TagId = g.Key.ContentTypeId,
                                          TagName = g.Key.ContentType,
                                          Count = g.Count()
                                      };
                    int counter = 0;
                    String encThisURL = String.Empty;
                    foreach (var item in groupedData)
                    {
                        encThisURL = "../dashboard/index.aspx?" + EncryptQueryString(String.Format("fileType:{0}^cType:{1}", "Recent", item.TagId));
                        if (ContentTypeId == 0 && counter == 0)
                        {
                            tagHtml += String.Format("<li><a style='background: rgb(7, 124, 150) none repeat scroll 0px 0px;' href='{2}' >{0} ({1})</a></li>", item.TagName, item.Count, encThisURL);
                            counter++;
                        }
                        else if (ContentTypeId == item.TagId && counter == 0)
                        {
                            tagHtml += String.Format("<li><a style='background: rgb(7, 124, 150) none repeat scroll 0px 0px;' href='{2}' >{0} ({1})</a></li>", item.TagName, item.Count, encThisURL);
                            counter++;
                        }
                        else
                            tagHtml += String.Format("<li><a href='{2}' >{0} ({1})</a></li>", item.TagName, item.Count, encThisURL);
                    }
                    ulRecentTag.InnerHtml = tagHtml;
                    ///
                    dt.DashboardRecentFilesTable = dt.DashboardRecentFilesTable.AsEnumerable().Take(Convert.ToInt32(ConfigurationManager.AppSettings["DashboardRecordCount"].ToString())).CopyToDataTable();
                    String encURL = String.Empty;
                    html = "<table id='tblRecent' width='100%' cellpadding='0' cellspacing='0' ><thead><tr>";
                    foreach (DataColumn dcol in dt.DashboardRecentFilesTable.Columns)
                    {
                        if (dcol.ColumnName == "Confidential" || dcol.ColumnName == "DocId" || dcol.ColumnName == "ContentTypeId")
                        { }
                        else if (dcol.ColumnName == "SerialNo")
                        {
                            html += String.Format("<th>{0}</th>", "Doc No.");
                        }
                        else
                            html += String.Format("<th>{0}</th>", dcol.ColumnName);
                    }
                    html += String.Format("<th width='5px'>{0}</th>", "");
                    html += "</tr></thead><tbody>";
                    foreach (DataRow row in dt.DashboardRecentFilesTable.Rows)
                    {
                        html += "<tr>";
                        foreach (DataColumn column in dt.DashboardRecentFilesTable.Columns)
                        {
                            if (column.ColumnName == "Confidential" || column.ColumnName == "DocId" || column.ColumnName == "ContentTypeId")
                            { }
                            //else if (column.ColumnName == "SerialNo")
                            //{
                            //    html += "<td>";
                            //    html += row[column.ColumnName];
                            //    html += "</td>";
                            //}
                            else if (column.ColumnName == "SerialNo")
                            {
                                if (row["Confidential"].ToString() == "Yes")
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += " &nbsp;<img class='lock' title='Locked' alt='Locked' src='../img/nav-icons/icon_lock.png'></td>";
                                }
                                else if (row["Confidential"].ToString() == "No")
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += "</td>";
                                }
                                else
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += "</td>";
                                }
                            }
                            else
                            {
                                html += "<td>";
                                html += row[column.ColumnName];
                                html += "</td>";
                            }
                        }
                        encURL = "../file-preview/index.aspx?" + EncryptQueryString(String.Format("fid={0}&docid={1}", 0, row["DocId"]));
                        html += "<td>";
                        html += String.Format("<a href='{0}'><img src='../img/nav-icons/view.png' alt=''></a>", encURL);
                        html += "</td>";
                        html += "</tr>";
                    }
                    html += "</tbody></table>";
                    divRecent.InnerHtml = html;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtSearch.Value.Trim().Length == 0)
                return;
            Session["SearchText"] = txtSearch.Value.Trim();
            Response.Redirect("~/search-result/index.aspx?", false);
        }

        protected void btnExportMy_Click(Object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.DashboardNewFiles dt;
            DAMServices.DashboardNewFiles dtTemp;
            String html = String.Empty;
            int count = 0;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = new DAMServices.DashboardNewFiles();

                var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                var SearchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();
                for (int i = 0; i < SearchPrivilege.Count; i++)
                {
                    dtTemp = new DAMServices.DashboardNewFiles();
                    String confidential = String.Empty;
                    switch (GetSelfPrivilege(SearchPrivilege[i].Permission))
                    {
                        case 0:
                            confidential = "False";
                            break;
                        case 1:
                            confidential = "No";
                            break;
                        case 2:
                            confidential = "Yes";
                            break;
                        case 3:
                            confidential = "";
                            break;
                    }
                    if (confidential != "False")
                    {
                        dtTemp = objDAM.GetDashboardNewFiles(confidential, SearchPrivilege[i].ContentTypeId, LibId, UserId, TeamId, SearchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]));
                        if (count == 0)
                        {
                            dt.DashboardNewFilesTable = dtTemp.DashboardNewFilesTable.Copy();
                            count++;
                        }
                        else
                            dt.DashboardNewFilesTable.Merge(dtTemp.DashboardNewFilesTable);
                    }
                }

                if (dt.DashboardNewFilesTable.Rows.Count > 0)
                {
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ClearContent();
                    HttpContext.Current.Response.ClearHeaders();
                    HttpContext.Current.Response.Buffer = true;
                    HttpContext.Current.Response.ContentType = "application/ms-excel";                    
                    HttpContext.Current.Response.Write(@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.0 Transitional//EN"">");
                    HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=Export.xls");
                    HttpContext.Current.Response.Charset = "utf-8";
                    HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("windows-1250");
                    HttpContext.Current.Response.Write("<font style='font-size:10.0pt; font-family:Calibri;'>");
                    HttpContext.Current.Response.Write("<BR><BR><BR>");
                    HttpContext.Current.Response.Write("<Table border='1' bgColor='#ffffff' borderColor='#000000' cellSpacing='0' cellPadding='0' style='font-size:10.0pt; font-family:Calibri; background:white;'> <TR>");
                    int columnscount = dt.DashboardNewFilesTable.Columns.Count;
                    foreach (DataColumn column in dt.DashboardNewFilesTable.Columns)
                    {
                        if (column.ColumnName == "DocId" || column.ColumnName == "ContentTypeId")
                        {

                        }
                        else if (column.ColumnName == "SerialNo")
                        {
                            HttpContext.Current.Response.Write("<Td>");
                            HttpContext.Current.Response.Write("<B>");
                            HttpContext.Current.Response.Write("Doc No.");
                            HttpContext.Current.Response.Write("</B>");
                            HttpContext.Current.Response.Write("</Td>");
                        }
                        else 
                        {
                            HttpContext.Current.Response.Write("<Td>");
                            HttpContext.Current.Response.Write("<B>");
                            HttpContext.Current.Response.Write(column.ColumnName);
                            HttpContext.Current.Response.Write("</B>");
                            HttpContext.Current.Response.Write("</Td>");
                        }
                    }
                    HttpContext.Current.Response.Write("</TR>");
                    foreach (DataRow row in dt.DashboardNewFilesTable.Rows)
                    {
                        HttpContext.Current.Response.Write("<TR>");
                        for (int i = 1; i < dt.DashboardNewFilesTable.Columns.Count; i++)
                        {
                            HttpContext.Current.Response.Write("<Td>");
                            HttpContext.Current.Response.Write(row[i].ToString());
                            HttpContext.Current.Response.Write("</Td>");
                        }
                        HttpContext.Current.Response.Write("</TR>");
                    }
                    HttpContext.Current.Response.Write("</Table>");
                    HttpContext.Current.Response.Write("</font>");
                    HttpContext.Current.Response.Flush();
                    HttpContext.Current.Response.End();
                }
                else
                {
                    //divConfirm.Attributes.Add("style", "display:none");
                    //divError.Attributes.Add("style", "display:block");
                    //confirmMsg.InnerHtml = "";
                    //errorMsg.InnerHtml = "No data found.";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void btnExportOther_Click(Object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.DashboardRecentFiles dt;
            DAMServices.DashboardRecentFiles dtTemp;
            String html = String.Empty;
            int count = 0;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = new DAMServices.DashboardRecentFiles();

                var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                var SearchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();
                for (int i = 0; i < SearchPrivilege.Count; i++)
                {
                    dtTemp = new DAMServices.DashboardRecentFiles();
                    String confidential = String.Empty;
                    switch (GetOtherPrivilege(SearchPrivilege[i].Permission))
                    {
                        case 0:
                            confidential = "False";
                            break;
                        case 1:
                            confidential = "No";
                            break;
                        case 2:
                            confidential = "Yes";
                            break;
                        case 3:
                            confidential = "";
                            break;
                    }
                    if (confidential != "False")
                    {
                        dtTemp = objDAM.GetDashboardRecentFiles(confidential, SearchPrivilege[i].ContentTypeId, LibId, UserId, TeamId, SearchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]));
                        if (count == 0)
                        {
                            dt.DashboardRecentFilesTable = dtTemp.DashboardRecentFilesTable.Copy();
                            count++;
                        }
                        else
                            dt.DashboardRecentFilesTable.Merge(dtTemp.DashboardRecentFilesTable);
                    }
                }

                if (dt.DashboardRecentFilesTable.Rows.Count > 0)
                {
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ClearContent();
                    HttpContext.Current.Response.ClearHeaders();
                    HttpContext.Current.Response.Buffer = true;
                    HttpContext.Current.Response.ContentType = "application/ms-excel";
                    HttpContext.Current.Response.Write(@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.0 Transitional//EN"">");
                    HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=Export.xls");
                    HttpContext.Current.Response.Charset = "utf-8";
                    HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("windows-1250");
                    HttpContext.Current.Response.Write("<font style='font-size:10.0pt; font-family:Calibri;'>");
                    HttpContext.Current.Response.Write("<BR><BR><BR>");
                    HttpContext.Current.Response.Write("<Table border='1' bgColor='#ffffff' borderColor='#000000' cellSpacing='0' cellPadding='0' style='font-size:10.0pt; font-family:Calibri; background:white;'> <TR>");
                    int columnscount = dt.DashboardRecentFilesTable.Columns.Count;
                    foreach (DataColumn column in dt.DashboardRecentFilesTable.Columns)
                    {
                        if (column.ColumnName == "DocId" || column.ColumnName == "ContentTypeId")
                        {

                        }
                        else if (column.ColumnName == "SerialNo")
                        {
                            HttpContext.Current.Response.Write("<Td>");
                            HttpContext.Current.Response.Write("<B>");
                            HttpContext.Current.Response.Write("Doc No.");
                            HttpContext.Current.Response.Write("</B>");
                            HttpContext.Current.Response.Write("</Td>");
                        }
                        else
                        {
                            HttpContext.Current.Response.Write("<Td>");
                            HttpContext.Current.Response.Write("<B>");
                            HttpContext.Current.Response.Write(column.ColumnName);
                            HttpContext.Current.Response.Write("</B>");
                            HttpContext.Current.Response.Write("</Td>");
                        }
                    }
                    HttpContext.Current.Response.Write("</TR>");
                    foreach (DataRow row in dt.DashboardRecentFilesTable.Rows)
                    {
                        HttpContext.Current.Response.Write("<TR>");
                        for (int i = 1; i < dt.DashboardRecentFilesTable.Columns.Count; i++)
                        {
                            HttpContext.Current.Response.Write("<Td>");
                            HttpContext.Current.Response.Write(row[i].ToString());
                            HttpContext.Current.Response.Write("</Td>");
                        }
                        HttpContext.Current.Response.Write("</TR>");
                    }
                    HttpContext.Current.Response.Write("</Table>");
                    HttpContext.Current.Response.Write("</font>");
                    HttpContext.Current.Response.Flush();
                    HttpContext.Current.Response.End();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
        private string DecryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Decrypt(strQueryString, "r0b1nr0y");
        }   
    }
}