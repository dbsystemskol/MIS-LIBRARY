﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using log4net;
using System.Configuration;
using DAM.Apps.CommonClasses;
using System.IO;
using System.Web.Configuration;

namespace DAM.Apps.content_type
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));
        private Int32 UserId;

        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "System Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {
                PopulateContentTypeList();
            }
        }

        protected void PopulateContentTypeList()
        {
            DAMServices.ServiceContractClient obje;
            try
            {
                obje = new DAMServices.ServiceContractClient();
                var list = obje.GetAllContentType();
                gdvContentTypeMaster.DataSource = list; //.Where(x => x.TeamName != "System Administrator").ToList();
                gdvContentTypeMaster.DataBind();
                gdvContentTypeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
            }
        }

        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }

        #region "New Insert Or Update"

        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            txtContentTypeName.Value = "";
            hdnSelectTeamId.Value = "";
            if (gdvContentTypeMaster.Rows.Count > 0)
            {
                gdvContentTypeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            popup.Show();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient obje;
            DAMServices.ContentTypeMasterInfo dList;
            try
            {
                if (txtContentTypeName.Value != "")
                {
                    obje = new DAMServices.ServiceContractClient();
                    dList = new DAMServices.ContentTypeMasterInfo();
                    if (hdnSelectTeamId.Value != "")
                        dList.ContentTypeMasterId = Convert.ToInt32(hdnSelectTeamId.Value);
                    dList.Description = Server.HtmlEncode(txtContentTypeName.Value);
                    dList.CreatedBy = UserId;
                    dList.IPAddress = GetIPAddress();
                    if (dList.ContentTypeMasterId == 0)
                    {
                        Int32 Returnval = obje.InsertContentType(dList);
                        if (Returnval > 0)
                        {
                            PopulateContentTypeList();
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.DUPLICATE;
                        }
                    }
                    else
                    {
                        // Int32 Returnval = obje.UpdateTeamMaster(dList);
                        Int32 Returnval = obje.UpdateContentType(dList);
                        if (Returnval > 0)
                        {
                            PopulateContentTypeList();
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }
                    }
                }
                else
                {
                    popup.Show();
                    lblPopupMsg.InnerText = "Enter Team Name.";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
                dList = null;
            }
        }

        #endregion

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                gdvContentTypeMaster.DataSource = objDAM.GetContentTypeSearch(txtSearchContent.Value.Trim());
                gdvContentTypeMaster.DataBind();
                gdvContentTypeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void gdvContentTypeMaster_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnActive = (HiddenField)e.Row.FindControl("hdnActive");
                    Image imgActive = (Image)e.Row.FindControl("imgActive");
                    Image imgDeactive = (Image)e.Row.FindControl("imgDeactive");
                    imgActive.Visible = (hdnActive.Value == "True") ? true : false;
                    imgDeactive.Visible = (hdnActive.Value == "True") ? false : true;

                    Label lblContentTypeName = (Label)e.Row.FindControl("lblContentTypeName");
                    if (lblContentTypeName.Text == "System Administrator" || lblContentTypeName.Text == "Application Administrator")
                    {
                        LinkButton btnEdit = (LinkButton)e.Row.FindControl("btnEdit");
                        Image imgEdit = (Image)e.Row.FindControl("imgEdit");
                        btnEdit.Visible = false;
                        imgEdit.Visible = false;
                        imgActive.Visible = false;
                        imgDeactive.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {

            }
        }

        protected void gdvContentTypeMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.ContentTypeMasterInfo mData;
            try
            {
                if (UserId != 0)
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    mData = new DAMServices.ContentTypeMasterInfo();

                    if (e.CommandName == "_ActiveDeactive")
                    {
                        String[] CommandArgs = e.CommandArgument.ToString().Split(new char[] { '|' });
                        Int32 RowContentTypeId = Convert.ToInt32(CommandArgs[0]);
                        Boolean Status = Convert.ToBoolean(CommandArgs[1]);

                        mData.ContentTypeMasterId = RowContentTypeId;
                        mData.ModifiedBy = UserId;
                        mData.IPAddress = GetIPAddress();
                        mData.IsActive = (Status) ? false : true;
                        Int32 r = objDAM.ActivateDeactivateContentType(mData);
                        if (r > 0)
                        {
                            PopulateContentTypeList();
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }
                    }
                    if (e.CommandName == "_Edit")
                    {
                        Int32 RowContentTypeId = Convert.ToInt32(e.CommandArgument);
                        gdvContentTypeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
                        var mList = objDAM.GetContentTypeMasterById(RowContentTypeId);
                        hdnSelectTeamId.Value = mList[0].ContentTypeMasterId.ToString();
                        txtContentTypeName.Value = Server.HtmlDecode(mList[0].Description);
                        popup.Show();
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
                mData = null;
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (gdvContentTypeMaster.Rows.Count > 0)
                {
                    Response.ClearContent();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "ContentType.xls"));
                    Response.ContentType = "application/ms-excel";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter htw = new HtmlTextWriter(sw);
                    gdvContentTypeMaster.AllowPaging = false;
                    //Change the Header Row back to white color
                    gdvContentTypeMaster.HeaderRow.Style.Add("background-color", "#FFFFFF");
                    gdvContentTypeMaster.HeaderRow.Style.Add("color", "#fff");
                    for (int i = 0; i < gdvContentTypeMaster.HeaderRow.Cells.Count; i++)
                        gdvContentTypeMaster.HeaderRow.Cells[i].Style.Add("background-color", "#1B1BBA");
                    for (int i = 0; i < gdvContentTypeMaster.Columns.Count; i++)
                    {
                        if (gdvContentTypeMaster.Columns[i].HeaderText == "Active" || gdvContentTypeMaster.Columns[i].HeaderText == "Edit")
                            gdvContentTypeMaster.Columns[i].Visible = false;
                        if (gdvContentTypeMaster.Columns[i].HeaderText == "IsActive")
                            gdvContentTypeMaster.Columns[i].Visible = true;
                    }
                    gdvContentTypeMaster.RenderControl(htw);
                    Response.Write(sw.ToString());
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
    }
}