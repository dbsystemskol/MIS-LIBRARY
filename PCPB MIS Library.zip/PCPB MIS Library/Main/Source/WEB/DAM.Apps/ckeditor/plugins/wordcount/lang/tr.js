﻿/*
Mesut ÇAKIR
mesut.cakir@hotmail.com.tr
*/
CKEDITOR.plugins.setLang('wordcount', 'tr', {
    WordCount: 'Kelime:',
    CharCount: 'Karakter:',
    CharCountWithHTML: 'Karakter (HTML dahil):',
    Paragraphs: 'Paragraf:',
    title: 'İstatistik'
});
