﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using log4net;
using DAM.Apps.CommonClasses;
using System.IO;
using System.Web.Configuration;

namespace DAM.Apps.attribute_master
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));

        private Int32 UserId;
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            ////HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);
               
                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "System Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());
                UserId = Convert.ToInt32(Session["UserId"].ToString());
                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {
                PopulateAttributeMasterList();
            }
        }
        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }

        protected void PopulateAttributeMasterList()
        {
            DAMServices.ServiceContractClient obje;
            try
            {
                obje = new DAMServices.ServiceContractClient();
                gdvAttributeMaster.DataSource = obje.GetAllAttributeMaster();
                gdvAttributeMaster.DataBind();
                gdvAttributeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
            }
        }

        

        protected void gdvAttributeMaster_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnActive = (HiddenField)e.Row.FindControl("hdnActive");
                    LinkButton btnActive = (LinkButton)e.Row.FindControl("btnActive");
                    LinkButton btnDeactive = (LinkButton)e.Row.FindControl("btnDeactive");
                    Image imgActive = (Image)e.Row.FindControl("imgActive");
                    Image imgDeactive = (Image)e.Row.FindControl("imgDeactive");
                    if (hdnActive.Value == "True")
                    {
                        btnActive.Visible = true;
                        btnDeactive.Visible = false;
                        imgActive.Visible = true;
                        imgDeactive.Visible = false;
                    }
                    else
                    {
                        btnActive.Visible = false;
                        btnDeactive.Visible = true;
                        imgActive.Visible = false;
                        imgDeactive.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {

            }
        }

        protected void gdvAttributeMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.AttributeFieldsInfo mData;
            try
            {
                if (UserId != 0)
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    mData = new DAMServices.AttributeFieldsInfo();
                    if (e.CommandName == "_Active")
                    {
                        Int32 RowAFieldId = Convert.ToInt32(e.CommandArgument);
                        mData.FieldId = RowAFieldId;
                        mData.ModifiedBy = UserId;
                        mData.IPAddress = GetIPAddress();
                        mData.IsActive = false;
                        Int32 r = objDAM.ActivateDeactivateAttributeMaster(mData);
                        if (r > 0)
                        {
                            PopulateAttributeMasterList();
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }
                    }
                    if (e.CommandName == "_Deactive")
                    {
                        Int32 RowAFieldId = Convert.ToInt32(e.CommandArgument);
                        mData.FieldId = RowAFieldId;
                        mData.ModifiedBy = UserId;
                        mData.IPAddress = GetIPAddress();
                        mData.IsActive = true;
                        Int32 r = objDAM.ActivateDeactivateAttributeMaster(mData);
                        if (r > 0)
                        {
                            PopulateAttributeMasterList();
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }
                    }
                    if (e.CommandName == "_Edit")
                    {
                        Int32 RowFieldId = Convert.ToInt32(e.CommandArgument);
                        gdvAttributeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
                        var mList = objDAM.GetAttributeMasterById(RowFieldId);
                        hdnSelectFieldId.Value = mList[0].FieldId.ToString();
                        txtFieldName.Value = Server.HtmlDecode(mList[0].FieldName);
                        txtFieldCaption.Value = Server.HtmlDecode(mList[0].FieldCaption);
                        ddlFieldType.Value = mList[0].FieldType;
                        txtFieldWidth.Value = mList[0].FieldWidth.ToString();
                        ddlFieldCategory.Value = mList[0].FieldCategory;
                        txtDefaultValue.Value = Server.HtmlDecode(mList[0].DefaultValue);
                        rdoYes.Checked = (mList[0].AutoPopulate == true) ? true : false;
                        rdoNo.Checked = (mList[0].AutoPopulate == false) ? true : false;
                        popup.Show();
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
                mData = null;
            }
        }

        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            txtFieldCaption.Value = "";
            txtFieldName.Value = "";
            txtFieldWidth.Value = "";
            txtDefaultValue.Value = "";
            hdnSelectFieldId.Value = "0";
            if (gdvAttributeMaster.Rows.Count > 0)
            {
                gdvAttributeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            popup.Show();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            
            DAMServices.ServiceContractClient obje;
            DAMServices.AttributeFieldsInfo dList;
            try
            {
                obje = new DAMServices.ServiceContractClient();
                dList = new DAMServices.AttributeFieldsInfo();
                dList.FieldId = (hdnSelectFieldId.Value!="") ? Convert.ToInt32(hdnSelectFieldId.Value):0;
                dList.FieldName = Server.HtmlEncode(txtFieldName.Value);
                dList.FieldCaption = Server.HtmlEncode(txtFieldCaption.Value);
                dList.FieldType = ddlFieldType.Value;
                dList.FieldWidth = Convert.ToInt32(txtFieldWidth.Value);
                dList.FieldCategory = ddlFieldCategory.Value;
                dList.DefaultValue = Server.HtmlEncode(txtDefaultValue.Value);
                dList.AutoPopulate = (rdoYes.Checked) ? true: false;
                dList.CreatedBy = UserId;
                dList.IPAddress = GetIPAddress();
                if (dList.FieldId == 0)
                {
                    Int32 ReturnVal = obje.InsertAttributeMaster(dList);
                    if (ReturnVal > 0)
                    {
                        PopulateAttributeMasterList();
                        divConfirm.Attributes.Add("style", "display:block");
                        divError.Attributes.Add("style", "display:none");
                        confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                        errorMsg.InnerHtml = "";
                    }
                    else
                    {
                        divConfirm.Attributes.Add("style", "display:none");
                        divError.Attributes.Add("style", "display:block");
                        confirmMsg.InnerHtml = "";
                        errorMsg.InnerHtml = Constant.DUPLICATE;
                    }
                }
                else
                {
                    Int32 Returnval = obje.UpdateAttributeMaster(dList);
                    if (Returnval > 0)
                    {
                        PopulateAttributeMasterList();
                        divConfirm.Attributes.Add("style", "display:block");
                        divError.Attributes.Add("style", "display:none");
                        confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                        errorMsg.InnerHtml = "";
                    }
                    else
                    {
                        divConfirm.Attributes.Add("style", "display:none");
                        divError.Attributes.Add("style", "display:block");
                        confirmMsg.InnerHtml = "";
                        errorMsg.InnerHtml = Constant.EDIT_ERROR;
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
                dList = null;
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                gdvAttributeMaster.DataSource = objDAM.GetAttributeMasterSearch(Server.HtmlEncode(txtSearchTeam.Value.Trim()));
                gdvAttributeMaster.DataBind();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (gdvAttributeMaster.Rows.Count > 0)
                {
                    Response.ClearContent();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "Attribute.xls"));
                    Response.ContentType = "application/ms-excel";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter htw = new HtmlTextWriter(sw);
                    gdvAttributeMaster.AllowPaging = false;
                    //Change the Header Row back to white color
                    gdvAttributeMaster.HeaderRow.Style.Add("background-color", "#FFFFFF");
                    gdvAttributeMaster.HeaderRow.Style.Add("color", "#fff");
                    for (int i = 0; i < gdvAttributeMaster.HeaderRow.Cells.Count; i++)
                        gdvAttributeMaster.HeaderRow.Cells[i].Style.Add("background-color", "#1B1BBA");
                    for (int i = 0; i < gdvAttributeMaster.Columns.Count; i++)
                    {
                        if (gdvAttributeMaster.Columns[i].HeaderText == "Active" || gdvAttributeMaster.Columns[i].HeaderText == "Edit")
                            gdvAttributeMaster.Columns[i].Visible = false;
                        if (gdvAttributeMaster.Columns[i].HeaderText == "IsActive")
                            gdvAttributeMaster.Columns[i].Visible = true;
                    }
                    gdvAttributeMaster.RenderControl(htw);
                    Response.Write(sw.ToString());
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }

        protected void chkActiveAll_CheckedChanged(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.AttributeFieldsInfo mData;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                mData = new DAMServices.AttributeFieldsInfo();
                CheckBox chkActiveAll = (CheckBox)gdvAttributeMaster.HeaderRow.FindControl("chkActiveAll");
                mData.ModifiedBy = UserId;
                mData.IPAddress = GetIPAddress();
                mData.IsActive = (chkActiveAll.Checked) ? true : false;
                Int32 r = objDAM.ActivateDeactivateAttributeMasterAll(mData);
                if (r > 0)
                {
                    foreach (GridViewRow row in gdvAttributeMaster.Rows)
                    {
                        Image imgActive = (Image)row.FindControl("imgActive");
                        Image imgDeactive = (Image)row.FindControl("imgDeactive");
                        LinkButton btnActive = (LinkButton)row.FindControl("btnActive");
                        LinkButton btnDeactive = (LinkButton)row.FindControl("btnDeactive");

                        imgActive.Visible = (chkActiveAll.Checked) ? true : false;
                        imgDeactive.Visible = (chkActiveAll.Checked) ? false : true;
                        btnActive.Visible = (chkActiveAll.Checked) ? true : false;
                        btnDeactive.Visible = (chkActiveAll.Checked) ? false : true;
                    }
                    confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                    errorMsg.InnerHtml = "";
                }
                else
                {
                    confirmMsg.InnerHtml = "";
                    errorMsg.InnerHtml = Constant.EDIT_ERROR;
                }
                gdvAttributeMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
                mData = null;
            }
        }
    }
}