﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using log4net;
using System.Text;
using System.Configuration;
using DAM.Apps.CommonClasses;
using System.IO;
using System.Web.Configuration;
using QueryStringEncryption;

namespace DAM.Apps.email_setting
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));
        private Int32 UserId;
        private Int32 LibId;
        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }

        protected void PopulateEmailSettingsMasterList(Int32 TeamId)
        {
            DAMServices.ServiceContractClient obje;
            try
            {
                obje = new DAMServices.ServiceContractClient();
                gdvEmailSettingsMaster.DataSource = obje.GetAllEmailSettingsMaster(TeamId);
                gdvEmailSettingsMaster.DataBind();
                gdvEmailSettingsMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
            }
        }

        private void BindMenu(Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                StringBuilder sb = new StringBuilder();
                var list = objDAM.GetAllActiveAttributeMasterLookupList()
                                    .Where(x => x.LibId == 0 || x.LibId == LibId)
                                    .GroupBy(g => g.FieldId)
                                    .Select(g => new
                                    {
                                        FieldId = g.Key,
                                        FieldName = g.First().FieldName
                                    });
                sb.Append("<ul>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../sys-user-master/index.aspx'>Manage User</a></li>");
                sb.Append("<li><img src='../img/nav-icons/file-type.png' alt='' /><a href='../sys-user-in-team/index.aspx'>User with Team</a></li>");
                int i = 0;
                foreach (var l in list)
                {
                    if (l.FieldName != "Confidential")
                    {
                        if (i == 0)
                            hdnFieldId.Value = l.FieldId.ToString();
                        sb.AppendFormat("<li><img src='../img/nav-icons/brand.png' alt='' /><a href='../sys-admin/index.aspx?{1}'>{0}</a></li>", l.FieldName, EncryptQueryString(String.Format("fid={0}^fname={1}", l.FieldId, l.FieldName)));
                        i++;
                    }
                }
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../email-setting/index.aspx'>Manage Email Setting</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../email-template/index.aspx'>Manage Email Template</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-master/index.aspx'>Manage Email Event</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-in-template/index.aspx'>Manage Event with template</a></li>");
                sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-object-mapping/index.aspx'>Manage Event with lookup</a></li>");
                sb.Append("</ul>");
                divMenu.InnerHtml = sb.ToString();
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }
        }
        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                UserId = Convert.ToInt32(Session["UserId"].ToString());
                LibId = Convert.ToInt32(Session["LibId"].ToString());
                if (Session["TeamName"] == null)
                {
                    Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                }
            }
            else
            {
                Response.Redirect("~/Default.aspx", false);
            }
            if (!IsPostBack)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);
                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                HeaderFieldName.InnerText = "Email Settings";
                BindMenu(LibId);
                PopulateTeam();
                PopulateEmailSettingsMasterList(Convert.ToInt32(ddlTeam.SelectedValue));
            }
        }
        private void PopulateTeam()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var list = objDAM.GetAllActiveTeamMaster();
                ddlTeam.DataSource = list.Where(x => x.TeamName != "System Administrator").ToList();
                ddlTeam.DataValueField = "TeamId";
                ddlTeam.DataTextField = "TeamName";
                ddlTeam.DataBind();
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
        }
        protected void chkAll_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow Row = ((GridViewRow)((Control)sender).Parent.Parent);
            CheckBox chkAll = (CheckBox)Row.FindControl("chkAll");
            CheckBox chkIsUpload = (CheckBox)Row.FindControl("chkIsUpload");
            CheckBox chkIsEdit = (CheckBox)Row.FindControl("chkIsEdit");
            CheckBox chkIsDelete = (CheckBox)Row.FindControl("chkIsDelete");
            CheckBox chkIsOnExpiry = (CheckBox)Row.FindControl("chkIsOnExpiry");
            if (chkAll.Checked)
            {
                chkIsUpload.Checked = true;
                chkIsEdit.Checked = true;
                chkIsDelete.Checked = true;
                chkIsOnExpiry.Checked = true;
            }
            else
            {
                chkIsUpload.Checked = false;
                chkIsEdit.Checked = false;
                chkIsDelete.Checked = false;
                chkIsOnExpiry.Checked = false;
            }
            gdvEmailSettingsMaster.HeaderRow.TableSection = TableRowSection.TableHeader;

        }
        protected void chkAllUpload_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkAllUpload = (CheckBox)gdvEmailSettingsMaster.HeaderRow.FindControl("chkAllUpload");
            foreach (GridViewRow row in gdvEmailSettingsMaster.Rows)
            {
                CheckBox chkIsUpload = (CheckBox)row.FindControl("chkIsUpload");
                if (chkAllUpload.Checked == true)
                {
                    chkIsUpload.Checked = true;
                }
                else
                {
                    chkIsUpload.Checked = false;
                }
            }
            gdvEmailSettingsMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            
        }

        protected void chkAllEdit_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkAllEdit = (CheckBox)gdvEmailSettingsMaster.HeaderRow.FindControl("chkAllEdit");
            foreach (GridViewRow row in gdvEmailSettingsMaster.Rows)
            {
                CheckBox chkIsEdit = (CheckBox)row.FindControl("chkIsEdit");
                if (chkAllEdit.Checked == true)
                {
                    chkIsEdit.Checked = true;
                }
                else
                {
                    chkIsEdit.Checked = false;
                }
            }
            gdvEmailSettingsMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            
        }

        protected void chkAllDelete_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkAllDelete = (CheckBox)gdvEmailSettingsMaster.HeaderRow.FindControl("chkAllDelete");
            foreach (GridViewRow row in gdvEmailSettingsMaster.Rows)
            {
                CheckBox chkIsDelete = (CheckBox)row.FindControl("chkIsDelete");
                if (chkAllDelete.Checked == true)
                {
                    chkIsDelete.Checked = true;
                }
                else
                {
                    chkIsDelete.Checked = false;
                }
            }
            gdvEmailSettingsMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            
        }

        protected void chkAll30Days_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkAll30Days = (CheckBox)gdvEmailSettingsMaster.HeaderRow.FindControl("chkAll30Days");
            foreach (GridViewRow row in gdvEmailSettingsMaster.Rows)
            {
                CheckBox chkIs30Days = (CheckBox)row.FindControl("chkIs30Days");
                if (chkAll30Days.Checked == true)
                {
                    chkIs30Days.Checked = true;
                }
                else
                {
                    chkIs30Days.Checked = false;
                }
            }
            gdvEmailSettingsMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            
        }

        protected void chkAllOnExpiry_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkAllOnExpiry = (CheckBox)gdvEmailSettingsMaster.HeaderRow.FindControl("chkAllOnExpiry");
            foreach (GridViewRow row in gdvEmailSettingsMaster.Rows)
            {
                CheckBox chkIsOnExpiry = (CheckBox)row.FindControl("chkIsOnExpiry");
                if (chkAllOnExpiry.Checked == true)
                {
                    chkIsOnExpiry.Checked = true;
                }
                else
                {
                    chkIsOnExpiry.Checked = false;
                }
            }
            gdvEmailSettingsMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            if (gdvEmailSettingsMaster.Rows.Count > 0)
            {
                try
                {
                    String strEmSetDetails = String.Empty;
                    for (int i = 0; i < gdvEmailSettingsMaster.Rows.Count; i++)
                    {
                        CheckBox chkIsUpload = (CheckBox)gdvEmailSettingsMaster.Rows[i].FindControl("chkIsUpload");
                        CheckBox chkIsEdit = (CheckBox)gdvEmailSettingsMaster.Rows[i].FindControl("chkIsEdit");
                        CheckBox chkIsDelete = (CheckBox)gdvEmailSettingsMaster.Rows[i].FindControl("chkIsDelete");
                        CheckBox chkIsOnExpiry = (CheckBox)gdvEmailSettingsMaster.Rows[i].FindControl("chkIsOnExpiry");
                        Label lblUserId = (Label)gdvEmailSettingsMaster.Rows[i].FindControl("lblUserId");
                        strEmSetDetails += String.Format("{0},{1},{2},{3},{4},{5},{6},{7}|", UserId, lblUserId.Text, (chkIsUpload.Checked) ? "true" : "false", (chkIsEdit.Checked) ? "true" : "false",
                                                            (chkIsDelete.Checked) ? "true" : "false", (chkIsOnExpiry.Checked) ? "true" : "false", UserId, GetIPAddress());
                    }
                    if (strEmSetDetails != "")
                    {
                        strEmSetDetails = strEmSetDetails.Remove(strEmSetDetails.Length - 1);
                        if (strEmSetDetails != "")
                        {
                            objDAM = new DAMServices.ServiceContractClient();
                            objDAM.InsertEmailSettingsMaster(strEmSetDetails,Convert.ToInt32(ddlTeam.SelectedValue));
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            confirmMsg.InnerHtml = "";
                            divError.Attributes.Add("style", "display:block");
                            divConfirm.Attributes.Add("style", "display:none");
                            errorMsg.InnerHtml = Constant.ADD_ERROR;
                        }
                        PopulateEmailSettingsMasterList(Convert.ToInt32(ddlTeam.SelectedValue));
                    }
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
            }
            else
            {
                confirmMsg.InnerHtml = "";
                divError.Attributes.Add("style", "display:block");
                divConfirm.Attributes.Add("style", "display:none");
                errorMsg.InnerHtml = Constant.DATA_NOT_FOUND;
            }
        }
        protected void ddlTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateEmailSettingsMasterList(Convert.ToInt32(ddlTeam.SelectedValue));
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                gdvEmailSettingsMaster.DataSource = objDAM.GetEmailSettingsMasterSearch(Server.HtmlEncode(txtSearchUser.Value.Trim()));
                gdvEmailSettingsMaster.DataBind();
                gdvEmailSettingsMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (gdvEmailSettingsMaster.Rows.Count > 0)
                {
                    Response.ClearContent();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "EmailSettings.xls"));
                    Response.ContentType = "application/ms-excel";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter htw = new HtmlTextWriter(sw);
                    gdvEmailSettingsMaster.AllowPaging = false;
                    //Change the Header Row back to white color
                    gdvEmailSettingsMaster.HeaderRow.Style.Add("background-color", "#FFFFFF");
                    gdvEmailSettingsMaster.HeaderRow.Style.Add("color", "#fff");
                    for (int i = 0; i < gdvEmailSettingsMaster.HeaderRow.Cells.Count; i++)
                        gdvEmailSettingsMaster.HeaderRow.Cells[i].Style.Add("background-color", "#1B1BBA");
                    //for (int i = 0; i < gdvEmailSettingsMaster.Columns.Count; i++)
                    //{
                    //    if (gdvEmailSettingsMaster.Columns[i].HeaderText == "Active" || gdvEmailSettingsMaster.Columns[i].HeaderText == "Edit")
                    //        gdvEmailSettingsMaster.Columns[i].Visible = false;
                    //    if (gdvEmailSettingsMaster.Columns[i].HeaderText == "IsActive")
                    //        gdvEmailSettingsMaster.Columns[i].Visible = true;
                    //}
                    gdvEmailSettingsMaster.RenderControl(htw);
                    Response.Write(sw.ToString());
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
    }
}