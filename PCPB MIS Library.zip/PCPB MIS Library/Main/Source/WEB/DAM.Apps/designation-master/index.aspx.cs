﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using log4net;
using DAM.Apps.CommonClasses;
using System.IO;
using System.Configuration;
using System.Web.Configuration;
using System.Text;
using QueryStringEncryption;

namespace DAM.Apps.designation_master
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));
        private Int32 UserId;
        private Int32 LibId;
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);
                
                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() == "System Administrator" || Session["TeamName"].ToString() == "Application Administrator")
                    {

                    }
                    else
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());
                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
                LibId = Convert.ToInt32(Session["LibId"].ToString());
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {
                BindMenu(LibId);
                PopulateDesignationMasterList();
            }
        }
        private void BindMenu(Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                StringBuilder sb = new StringBuilder();
                var list = objDAM.GetAllActiveAttributeMasterLookupList()
                                    .Where(x => x.LibId == 0 || x.LibId == LibId)
                                    .GroupBy(g => g.FieldId)
                                    .Select(g => new
                                    {
                                        FieldId = g.Key,
                                        FieldName = g.First().FieldName
                                    });
                if (Session["TeamName"].ToString() == "Application Administrator")
                {
                    sb.Append("<ul>");
                    sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../sys-user-master/index.aspx'>Manage User</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/file-type.png' alt='' /><a href='../sys-user-in-team/index.aspx'>User with Team</a></li>");
                    int i = 0;
                    foreach (var l in list)
                    {
                        if (l.FieldName != "Confidential")
                        {
                            if (i == 0)
                                hdnFieldId.Value = l.FieldId.ToString();
                            sb.AppendFormat("<li><img src='../img/nav-icons/brand.png' alt='' /><a href='../sys-admin/index.aspx?{1}'>{0}</a></li>", l.FieldName, EncryptQueryString(String.Format("fid={0}^fname={1}", l.FieldId, l.FieldName)));
                            i++;
                        }
                    }
                    sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../brand-category-mapping/index.aspx'>Brand Category Mail Mapping</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../user-brand-category-mapping/index.aspx'>User Brand Category Mapping</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../email-log/index.aspx'>Email Log</a></li>");
                    sb.Append("</ul>");
                }
                else if (Session["TeamName"].ToString() == "System Administrator")
                {
                    sb.Append("<ul>");
                    sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../user-master/index.aspx'>Manage User</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/team.png' alt='' /><a href='../team-master/index.aspx'>Manage Team</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/file-type.png' alt='' /><a href='../user-in-team/index.aspx'>User with Team</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/varient.png' alt='' /><a href='../privilege-master/index.aspx'>Manage Privilege</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/category.png' alt='' /><a href='../team-in-privilege/index.aspx'>Team Privilege</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/category.png' alt='' /><a href='../content-type/index.aspx'>Content Type</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/brand.png' alt='' /><a href='../attribute-master/index.aspx'>Attribute Set</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/lookup.png' alt='' /><a href='../lookup-master/index.aspx'>Lookup</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/library.png' alt='' /><a href='../library-master/index.aspx'>Library</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/library.png' alt='' /><a href='../team-in-library/index.aspx'>Team with Library</a></li>");

                    sb.Append("<li><img src='../img/nav-icons/file-type.png' alt='' /><a href='../file-extension/index.aspx'>Manage File-extension</a></li>");

                    sb.Append("<li><img src='../img/nav-icons/Location.png' alt='' /><a href='../location-master/index.aspx'>Manage Location</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/Department.png' alt='' /><a href='../department-master/index.aspx'>Manage Department</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/designation.png' alt='' /><a href='../designation-master/index.aspx'>Manage Designation</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/designation.png' alt='' /><a href='../group-master/index.aspx'>Manage Group</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../email-template/index.aspx'>Manage Email Template</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-master/index.aspx'>Manage Email Event</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-in-template/index.aspx'>Manage Event with template</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/user.png' alt='' /><a href='../event-object-mapping/index.aspx'>Manage Event with lookup</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/lookup.png' alt='' /><a href='../actitity-log/index.aspx'>Log</a></li>");
                    sb.Append("<li><img src='../img/nav-icons/lookup.png' alt='' /><a href='../error-log/index.aspx'>Error Log</a></li>");
                    sb.Append("</ul>");
                }
                divMenu.InnerHtml = sb.ToString();
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }
        }
        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }

        protected void PopulateDesignationMasterList()
        {
            DAMServices.ServiceContractClient obje;
            try
            {
                obje = new DAMServices.ServiceContractClient();
                gdvDesignationMaster.DataSource = obje.GetAllDesignationMaster();
                gdvDesignationMaster.DataBind();
                gdvDesignationMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
            }
        }

        

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                gdvDesignationMaster.DataSource = objDAM.GetDesignationMasterSearch(Server.HtmlEncode(txtSearchDesignation.Value.Trim()));
                gdvDesignationMaster.DataBind();
                gdvDesignationMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            txtDesignation.Value = "";
            hdnSelectDesignationId.Value = "";
            if (gdvDesignationMaster.Rows.Count > 0)
            {
                gdvDesignationMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            popup.Show();
        }

        protected void gdvDesignationMaster_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnActive = (HiddenField)e.Row.FindControl("hdnActive");
                    Image imgActive = (Image)e.Row.FindControl("imgActive");
                    Image imgDeactive = (Image)e.Row.FindControl("imgDeactive");
                    imgActive.Visible = (hdnActive.Value == "True") ? true : false;
                    imgDeactive.Visible = (hdnActive.Value == "True") ? false : true;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {

            }
        }

        protected void gdvDesignationMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.DesignationMasterInfo mData;
            try
            {
                if (UserId != 0)
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    mData = new DAMServices.DesignationMasterInfo();

                    if (e.CommandName == "_ActiveDeactive")
                    {
                        String[] CommandArgs = e.CommandArgument.ToString().Split(new char[] { '|' });
                        Int32 RowADesignationId = Convert.ToInt32(CommandArgs[0]);
                        Boolean Status = Convert.ToBoolean(CommandArgs[1]);

                        mData.DesignationId = RowADesignationId;
                        mData.ModifiedBy = UserId;
                        mData.IPAddress = GetIPAddress();
                        mData.IsActive = (Status) ? false : true;
                        Int32 r = objDAM.ActivateDeactivateDesignationMaster(mData);
                        if (r > 0)
                        {
                            PopulateDesignationMasterList();
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }

                    }
                    if (e.CommandName == "_Edit")
                    {
                        Int32 RowDesignationId = Convert.ToInt32(e.CommandArgument);
                        gdvDesignationMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
                        var mList = objDAM.GetDesignationMasterById(RowDesignationId);
                        hdnSelectDesignationId.Value = mList[0].DesignationId.ToString();
                        txtDesignation.Value = Server.HtmlDecode(mList[0].Designation);
                        popup.Show();
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
                mData = null;
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient obje;
            DAMServices.DesignationMasterInfo dList;
            try
            {
                if (txtDesignation.Value != "")
                {
                    obje = new DAMServices.ServiceContractClient();
                    dList = new DAMServices.DesignationMasterInfo();
                    if (hdnSelectDesignationId.Value != "")
                        dList.DesignationId = Convert.ToInt32(hdnSelectDesignationId.Value);
                    dList.Designation = Server.HtmlEncode(txtDesignation.Value);
                    dList.CreatedBy = UserId;
                    dList.IPAddress = GetIPAddress();
                    if (dList.DesignationId == 0)
                    {
                        Int32 Returnval = obje.InsertDesignationMaster(dList);
                        if (Returnval > 0)
                        {
                            PopulateDesignationMasterList();
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.DUPLICATE;
                        }
                    }
                    else
                    {
                        Int32 Returnval = obje.UpdateDesignationMaster(dList);
                        if (Returnval > 0)
                        {
                            PopulateDesignationMasterList();
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divConfirm.Attributes.Add("style", "display:none");
                            divError.Attributes.Add("style", "display:block");
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }
                    }
                }
                else
                {
                    popup.Show();
                    lblPopupMsg.InnerText = "Enter Designation Name.";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
                dList = null;
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (gdvDesignationMaster.Rows.Count > 0)
                {
                    Response.ClearContent();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "Designation.xls"));
                    Response.ContentType = "application/ms-excel";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter htw = new HtmlTextWriter(sw);
                    gdvDesignationMaster.AllowPaging = false;
                    //Change the Header Row back to white color
                    gdvDesignationMaster.HeaderRow.Style.Add("background-color", "#FFFFFF");
                    gdvDesignationMaster.HeaderRow.Style.Add("color", "#fff");
                    for (int i = 0; i < gdvDesignationMaster.HeaderRow.Cells.Count; i++)
                        gdvDesignationMaster.HeaderRow.Cells[i].Style.Add("background-color", "#1B1BBA");
                    for (int i = 0; i < gdvDesignationMaster.Columns.Count; i++)
                    {
                        if (gdvDesignationMaster.Columns[i].HeaderText == "Active" || gdvDesignationMaster.Columns[i].HeaderText == "Edit")
                            gdvDesignationMaster.Columns[i].Visible = false;
                        if (gdvDesignationMaster.Columns[i].HeaderText == "IsActive")
                            gdvDesignationMaster.Columns[i].Visible = true;
                    }
                    gdvDesignationMaster.RenderControl(htw);
                    Response.Write(sw.ToString());
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
    }
}