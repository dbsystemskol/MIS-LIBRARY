// JavaScript Document

$(function () {

    if ($(window).width() > 768) {
        // Hide all but first tab content on larger viewports
        $('.accordion__content:not(:first)').hide();

        // Activate first tab
        $('.accordion__title:first-child').addClass('active');

    } else {
        // Hide all content items on narrow viewports
        $('.accordion__content:last-child').hide();
    };

    // Wrap a div around content to create a scrolling container which we're going to use on narrow viewports
    $(".accordion__content").wrapInner("<div class='overflow-scrolling'></div>");

    // The clicking action
    $('.accordion__title').on('click', function () {
        $('.accordion__content').hide();
        $(this).next().show().prev().addClass('active').siblings().removeClass('active');

    });
    // table row color odd/even
    $(".accordion__content table tbody tr:even").css("background-color", "#fafafa");
    $(".accordion__content table tbody tr:odd").css("background-color", "#ffffff");

    $(".modaltbl tr:even").css("background-color", "#fafafa");
    $(".modaltbl tr:odd").css("background-color", "#ffffff");

    $("#searchResult tr:even").css("background-color", "#fafafa");
    $("#searchResult tr:odd").css("background-color", "#ffffff");

    $(".leftNav").css({ 'height': $('.rightContainer').height() });
    $('.accordion__title').each(function () {
        $(this).click(function () {
            //alert($('.rightContainer').height());
            $(".leftNav").css({
                'height': $('.rightContainer').height()
            });
            return false;
        });
    });



    $("#dflt").hide();
    $("#colps").show();
    $(".leftNav").css('width', '48px');
    //$('.itc_logo').hide();
    $("#colps").css('margin-left', '6px');
    $(".leftNav ul li a").css('display', 'none');
    $('.leftNav ul li').css('margin-top', '-4px');
    $('.leftNav ul li:first-child').css('margin-top', '0px');

    $("#colps").click(function () {
        $(this).hide();
        $("#dflt").show();
        $("#dflt").css({
            'margin-left': '200px',
            'position': 'absolute',
            'z-index': '9999'
        });
        $(".leftNav").css({
            'width': '224px',
            'z-index': '9999',
            'opacity': '1'
        });
        $(".leftNav ul li a").css('display', 'block');
        $('.itc_logo').show();
        $('.itc_logo').css('top', '0px');
        $('.leftNav ul li').css('margin-top', '0px');
        return false;
    });

    $("#dflt").click(function () {
        $(this).hide();
        $("#colps").show();
        $(".leftNav").css('width', '48px');
        //$('.itc_logo').hide();
        $("#colps").css('margin-left', '6px');
        $(".leftNav ul li a").css('display', 'none');
        $('.leftNav ul li').css('margin-top', '-4px');
        $('.leftNav ul li:first-child').css('margin-top', '0px');
        $('.itc_logo').css('top', '-50px');
        return false;
    });
    //

    // date picker ends //



    // advanced search interaction//

    var $allID = $('#title, #party, #partyCode, #poNumber, #execution, #start, #finished, #value, #status, #duration, #flieType, #release, #creative, #music, #singer, #ip, #production, #director, #model, #musicDirector');
    $($allID).hide();


    $(".leftNav").css({ 'height': $('.rightContainer').height() });

    $("#RadioGroup1_0").click(function () {
        $($allID).hide();
        $("#dateForm").show();
    });
    $("#RadioGroup1_1").click(function () {
        $('#duration, #flieType, #release, #creative,#production, #director, #model, #musicDirector').show();
        $("#dateForm,#singer").hide();
    });
    $("#RadioGroup1_2").click(function () {
        $('#production, #director, #model, #dateForm,#ip').hide();
        $(" #musicDirector, #singer, #duration,#flieType,#release,#creative").show();
    });
    $("#RadioGroup1_3").click(function () {
        $($allID).hide();
        $(" #release, #creative, #music,#singer,#ip").show();
    });
    $("#RadioGroup1_4").click(function () {
        $($allID).hide();
        $(" #title, #party, #partyCode,#poNumber,#execution,#start,#finished,#value,#status").show();
        $("#dateForm").hide();
    });
    $(".tableAdvancedSearch fieldset input").each(function () {
        $(this).click(function () {
            $(".leftNav").css({ 'height': $('.rightContainer').height() });
        });
    });
    //
    //		$(".breadcrumb ul li a:first-child").click(function(){
    //			parent.history.back();
    //        	return false;
    //			});

    // image thumb download //
    $(".thumbImgDownload").hide();
    $(".searchResultThumb,.thumbImgDownload").mouseenter(function () {
        $(".thumbImgDownload").show();
    });
    $(".searchResultThumb,.thumbImgDownload").mouseleave(function () {
        $(".thumbImgDownload").hide();
    });
    //

    // image thumb upload //
    $(".thumbImgDownload1").hide();
    $(".uploadResultThumb,.thumbImgDownload1").mouseenter(function () {
        $(".thumbImgDownload1").show();
    });
    $(".uploadResultThumb,.thumbImgDownload1").mouseleave(function () {
        $(".thumbImgDownload1").hide();
    });
    //
    // step by step code //
    $(".stepFormHolder > div").hide();
    $(".stepFormHolder > div").eq(0).show();

    //$('.stepFormHolder div:gt(0)').hide();

    //    $("#nxt1").click(function () {
    //        $('.one').hide();
    //        $('.two').show();
    //        $('.stepContainer span').eq(0).addClass('circleStateVisited');
    //        $('.stepContainer span').eq(1).addClass('circleStateActive');
    //    });

    //    $("#nxt2").click(function () {
    //        $('.two').hide();
    //        $('.three').show();
    //        $('.stepContainer span').eq(1).addClass('circleStateVisited');
    //        $('.stepContainer span').eq(2).addClass('circleStateActive');
    //    });

    //    $("#nxt3").click(function () {
    //        $('.three').hide();
    //        $('.four').show();
    //        $('.stepContainer span').eq(2).addClass('circleStateVisited');
    //        $('.stepContainer span').eq(3).addClass('circleStateActive');
    //    });
});