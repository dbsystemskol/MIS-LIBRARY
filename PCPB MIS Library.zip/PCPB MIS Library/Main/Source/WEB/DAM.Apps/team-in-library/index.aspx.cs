﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using log4net;
using System.Configuration;
using DAM.Apps.CommonClasses;
using System.IO;
using System.Web.Configuration;

namespace DAM.Apps.team_in_library
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));
        private Int32 UserId;
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "System Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {
                PopulateAllTeamInLibrary();
            }
        }
        protected void PopulateAllTeamInLibrary()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                gdvTeamInLibrary.DataSource = objDAM.GetAllTeamInLibrary();
                gdvTeamInLibrary.DataBind();
                gdvTeamInLibrary.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void PopulateLibrary()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                ddlLibrary.DataSource = objDAM.GetAllActiveLibraryMaster();
                ddlLibrary.DataValueField = "LibId";
                ddlLibrary.DataTextField = "LibName";
                ddlLibrary.DataBind();
                ddlLibrary.Items.Insert(0, new ListItem("---- Select Library ----", "0"));
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        

        protected void gdvTeamInLibrary_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnActive = (HiddenField)e.Row.FindControl("hdnActive");
                    Image imgActive = (Image)e.Row.FindControl("imgActive");
                    Image imgDeactive = (Image)e.Row.FindControl("imgDeactive");
                    imgActive.Visible = (hdnActive.Value == "True") ? true : false;
                    imgDeactive.Visible = (hdnActive.Value == "True") ? false : true;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {

            }
        }

        protected void gdvTeamInLibrary_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.TeamInLibraryInfo mData;
            try
            {
                if (UserId != 0)
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    mData = new DAMServices.TeamInLibraryInfo();


                    if (e.CommandName == "_ActiveDeactive")
                    {
                        String[] CommandArgs = e.CommandArgument.ToString().Split(new char[] { '|' });
                        Int32 RowTeamInLibId = Convert.ToInt32(CommandArgs[0]);
                        Boolean Status = Convert.ToBoolean(CommandArgs[1]);

                        mData.TeamInLibraryId = RowTeamInLibId;
                        mData.ModifiedBy = UserId;
                        mData.IPAddress = GetIPAddress();
                        mData.IsActive = (Status) ? false : true;
                        Int32 r = objDAM.ActivateDeactivateTeamInLibrary(mData);
                        if (r > 0)
                        {
                            PopulateAllTeamInLibrary();
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }
                    }                    
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
                mData = null;
            }
        }

        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            PopulateLibrary();
            ddlLibrary.SelectedValue = "0";
            if(gdvTeamInLibrary.Rows.Count>0)
                gdvTeamInLibrary.HeaderRow.TableSection = TableRowSection.TableHeader;
            gdvTeam.DataSource = null;
            gdvTeam.DataBind();
            popup.Show();
        }

        protected void ddlLibrary_SelectedIndexChanged(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            if (ddlLibrary.SelectedIndex > 0)
            {
                try
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    gdvTeam.DataSource = objDAM.GetAllTeamNotInLibraryById(Convert.ToInt32(ddlLibrary.SelectedValue)).Where(x => x.TeamName != "System Administrator").ToList();
                    gdvTeam.DataBind();
                    gdvTeam.HeaderRow.TableSection = TableRowSection.TableHeader;
                    popup.Show();
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
            }
            else
            {
                gdvTeam.DataSource = null;
                gdvTeam.DataBind();
                gdvTeam.HeaderRow.TableSection = TableRowSection.TableHeader;
                popup.Show();
            }
        }

        protected void chkSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkSelectAll = (CheckBox)gdvTeam.HeaderRow.FindControl("chkSelectAll");
            foreach (GridViewRow row in gdvTeam.Rows)
            {
                CheckBox chkAdd = (CheckBox)row.FindControl("chkAdd");
                if (chkSelectAll.Checked == true)
                {
                    chkAdd.Checked = true;
                }
                else
                {
                    chkAdd.Checked = false;
                }
            }
            gdvTeam.HeaderRow.TableSection = TableRowSection.TableHeader;
            popup.Show();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            if (gdvTeam.Rows.Count > 0)
            {
                try
                {
                    String strTmInLibDetails = String.Empty;
                    for (int i = 0; i < gdvTeam.Rows.Count; i++)
                    {
                        CheckBox chkAdd = (CheckBox)gdvTeam.Rows[i].FindControl("chkAdd");
                        HiddenField hdnTeamId = (HiddenField)gdvTeam.Rows[i].FindControl("hdnTeamId");
                        if (chkAdd.Checked)
                        {
                            strTmInLibDetails += hdnTeamId.Value + "," + ddlLibrary.SelectedValue + "," + UserId + "," + GetIPAddress() + "|";
                        }
                    }
                    if (strTmInLibDetails != "")
                    {
                        strTmInLibDetails = strTmInLibDetails.Remove(strTmInLibDetails.Length - 1);
                        if (strTmInLibDetails != "")
                        {
                            objDAM = new DAMServices.ServiceContractClient();
                            objDAM.InsertTeamInLibraryMaster(strTmInLibDetails);
                            divConfirm.Attributes.Add("style", "display:block");
                            divError.Attributes.Add("style", "display:none");
                            confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            divError.Attributes.Add("style", "display:block");
                            divConfirm.Attributes.Add("style", "display:none");
                            errorMsg.InnerHtml = Constant.ADD_ERROR;
                            confirmMsg.InnerHtml = "";
                        }
                        PopulateAllTeamInLibrary();
                    }
                }
                catch (Exception ex)
                {
                    log.Error(ex.Message);
                }
                finally
                {
                    objDAM = null;
                }
            }
            else
            {
                confirmMsg.InnerHtml = "";
                divError.Attributes.Add("style", "display:block");
                divConfirm.Attributes.Add("style", "display:none");
                errorMsg.InnerHtml = Constant.DATA_NOT_FOUND;
            }
        }

        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                gdvTeamInLibrary.DataSource = objDAM.GetTeamInLibrarySearch(Server.HtmlEncode(txtSearchTeam.Value));
                gdvTeamInLibrary.DataBind();
                gdvTeamInLibrary.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (gdvTeamInLibrary.Rows.Count > 0)
                {
                    Response.ClearContent();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "TeamInLibrary.xls"));
                    Response.ContentType = "application/ms-excel";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter htw = new HtmlTextWriter(sw);
                    gdvTeamInLibrary.AllowPaging = false;
                    //Change the Header Row back to white color
                    gdvTeamInLibrary.HeaderRow.Style.Add("background-color", "#FFFFFF");
                    gdvTeamInLibrary.HeaderRow.Style.Add("color", "#fff");
                    for (int i = 0; i < gdvTeamInLibrary.HeaderRow.Cells.Count; i++)
                        gdvTeamInLibrary.HeaderRow.Cells[i].Style.Add("background-color", "#1B1BBA");
                    for (int i = 0; i < gdvTeamInLibrary.Columns.Count; i++)
                    {
                        if (gdvTeamInLibrary.Columns[i].HeaderText == "Active")
                            gdvTeamInLibrary.Columns[i].Visible = false;
                        if (gdvTeamInLibrary.Columns[i].HeaderText == "IsActive")
                            gdvTeamInLibrary.Columns[i].Visible = true;
                    }
                    gdvTeamInLibrary.RenderControl(htw);
                    Response.Write(sw.ToString());
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
    }
}