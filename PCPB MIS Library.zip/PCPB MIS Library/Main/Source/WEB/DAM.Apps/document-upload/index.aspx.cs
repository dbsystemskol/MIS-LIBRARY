﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AjaxControlToolkit;
using DAM.Apps.CommonClasses;
using System.Configuration;
using log4net;
using log4net.Config;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data;
using System.IO;
using System.Drawing.Imaging;
using QueryStringEncryption;
using System.Text;
namespace DAM.Apps.document_upload
{
    public partial class index : System.Web.UI.Page
    {
        
        
        
        protected void Page_Load(object sender, EventArgs e)
        {
            //Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //////HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            //if (Page.User.Identity.IsAuthenticated)
            //{
            //    UserId = Convert.ToInt32(Session["UserId"].ToString());
            //    LibId = Convert.ToInt32(Session["LibId"].ToString());
            //    TeamId = Convert.ToInt32(Session["TeamId"].ToString());
            //    SearchPrivilege = Convert.ToInt32(Session["Search"].ToString());
            //    UploadPrivilege = Convert.ToInt32(Session["Upload"].ToString());
            //    lblTeamName.Text = "Role : " + Session["TeamName"].ToString();
            //    lblLibrary.Text = "Library : " + Session["Library"].ToString();
            //    if (Session["TeamName"] == null)
            //    {
            //        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
            //    }
            //}
            //else
            //{
            //    Response.Redirect("~/Default.aspx", false);
            //}
            //if (!IsPostBack)
            //{
            //    Uname.InnerText = "Hi," + Session["FirstName"].ToString();
            //    PopulateContentType(LibId);
            //    BindNotification(TeamId, UserId, LibId);
            //}
        }
//        protected void imgConfirm_Click(object sender, EventArgs e)
//        {
//            Session["IsConfirm"] = 1;
//            ScriptManager.RegisterStartupScript(Page, this.GetType(), "enableKey", "<script>enableContent();</script>", false);
//        }
//        protected void imgEdit_Click(object sender, EventArgs e)
//        {
//            Session["IsConfirm"] = 0;
//            ScriptManager.RegisterStartupScript(Page, this.GetType(), "disableKey", "<script>disableContent();</script>", false);
//        }
//        private void BindNotification(Int32 TeamId, Int32 VisiterUserId, Int32 LibId)
//        {
//            DAMServices.ServiceContractClient objDAM;
//            StringBuilder sb;
//            try
//            {
//                objDAM = new DAMServices.ServiceContractClient();
//                sb = new StringBuilder();
//                var mList = objDAM.GetUserNotification(TeamId, VisiterUserId, LibId);
//                if (mList.Count() > 0)
//                {
                    
//                    var list = mList.GroupBy(a => a.NotificationType)
//                                .Select(n => new { Text = n.Key, Value = n.Count() }).ToList();
//                    notificationCount.InnerText = list.Count().ToString();
//                    sb.Append("<ul class='jq-dropdown-menu'>");

//                    foreach (var l in list)
//                    {
//                        String encURL = String.Empty;
//                        encURL = "../notification-list/index.aspx?" + EncryptQueryString(String.Format("sType={0}", l.Text));
//                        sb.AppendFormat("<li><a href='{0}'>{1} ({2})</a></li>", encURL, l.Text, l.Value);
//                    }
//                    sb.Append("</ul>");
//                    jqdropdown4.InnerHtml = sb.ToString();
//                }
//                else
//                {
//                    notificationCount.InnerText = "0";
//                    String abc = String.Empty;
//                    abc += abc + @"<ul class='jq-dropdown-menu'>
//                                <li><a href='#'>Notification 1</a></li>
//                                <li><a href='#'>Notification 2</a></li>
//                                <li><a href='#'>Notification 3</a></li>
//                                </ul>";
//                    jqdropdown4.InnerHtml = "";
//                }
//            }
//            catch (Exception ex)
//            {
//                log.Error(ex);
//            }
//            finally
//            {
//                objDAM = null;
//                sb = null;
//            }
//        }
//        private void PopulateContentType(Int32 LibId)
//        {
//            DAMServices.ServiceContractClient objDAM;
//            try
//            {
//                objDAM = new DAMServices.ServiceContractClient();
//                var list = objDAM.GetContentTypeByLibId(LibId);
//                var mList = list.Where(x => x.IsActive == true);
//                if (mList.Count() > 0)
//                {
//                    ddlContentType.DataSource = mList;
//                    ddlContentType.DataValueField = "ContentTypeId";
//                    ddlContentType.DataTextField = "Description";
//                    ddlContentType.DataBind();
//                    ddlContentType.Items.Insert(0, new ListItem("--Select--", "0"));
//                }
//                else
//                {
//                    //lblErrorMsg.Text = Constant.BRAND_UNAVAILABLE;
//                }
//            }
//            catch (Exception ex)
//            {
//                log.Error(ex.Message);
//            }
//            finally
//            {
//                objDAM = null;
//            }
//        }
//        protected void btnUpload_Click(object sender, EventArgs e)
//        {
//            divConfirm.Attributes.Add("style", "display:none");
//            divError.Attributes.Add("style", "display:none");
//            confirmMsg.InnerHtml = "";
//            errorMsg.InnerHtml = "";

//            int flen = fileUpload.PostedFile.ContentLength;
//            string FileName = fileUpload.FileName;
//            string path = System.IO.Path.GetFullPath(fileUpload.PostedFile.FileName);
//            String fext = CheckMimeType.getMimeFromFile(fileUpload.PostedFile);
//            String ext = System.IO.Path.GetExtension(fileUpload.PostedFile.FileName);

//            if (!CheckMimeType.IsValidExtension(ext))
//            {
//                divError.Attributes.Add("style", "display:block");
//                errorMsg.InnerHtml = Constant.FILE_INVALID;
//                return;
//            }
//            if (!CheckMimeType.CheckExe(fext))
//            {
//                divError.Attributes.Add("style", "display:block");
//                errorMsg.InnerHtml = Constant.FILE_CORRUPT;
//            }
//            if (flen <= Convert.ToInt64(ConfigurationManager.AppSettings["MaxFileSize"]))
//            {
//                String path1 = ConfigurationManager.AppSettings["FilePath"].ToString();
//                String path2 = String.Empty;
//                String UniqueFileName = Guid.NewGuid().ToString() + ext;
//                path2 = path1 + UniqueFileName;
//                if (path2.Length < 260)
//                {
//                    try
//                    {
//                        fileUpload.SaveAs(path2);
//                        hdnFileName.Value = fileUpload.FileName;
//                        lblFileName.Text = fileUpload.FileName;
//                        hdnFileExtension.Value = ext;
//                        hdnFileSize.Value = flen.ToString();
//                        hdnGuidName.Value = UniqueFileName;
//                        BindFilePreview(ext, UniqueFileName);
//                        imgFilePreview.Visible = true;
//                        lnkDownload.Visible = true;
//                        hdnIsFileUploaded.Value = "true";
//                        divConfirm.Attributes.Add("style", "display:block");
//                        confirmMsg.InnerHtml = Constant.FILE_UPLOAD_SUCCESS;
//                    }
//                    catch (Exception ex)
//                    {
//                        log.Error(ex.Message);
//                    }
//                }
//                else
//                {
//                    divError.Attributes.Add("style", "display:block");
//                    errorMsg.InnerHtml = Constant.FILE_UPLOAD_FAILURE;
//                    return;
//                }
//            }
//            else
//            {
//                divError.Attributes.Add("style", "display:block");
//                errorMsg.InnerHtml = Constant.FILE_SIZE_FAILURE;
//            }
//            ScriptManager.RegisterStartupScript(Page, this.GetType(), "hideKey", "<script>HideProgress();</script>", false);
//        }
//        private void BindFilePreview(String Extension, String GuidName)
//        {
//            switch (Extension.ToLower())
//            {
//                case ".png":
//                    GenerateThumbnails(ConfigurationManager.AppSettings["FilePath"].ToString() + GuidName);
//                    break;
//                case ".jpg":
//                    GenerateThumbnails(ConfigurationManager.AppSettings["FilePath"].ToString() + GuidName);
//                    break;
//                case ".jpeg":
//                    GenerateThumbnails(ConfigurationManager.AppSettings["FilePath"].ToString() + GuidName);
//                    break;
//                default:
//                    DAMServices.ServiceContractClient objDAM;
//                    objDAM = new DAMServices.ServiceContractClient();
//                    var mlist = objDAM.GetFileExtensionMasterByExtension(Extension.Trim('.'));
//                    if (mlist[0].PreviewImage != "")
//                        imgFilePreview.ImageUrl = "../img/file-icons/" + mlist[0].PreviewImage;
//                    else
//                        imgFilePreview.ImageUrl = "../img/file-icons/noImageAvailable.jpg";
//                    break;
//            }
//        }
//        private void GenerateThumbnails(String path)
//        {
//            System.Drawing.Image image = System.Drawing.Image.FromFile(path);
//            using (System.Drawing.Image thumbnail = image.GetThumbnailImage(100, 100, new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero))
//            {
//                using (MemoryStream memoryStream = new MemoryStream())
//                {
//                    thumbnail.Save(memoryStream, ImageFormat.Png);
//                    Byte[] bytes = new Byte[memoryStream.Length];
//                    memoryStream.Position = 0;
//                    memoryStream.Read(bytes, 0, (int)bytes.Length);
//                    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
//                    imgFilePreview.ImageUrl = "data:image/png;base64," + base64String;
//                }
//            }
//        }
//        public bool ThumbnailCallback()
//        {
//            return false;
//        }
//        protected override void OnLoad(EventArgs e)
//        {
//            base.OnLoad(e);
//            BindControls();
//        }
//        private void BindControls()
//        {
//            if (ddlContentType.SelectedIndex > 0)
//            {
//                DAMServices.ServiceContractClient objDAM;
//                try
//                {
//                    objDAM = new DAMServices.ServiceContractClient();
//                    var list = objDAM.GetLibraryAttributeSetByContentTypeId(Convert.ToInt32(ddlContentType.SelectedValue));
//                    var mList = list.Where(x => x.IsActive == true);
//                    var commonList = mList.Where(x => x.AttributeType != "MetaData").ToList();
//                    var metadataList = mList.Where(x => x.AttributeType == "MetaData").ToList();
//                    if (commonList.Count() > 0)
//                    {
//                        for (int i = 0; i < commonList.Count(); i++)
//                        {
//                            generateDynamicControls(commonList[i].AttributeType, commonList[i].FieldId, commonList[i].FieldCaption, commonList[i].FieldType, commonList[i].IsMandatory, i % 2, commonList[i].DefaultValue);
//                        }
//                    }
//                    if (metadataList.Count() > 0)
//                    {
//                        for (int i = 0; i < metadataList.Count(); i++)
//                        {
//                            generateDynamicControls(metadataList[i].AttributeType, metadataList[i].FieldId, metadataList[i].FieldCaption, metadataList[i].FieldType, metadataList[i].IsMandatory, i % 2, metadataList[i].DefaultValue);
//                        }
//                    }
//                }
//                catch (Exception ex)
//                {
//                    log.Error(ex.Message);
//                }
//                finally
//                {
//                    objDAM = null;
//                }
//                if (Session["IsConfirm"] != null )
//                {
//                    if(Session["IsConfirm"].ToString() == "0")
//                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "showConfirmKey", "<script>showConfirmButton();</script>", false);
//                    else
//                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "enableKey", "<script>enableContent();</script>", false);
//                }
//                else
//                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "showConfirmKey", "<script>showConfirmButton();</script>", false);
//            }
//            else
//                ScriptManager.RegisterStartupScript(Page, this.GetType(), "hideConfirmKey", "<script>hideConfirmButton();</script>", false);
//        }
//        protected void ddlContentType_SelectedIndexChanged(object sender, EventArgs e)
//        {
//            //BindControls();
//        }
//        public void generateDynamicControls(String AttributeType, Int32 FieldId, String FieldName, String FieldType, Boolean IsRequired, int bgCss, String DefaultValue)
//        {
//            ViewState["control"] = FieldName + FieldId;
//            switch (FieldType.ToLower())
//            {
//                case "texttype":
//                    createDynamicTextBox(AttributeType, FieldId, FieldName, IsRequired, bgCss, DefaultValue);
//                    break;
//                case "listtype":
//                    createDynamicDropDownList(AttributeType, FieldId, FieldName, IsRequired, bgCss, DefaultValue);
//                    break;
//                case "datetimetype":
//                    createDynamicDateTime(AttributeType, FieldId, FieldName, IsRequired, bgCss, DefaultValue);
//                    break;
//                case "textareatype":
//                    createDynamicTextArea(AttributeType, FieldId, FieldName, IsRequired, bgCss, DefaultValue);
//                    break;
//                case "numerictype":
//                    createDynamicNumericTextBox(AttributeType, FieldId, FieldName, IsRequired, bgCss, DefaultValue);
//                    break;
//                default:
//                    break;
//            }
//        }
//        public void createDynamicTextBox(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss, String DefaultValue)
//        {
//            HtmlGenericControl tr = new HtmlGenericControl("tr");
//            HtmlGenericControl td1 = new HtmlGenericControl("td");
//            if(bgCss == 0)
//                tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
//            else
//                tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
//            Label lbl = new Label();
//            lbl.ID = "lbl" + FieldId.ToString();
//            lbl.Text = FieldName;
//            td1.Controls.Add(lbl);
//            tr.Controls.Add(td1);
//            if (IsRequired)
//            {
//                Label lbl1 = new Label();
//                lbl1.ID = "lbl" + FieldName;
//                lbl1.Text = "   *";
//                lbl1.ForeColor = System.Drawing.Color.Red;
//                td1.Controls.Add(lbl1);
//                tr.Controls.Add(td1);
//            }            

//            HtmlGenericControl td2 = new HtmlGenericControl("td");
//            TextBox txtBox = new TextBox();
//            txtBox.ID = "txt" + FieldId.ToString();
//            txtBox.Attributes.Add("disabled", "");
//            txtBox.CssClass = "my-class";
//            txtBox.Text = DefaultValue;
//            td2.Controls.Add(txtBox);
//            tr.Controls.Add(td2);
//            tr.EnableViewState = true;
//            tr.ViewStateMode = ViewStateMode.Enabled;
//            if (AttributeType == "MetaData")
//                plcHldMetadata.Controls.Add(tr);
//            else
//                plcHldCommon.Controls.Add(tr);
//        }
//        public void createDynamicDropDownList(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss, String DefaultValue)
//        {
//            HtmlGenericControl tr = new HtmlGenericControl("tr");
//            HtmlGenericControl td1 = new HtmlGenericControl("td");
//            if (bgCss == 0)
//                tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
//            else
//                tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
//            Label lbl = new Label();
//            lbl.ID = "lbl" + FieldId.ToString();
//            lbl.Text = FieldName;
            
//            td1.Controls.Add(lbl);
//            tr.Controls.Add(td1);

//            if (IsRequired)
//            {
//                Label lbl1 = new Label();
//                lbl1.ID = "lbl" + FieldName;
//                lbl1.Text = "   *";
//                lbl1.ForeColor = System.Drawing.Color.Red;
//                td1.Controls.Add(lbl1);
//                tr.Controls.Add(td1);
//            }

//            HtmlGenericControl td2 = new HtmlGenericControl("td");
//            DropDownList ddl = new DropDownList();
//            ddl.ID = "ddl" + FieldId.ToString();
//            ddl.Width = 270;
//            ddl.Attributes.Add("disabled", "");
//            ddl.CssClass = "my-class";
//            DAMServices.ServiceContractClient objDAM;
//            try
//            {
//                objDAM = new DAMServices.ServiceContractClient();
//                var list = objDAM.GetLookupMasterByFieldId(FieldId, LibId);
//                var mList = list.Where(x => x.IsActive = true);
//                if (mList.Count() > 0)
//                {
//                    ddl.DataSource = mList;
//                    ddl.DataValueField = "LookupId";
//                    ddl.DataTextField = "FieldValue";
//                    ddl.DataBind();
//                }
//                else
//                {
//                    //lblErrorMsg.Text = Constant.BRAND_UNAVAILABLE;
//                }
                
//            }
//            catch (Exception ex)
//            {
//                log.Error(ex.Message);
//            }
//            finally
//            {
//                objDAM = null;
//            }
//            ddl.Items.Insert(0, new ListItem("--Select--", "0"));

//            if (ddl.Items.FindByText(DefaultValue) != null)
//                ddl.Items.FindByText(DefaultValue).Selected = true;
//            if (FieldName == "Confidential")
//            {
//                Label lblLagand = new Label();
//                lblLagand.ID = "lblLagand";
//                lblLagand.Text = "* If confidential, only Team A will be able to view the file.";
//                lblLagand.Attributes.Add("style", "width:155px;display: inline-block;margin-left: 10px;");
//                td2.Controls.Add(lblLagand);
//            }
//            td2.Controls.Add(ddl);            
//            tr.Controls.Add(td2);
//            if (FieldName == "Confidential")
//            {
//                switch (GetSelfPrivilege(UploadPrivilege))
//                {
//                    case 0:
//                    case 1:
//                        tr.Attributes.Add("style", "display: none");
//                        break;
//                }
//            }
//            tr.EnableViewState = true;
//            tr.ViewStateMode = ViewStateMode.Enabled;
//            if (AttributeType == "MetaData")
//                plcHldMetadata.Controls.Add(tr);
//            else
//                plcHldCommon.Controls.Add(tr);
//        }
//        private int GetSelfPrivilege(Int32 privilege)
//        {
//            int privilegeValue = 0;
//            switch (privilege)
//            {
//                case 2:
//                case 3:
//                    privilegeValue = 1;
//                    break;
//                case 8:
//                case 12:
//                    privilegeValue = 2;
//                    break;
//                case 10:
//                case 11:
//                case 14:
//                case 15:
//                    privilegeValue = 3;
//                    break;
//            }
//            return privilegeValue;
//        }
//        public void createDynamicDateTime(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss, String DefaultValue)
//        {
//            HtmlGenericControl tr = new HtmlGenericControl("tr");
//            HtmlGenericControl td1 = new HtmlGenericControl("td");
//            if (bgCss == 0)
//                tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
//            else
//                tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
//            Label lbl = new Label();
//            lbl.ID = "lbl" + FieldId.ToString();
//            lbl.Text = FieldName;
//            td1.Controls.Add(lbl);
//            tr.Controls.Add(td1);
//            if (IsRequired)
//            {
//                Label lbl1 = new Label();
//                lbl1.ID = "lbl" + FieldName;
//                lbl1.Text = "   *";
//                lbl1.ForeColor = System.Drawing.Color.Red;
//                td1.Controls.Add(lbl1);
//                tr.Controls.Add(td1);
//            }

//            HtmlGenericControl td2 = new HtmlGenericControl("td");
//            TextBox txtBox = new TextBox();
//            txtBox.ID = "txt" + FieldId.ToString();
//            txtBox.CssClass = "date";
//            txtBox.Attributes.Add("style", "background-image: url('../img/nav-icons/calender.png');background-position: right center;background-repeat: no-repeat");
//            txtBox.Attributes.Add("disabled", "");
//            if(FieldName == "Expiry Date")
//                txtBox.Text = DateTime.Now.AddDays(Convert.ToDouble(DefaultValue)).ToString("dd-MM-yyyy");
//            else
//                txtBox.Text = DefaultValue;
//            td2.Controls.Add(txtBox);
//            tr.Controls.Add(td2);
//            tr.EnableViewState = true;
//            tr.ViewStateMode = ViewStateMode.Enabled;
//            if (AttributeType == "MetaData")
//                plcHldMetadata.Controls.Add(tr);
//            else
//                plcHldCommon.Controls.Add(tr);
//        }
//        public void createDynamicTextArea(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss, String DefaultValue)
//        {
//            HtmlGenericControl tr = new HtmlGenericControl("tr");
//            HtmlGenericControl td1 = new HtmlGenericControl("td");
//            if (bgCss == 0)
//                tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
//            else
//                tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
//            Label lbl = new Label();
//            lbl.ID = "lbl" + FieldId.ToString();
//            lbl.Text = FieldName;
//            td1.Controls.Add(lbl);
//            tr.Controls.Add(td1);
//            if (IsRequired)
//            {
//                Label lbl1 = new Label();
//                lbl1.ID = "lbl" + FieldName;
//                lbl1.Text = "   *";
//                lbl1.ForeColor = System.Drawing.Color.Red;
//                td1.Controls.Add(lbl1);
//                tr.Controls.Add(td1);
//            }

//            HtmlGenericControl td2 = new HtmlGenericControl("td");
//            TextBox txtBox = new TextBox();
//            txtBox.ID = "txt" + FieldId.ToString();
//            txtBox.TextMode = TextBoxMode.MultiLine;
//            txtBox.Attributes.Add("disabled", "");
//            txtBox.CssClass = "my-class";
//            txtBox.Text = DefaultValue;
//            td2.Controls.Add(txtBox);
//            tr.Controls.Add(td2);
//            tr.EnableViewState = true;
//            tr.ViewStateMode = ViewStateMode.Enabled;
//            if (AttributeType == "MetaData")
//                plcHldMetadata.Controls.Add(tr);
//            else
//                plcHldCommon.Controls.Add(tr);
//        }
//        public void createDynamicNumericTextBox(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss, String DefaultValue)
//        {
//            HtmlGenericControl tr = new HtmlGenericControl("tr");
//            HtmlGenericControl td1 = new HtmlGenericControl("td");
//            if (bgCss == 0)
//                tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
//            else
//                tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
//            Label lbl = new Label();
//            lbl.ID = "lbl" + FieldId.ToString();
//            lbl.Text = FieldName;
//            td1.Controls.Add(lbl);
//            tr.Controls.Add(td1);
//            if (IsRequired)
//            {
//                Label lbl1 = new Label();
//                lbl1.ID = "lbl" + FieldName;
//                lbl1.Text = "   *";
//                lbl1.ForeColor = System.Drawing.Color.Red;
//                td1.Controls.Add(lbl1);
//                tr.Controls.Add(td1);
//            }

//            HtmlGenericControl td2 = new HtmlGenericControl("td");
//            TextBox txtBox = new TextBox();
//            txtBox.ID = "txt" + FieldId.ToString();
//            txtBox.Attributes.Add("onkeypress", "return allowOnlyNumber(event);");
//            txtBox.Attributes.Add("disabled", "");
//            txtBox.CssClass = "my-class";
//            txtBox.Text = DefaultValue;
//            td2.Controls.Add(txtBox);
//            tr.Controls.Add(td2);
//            tr.EnableViewState = true;
//            tr.ViewStateMode = ViewStateMode.Enabled;
//            if (AttributeType == "MetaData")
//                plcHldMetadata.Controls.Add(tr);
//            else
//                plcHldCommon.Controls.Add(tr);
//        }
//        protected void btnSave_Click(object sender, EventArgs e)
//        {
//            Int32[] returnValues;
//            divConfirm.Attributes.Add("style", "display:none");
//            divError.Attributes.Add("style", "display:none");
//            confirmMsg.InnerHtml = "";
//            errorMsg.InnerHtml = "";
//            String encURL = String.Empty;
//            DAMServices.ServiceContractClient objDAM;
//            DAMServices.FileInfo mFileMaster;
//            DAMServices.FileVersionInfo mFileVersion;
//            DAMServices.DocomentMasterInfo mDocMaster;
//            DataTable linkedFiles;
//            try
//            {
//                if (Convert.ToBoolean(hdnIsFileUploaded.Value))
//                {
//                    if (Convert.ToInt32(ddlContentType.SelectedValue) > 0)
//                    {
//                        objDAM = new DAMServices.ServiceContractClient();
//                        mFileMaster = new DAMServices.FileInfo();
//                        mFileVersion = new DAMServices.FileVersionInfo();
//                        mDocMaster = new DAMServices.DocomentMasterInfo();
//                        linkedFiles = new DataTable();
//                        String strDocDetails = String.Empty;
//                        String strFileLinks = String.Empty;


//                        mFileMaster.ContentTypeId = Convert.ToInt32(ddlContentType.SelectedValue);
//                        mFileMaster.FileName = hdnFileName.Value;
//                        mFileMaster.GuidName = hdnGuidName.Value;
//                        mFileMaster.FileExtension = hdnFileExtension.Value;
//                        mFileMaster.CreatedBy = UserId;

//                        mFileVersion.VersionNo = 1;
//                        mFileVersion.DefaultFlag = true;
//                        mFileVersion.FileSize = Convert.ToInt32(hdnFileSize.Value);
//                        mFileVersion.CreatedBy = UserId;

//                        mDocMaster.ContentTypeId = Convert.ToInt32(ddlContentType.SelectedValue);
//                        mDocMaster.Keywords = txtKeywords.Value;
//                        mDocMaster.CreatedBy = UserId;

//                        var list = objDAM.GetLibraryAttributeSetByContentTypeId(Convert.ToInt32(ddlContentType.SelectedValue));
//                        var mList = list.Where(x => x.IsActive = true).ToList();
//                        for (int i = 0; i < mList.Count(); i++)
//                        {
//                            if (mList[i].AttributeType == "MetaData") //find in metadata tab
//                            {
//                                switch (mList[i].FieldType.ToLower())
//                                {
//                                    case "texttype":
//                                    case "textareatype":
//                                    case "datetimetype":
//                                    case "numerictype":
//                                        TextBox txt = (TextBox)plcHldMetadata.FindControl("txt" + mList[i].FieldId.ToString());
//                                        if (txt.Text.Trim().Length == 0 && mList[i].IsMandatory == true)
//                                        {
//                                            divConfirm.Attributes.Add("style", "display:none");
//                                            divError.Attributes.Add("style", "display:block");
//                                            confirmMsg.InnerHtml = "";
//                                            errorMsg.InnerHtml = mList[i].FieldName + " is required.";
//                                            return;
//                                        }
//                                        strDocDetails += mList[i].FieldId + "," + 0 + "," + txt.Text + "," + UserId + "|";
//                                        break;
//                                    case "listtype":
//                                        DropDownList ddl = (DropDownList)plcHldMetadata.FindControl("ddl" + mList[i].FieldId.ToString());
//                                        if (Convert.ToInt32(ddl.SelectedValue) == 0 && mList[i].IsMandatory == true)
//                                        {
//                                            divConfirm.Attributes.Add("style", "display:none");
//                                            divError.Attributes.Add("style", "display:block");
//                                            confirmMsg.InnerHtml = "";
//                                            errorMsg.InnerHtml = mList[i].FieldName + " is required.";
//                                            return;
//                                        }
//                                        strDocDetails += mList[i].FieldId + "," + ddl.SelectedValue + "," + ddl.SelectedItem.Text + "," + UserId + "|";
//                                        break;
//                                }
//                            }
//                            else                                    //find in uploads tab
//                            {
//                                switch (mList[i].FieldType.ToLower())
//                                {
//                                    case "texttype":
//                                    case "textareatype":
//                                    case "numerictype":
//                                        TextBox txt = (TextBox)plcHldCommon.FindControl("txt" + mList[i].FieldId.ToString());
//                                        if (txt.Text.Trim().Length == 0 && mList[i].IsMandatory == true)
//                                        {
//                                            divConfirm.Attributes.Add("style", "display:none");
//                                            divError.Attributes.Add("style", "display:block");
//                                            confirmMsg.InnerHtml = "";
//                                            errorMsg.InnerHtml = mList[i].FieldName + " is required.";
//                                            return;
//                                        }
//                                        strDocDetails += mList[i].FieldId + "," + 0 + "," + txt.Text + "," + UserId + "|";
//                                        break;
//                                    case "datetimetype":
//                                        TextBox txtExpiryDate = (TextBox)plcHldCommon.FindControl("txt" + mList[i].FieldId.ToString());
//                                        if (txtExpiryDate.Text.Trim().Length == 0 && mList[i].IsMandatory == true)
//                                        {
//                                            divConfirm.Attributes.Add("style", "display:none");
//                                            divError.Attributes.Add("style", "display:block");
//                                            confirmMsg.InnerHtml = "";
//                                            errorMsg.InnerHtml = mList[i].FieldName + " is required.";
//                                            return;
//                                        }
//                                        else if (txtExpiryDate.Text.Trim().Length > 0 && mList[i].FieldName == "ExpiryDate")
//                                        {
//                                            CommonClass objCommon = new CommonClass();
//                                            Boolean IsValid = objCommon.ValidateExpiryDate(txtExpiryDate.Text,Convert.ToInt32(mList[i].DefaultValue));
//                                            if (!IsValid)
//                                            {
//                                                divConfirm.Attributes.Add("style", "display:none");
//                                                divError.Attributes.Add("style", "display:block");
//                                                confirmMsg.InnerHtml = "";
//                                                errorMsg.InnerHtml = mList[i].FieldName + " is invalid.";
//                                                return;
//                                            }
//                                        }
//                                        strDocDetails += mList[i].FieldId + "," + 0 + "," + txtExpiryDate.Text + "," + UserId + "|";
//                                        break;
//                                    case "listtype":
//                                        DropDownList ddl = (DropDownList)plcHldCommon.FindControl("ddl" + mList[i].FieldId.ToString());
//                                        if (Convert.ToInt32(ddl.SelectedValue) == 0 && mList[i].IsMandatory == true)
//                                        {
//                                            divConfirm.Attributes.Add("style", "display:none");
//                                            divError.Attributes.Add("style", "display:block");
//                                            confirmMsg.InnerHtml = "";
//                                            errorMsg.InnerHtml = mList[i].FieldName + " is required.";
//                                            return;
//                                        }
//                                        strDocDetails += mList[i].FieldId + "," + ddl.SelectedValue + "," + ddl.SelectedItem.Text + "," + UserId + "|";
//                                        break;
//                                }
//                            }
//                        }
//                        if (strDocDetails != "")
//                            strDocDetails = strDocDetails.Remove(strDocDetails.Length - 1);///remove last character(|)
//                        linkedFiles = (DataTable)Session["Result"];
//                        if (linkedFiles != null)
//                        {
//                            foreach (DataRow row in linkedFiles.Rows)
//                            {
//                                strFileLinks += row["FileInfoId"] + "," + UserId + "|";
//                            }
//                            if (strFileLinks != "")
//                                strFileLinks = strFileLinks.Remove(strFileLinks.Length - 1);///remove last character(|)
//                        }                                                      
//                        returnValues = new Int32[2];
//                        returnValues = objDAM.InsertFileMaster(mFileMaster, mFileVersion, mDocMaster, strDocDetails, strFileLinks, TeamId, LibId, "New Upload");
//                        if (returnValues[0] > 0)
//                        {
//                            divConfirm.Attributes.Add("style", "display:block");
//                            divError.Attributes.Add("style", "display:none");
//                            confirmMsg.InnerHtml = Constant.ADD_SUCCESS;
//                            errorMsg.InnerHtml = "";
//                            encURL = "../file-preview/index.aspx?" + EncryptQueryString(String.Format("fid={0}&docid={1}", returnValues[0], returnValues[1]));
//                            Response.Redirect(encURL, false);
//                        }
//                        else
//                        {
//                            divConfirm.Attributes.Add("style", "display:none");
//                            divError.Attributes.Add("style", "display:block");
//                            confirmMsg.InnerHtml = "";
//                            errorMsg.InnerHtml = Constant.ADD_ERROR;
//                        }
//                    }
//                    else
//                    {
//                        divConfirm.Attributes.Add("style", "display:none");
//                        divError.Attributes.Add("style", "display:block");
//                        confirmMsg.InnerHtml = "";
//                        errorMsg.InnerHtml = "Select content type";
//                    }
//                }
//                else
//                {
//                    divConfirm.Attributes.Add("style", "display:none");
//                    divError.Attributes.Add("style", "display:block");
//                    confirmMsg.InnerHtml = "";
//                    errorMsg.InnerHtml = Constant.NO_FILE;
//                }

//            }
//            catch (Exception ex)
//            {
//                log.Error(ex.Message);
//            }
//            finally
//            {
//                objDAM = null;
//            }
//        }
//        private string[] GetPrivilegeDetail(Int32 privilege)
//        {
//            string[] privilegeArray = new string[4];
//            switch (privilege)
//            {
//                case 2:
//                    privilegeArray[0] = "Yes";
//                    privilegeArray[1] = UserId.ToString();
//                    privilegeArray[2] = "No";
//                    privilegeArray[3] = UserId.ToString();
//                    break;
//                case 3:
//                    privilegeArray[0] = "Yes";
//                    privilegeArray[1] = UserId.ToString();
//                    privilegeArray[2] = "No";
//                    privilegeArray[3] = "0";
//                    break;
//                case 8:
//                    privilegeArray[0] = "Yes";
//                    privilegeArray[1] = UserId.ToString();
//                    privilegeArray[2] = "No";
//                    privilegeArray[3] = UserId.ToString();
//                    break;
//                case 10:
//                    privilegeArray[0] = "Yes";
//                    privilegeArray[1] = UserId.ToString();
//                    privilegeArray[2] = "No";
//                    privilegeArray[3] = UserId.ToString();
//                    break;
//                case 11:
//                    privilegeArray[0] = "Yes";
//                    privilegeArray[1] = UserId.ToString();
//                    privilegeArray[2] = "No";
//                    privilegeArray[3] = "0";
//                    break;
//                case 12:
//                    privilegeArray[0] = "Yes";
//                    privilegeArray[1] = "0";
//                    privilegeArray[2] = "No";
//                    privilegeArray[3] = UserId.ToString();
//                    break;
//                case 14:
//                    privilegeArray[0] = "Yes";
//                    privilegeArray[1] = "0";
//                    privilegeArray[2] = "No";
//                    privilegeArray[3] = UserId.ToString();
//                    break;
//                case 15:
//                    privilegeArray[0] = "Yes";
//                    privilegeArray[1] = "0";
//                    privilegeArray[2] = "No";
//                    privilegeArray[3] = "0";
//                    break;
//            }
//            return privilegeArray;
//        }
//        protected void btnSearch_Click(object sender, EventArgs e)
//        {
//            divConfirm.Attributes.Add("style", "display:none");
//            divError.Attributes.Add("style", "display:none");
//            confirmMsg.InnerHtml = "";
//            errorMsg.InnerHtml = "";
//            DAMServices.ServiceContractClient objDAM;
//            DAMServices.FreeTextSearchFiles dt;
//            DAMServices.FreeTextSearchFiles dtC;
//            DAMServices.FreeTextSearchFiles dtG;
//            String html = String.Empty;
//            String resulthtml = String.Empty;            
//            try
//            {
//                objDAM = new DAMServices.ServiceContractClient();
//                dt = new DAMServices.FreeTextSearchFiles();
//                dtC = new DAMServices.FreeTextSearchFiles();
//                dtG = new DAMServices.FreeTextSearchFiles();
//                string[] privilage = GetPrivilegeDetail(SearchPrivilege);
//                dtC = objDAM.GetFreeTextSearchFiles(txtSearch.Value, privilage[0], LibId, TeamId, Convert.ToInt32(privilage[1]));
//                dtG = objDAM.GetFreeTextSearchFiles(txtSearch.Value, privilage[2], LibId, TeamId, Convert.ToInt32(privilage[3]));
//                dt.FreeTextSearchTable = dtC.FreeTextSearchTable.Copy();
//                dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);
//                if (dt.FreeTextSearchTable.Rows.Count > 0)
//                {
//                    Session["SearchResult"] = dt;
//                    gdvSearchResult.DataSource = dt.FreeTextSearchTable;
//                    gdvSearchResult.DataBind();
//                    gdvSearchResult.HeaderRow.TableSection = TableRowSection.TableHeader;
//                    gdvLinkedFiles.HeaderRow.TableSection = TableRowSection.TableHeader;
//                }
//                else
//                {
//                    Session["SearchResult"] = dt;
//                    gdvSearchResult.DataSource = dt.FreeTextSearchTable;
//                    gdvSearchResult.DataBind();
//                    gdvSearchResult.HeaderRow.TableSection = TableRowSection.TableHeader;
//                    gdvLinkedFiles.HeaderRow.TableSection = TableRowSection.TableHeader;
//                    divConfirm.Attributes.Add("style", "display:none");
//                    divError.Attributes.Add("style", "display:block");
//                    confirmMsg.InnerHtml = "";
//                    errorMsg.InnerHtml = "No data found.";
//                }
//            }
//            catch (Exception ex)
//            {
//                log.Error(ex.Message);
//            }
//            finally
//            {
//                objDAM = null;
//            }
//        }
//        protected void btnAddLinkFile_Click(object sender, EventArgs e)
//        {
//            DAMServices.FreeTextSearchFiles master;
//            List<int> values;
//            try
//            {
//                values = new List<int>();
//                master = (DAMServices.FreeTextSearchFiles)Session["SearchResult"];
//                foreach (GridViewRow r in gdvSearchResult.Rows)
//                {
//                    CheckBox chkSelect = (CheckBox)r.FindControl("chkSelect");
//                    if (chkSelect.Checked)
//                    {
//                        string value = r.Cells[GetColumnIndexByName(r, "DocId")].Text;
//                        values.Add(Convert.ToInt32(value));
//                    }
//                }
//                if (values.Count() > 0)
//                {
//                    var matchingRows = from row in master.FreeTextSearchTable.AsEnumerable()
//                                       join value in values
//                                       on row.Field<int>("DocId") equals value
//                                       select row;
//                    DataTable tblResult = matchingRows.CopyToDataTable();
//                    if (Session["Result"] == null)
//                    {
//                        Session["Result"] = tblResult;
//                        gdvLinkedFiles.DataSource = tblResult;
//                        gdvLinkedFiles.DataBind();
//                        gdvSearchResult.HeaderRow.TableSection = TableRowSection.TableHeader;
//                        gdvLinkedFiles.HeaderRow.TableSection = TableRowSection.TableHeader;
//                    }
//                    else
//                    {
//                        DataTable dt = (DataTable)Session["Result"];
//                        dt.PrimaryKey = new[] { dt.Columns["DocId"] };
//                        dt.Merge(tblResult,true);
//                        gdvLinkedFiles.DataSource = dt;
//                        gdvLinkedFiles.DataBind();
//                        gdvSearchResult.HeaderRow.TableSection = TableRowSection.TableHeader;
//                        gdvLinkedFiles.HeaderRow.TableSection = TableRowSection.TableHeader;
//                        Session["Result"] = dt;
//                    }             
//                }
//            }
//            catch (Exception ex)
//            {
//                log.Error(ex);
//            }
//            finally
//            {
//                master = null;
//                values = null;
//            }
//        }
//        protected void gdvSearchResult_RowCreated(object sender, GridViewRowEventArgs e)
//        {
//            e.Row.Cells[1].Visible = false; // hides the first column
//            e.Row.Cells[2].Visible = false;
//            e.Row.Cells[7].Visible = false;
//        }
//        protected void gdvLinkedFiles_RowCreated(object sender, GridViewRowEventArgs e)
//        {
//            e.Row.Cells[1].Visible = false; // hides the first column
//            e.Row.Cells[2].Visible = false; // hides the 2nd column
//            e.Row.Cells[7].Visible = false;
//            GridViewRow row = e.Row;
//            // Intitialize TableCell list
//            List<TableCell> columns = new List<TableCell>();
//            foreach (DataControlField column in gdvLinkedFiles.Columns)
//            {
//                //Get the first Cell /Column
//                TableCell cell = row.Cells[0];
//                // Then Remove it after
//                row.Cells.Remove(cell);
//                //And Add it to the List Collections
//                columns.Add(cell);
//            }

//            // Add cells
//            row.Cells.AddRange(columns.ToArray());
//        }
//        int GetColumnIndexByName(GridViewRow row, string SearchColumnName)
//        {
//            int columnIndex = 0;
//            foreach (DataControlFieldCell cell in row.Cells)
//            {
//                if (cell.ContainingField is BoundField)
//                {
//                    if (((BoundField)cell.ContainingField).DataField.Equals(SearchColumnName))
//                    {
//                        break;
//                    }
//                }
//                columnIndex++;
//            }
//            return columnIndex;
//        }        
//        protected void chkboxSelectAll_CheckedChanged(object sender, EventArgs e)
//        {
//            CheckBox ChkBoxHeader = (CheckBox)gdvSearchResult.HeaderRow.FindControl("chkboxSelectAll");
//            foreach (GridViewRow row in gdvSearchResult.Rows)
//            {
//                CheckBox ChkBoxRows = (CheckBox)row.FindControl("chkSelect");
//                if (ChkBoxHeader.Checked == true)
//                {
//                    ChkBoxRows.Checked = true;
//                }
//                else
//                {
//                    ChkBoxRows.Checked = false;
//                }
//            }
//        }
//        protected void gdvLinkedFiles_RowCommand(object sender, GridViewCommandEventArgs e)
//        {
//            Int32 FileInfoId = Convert.ToInt32(e.CommandArgument);
//            try
//            {
//                DataTable dt = (DataTable)Session["Result"];
//                foreach (DataRow dr in dt.Rows)
//                {
//                    if ((Int32)dr["FileInfoId"] == FileInfoId)
//                        dr.Delete();
//                }
//                dt.AcceptChanges();
//                gdvLinkedFiles.DataSource = dt;
//                gdvLinkedFiles.DataBind();
//                Session["Result"] = dt;
//            }
//            catch (Exception ex)
//            {
//                log.Error(ex);
//            }
//            finally
//            {

//            }
//        }
//        protected void download_Click(object sender, EventArgs e)
//        {
//            String filePath = ConfigurationManager.AppSettings["FilePath"].ToString() + hdnGuidName.Value;
//            System.Web.HttpResponse response = System.Web.HttpContext.Current.Response;
//            response.ClearContent();
//            response.Clear();
//            response.ContentType = ContentType;
//            response.AddHeader("Content-Disposition", "attachment; filename=" + hdnFileName.Value + ";");
//            response.TransmitFile(filePath);
//            response.Flush();
//            HttpContext.Current.ApplicationInstance.CompleteRequest();
//        }
//        public string EncryptQueryString(string strQueryString)
//        {
//            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
//            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
//        }
//        protected void btnCancel_Click(object sender, EventArgs e)
//        {
//            Response.Redirect("~/dashboard/index.aspx", false);
//        }
    }
}