﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AjaxControlToolkit;
using DAM.Apps.CommonClasses;
using System.Configuration;
using log4net;
using log4net.Config;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data;

namespace DAM.Apps.teamA_dashboard
{
    public partial class index : System.Web.UI.Page
    {
        static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                PopulateFileNew(1);
            }
        }

        private void PopulateFileNew(Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.DashboardNewFiles dt;
            String html = String.Empty;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = objDAM.GetDashboardNewFiles(LibId,1);
                if (dt.DashboardNewFilesTable.Rows.Count > 0)
                {
                    html = "<table id='Table4' width='100%' cellpadding='0' cellspacing='0' ><thead><tr>";
                    foreach (DataColumn dcol in dt.DashboardNewFilesTable.Columns)
                    {
                        html += String.Format("<th>{0}</th>", dcol.ColumnName);
                    }
                    html += "</tr></thead><tbody>";
                    foreach (DataRow row in dt.DashboardNewFilesTable.Rows)
                    {
                        html += "<tr>";
                        foreach (DataColumn column in dt.DashboardNewFilesTable.Columns)
                        {
                            html += "<td>";
                            html += row[column.ColumnName];
                            html += "</td>";
                        }
                        html += "</tr>";
                    }
                    html += "</tbody></table>";
                    divNew.InnerHtml = html;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
    }
}