﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using log4net;
using System.Configuration;
using DAM.Apps.CommonClasses;
using System.Web.Configuration;

namespace DAM.Apps.library_new
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));

        private Int32 UserId;
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "System Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {
                
                PopulateAttributeList();
                PopulateContentTypeMaster();
            }
        }
        protected void PopulateContentTypeMaster()
        {
            DAMServices.ServiceContractClient obje;
            try
            {
                obje = new DAMServices.ServiceContractClient();
                var mList = obje.GetContentTypeMaster();
                ddlContentType.DataSource = mList;
                ddlContentType.DataValueField = "ContentTypeMasterId";
                ddlContentType.DataTextField = "Description";
                ddlContentType.DataBind();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
            }
        }

        protected void PopulateAttributeList()
        {
            DAMServices.ServiceContractClient obje;
            try
            {
                obje = new DAMServices.ServiceContractClient();
                var mList = obje.GetAllActiveAttributeMasterForLibrary();
                var cList = mList.Where(b => b.FieldCategory == "General").Select(b => new DAMServices.LibraryMasterInfo
                {
                    FieldId = b.FieldId,
                    FieldCaption = b.FieldCaption
                }).ToList();
                gdvCommon.DataSource = cList;
                gdvCommon.DataBind();
                gdvCommon.HeaderRow.TableSection = TableRowSection.TableHeader;

                var oList = mList.Where(b => b.FieldCategory == "Security").Select(b => new DAMServices.LibraryMasterInfo
                {
                    FieldId = b.FieldId,
                    FieldCaption = b.FieldCaption
                }).ToList();
                gdvOther.DataSource = oList;
                gdvOther.DataBind();
                gdvOther.HeaderRow.TableSection = TableRowSection.TableHeader;

                var mtList = mList.Where(b => b.FieldCategory == "Business").Select(b => new DAMServices.LibraryMasterInfo
                {
                    FieldId = b.FieldId,
                    FieldCaption = b.FieldCaption
                }).ToList();
                gdvMataData.DataSource = mtList;
                gdvMataData.DataBind();
                gdvMataData.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
            }
        }

        

        protected void chkCommonSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkCommonSelectAll = (CheckBox)gdvCommon.HeaderRow.FindControl("chkCommonSelectAll");
            foreach (GridViewRow row in gdvCommon.Rows)
            {
                CheckBox chkCommonAdd = (CheckBox)row.FindControl("chkCommonAdd");

                chkCommonAdd.Checked = (chkCommonSelectAll.Checked) ? true : false;
            }
            gdvCommon.HeaderRow.TableSection = TableRowSection.TableHeader;
            gdvOther.HeaderRow.TableSection = TableRowSection.TableHeader;
        }

        protected void chkOtherSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkOtherSelectAll = (CheckBox)gdvOther.HeaderRow.FindControl("chkOtherSelectAll");
            foreach (GridViewRow row in gdvOther.Rows)
            {
                CheckBox chkOtherAdd = (CheckBox)row.FindControl("chkOtherAdd");

                chkOtherAdd.Checked = (chkOtherSelectAll.Checked) ? true : false;
            }
            gdvCommon.HeaderRow.TableSection = TableRowSection.TableHeader;
            gdvOther.HeaderRow.TableSection = TableRowSection.TableHeader;
        }

        protected void chkMataDataSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkMataDataSelectAll = (CheckBox)gdvMataData.HeaderRow.FindControl("chkMataDataSelectAll");
            CheckBox chkMataDataIsMandSelectAll = (CheckBox)gdvMataData.HeaderRow.FindControl("chkMataDataIsMandSelectAll");
            chkMataDataIsMandSelectAll.Enabled = (chkMataDataSelectAll.Checked) ? true : false;
            if (!chkMataDataSelectAll.Checked)
                chkMataDataIsMandSelectAll.Checked = false;
            foreach (GridViewRow row in gdvMataData.Rows)
            {
                CheckBox chkMataDataAdd = (CheckBox)row.FindControl("chkMataDataAdd");
                CheckBox chkMataDataIsMand = (CheckBox)row.FindControl("chkMataDataIsMand");

                chkMataDataAdd.Checked = (chkMataDataSelectAll.Checked) ? true : false;
                chkMataDataIsMand.Enabled = (chkMataDataSelectAll.Checked) ? true : false;
                if (!chkMataDataSelectAll.Checked)
                    chkMataDataIsMand.Checked = false;
            }
            gdvMataData.HeaderRow.TableSection = TableRowSection.TableHeader;
        }

        protected void chkMataDataIsMandSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkMataDataIsMandSelectAll = (CheckBox)gdvMataData.HeaderRow.FindControl("chkMataDataIsMandSelectAll");
            foreach (GridViewRow row in gdvMataData.Rows)
            {
                CheckBox chkMataDataIsMand = (CheckBox)row.FindControl("chkMataDataIsMand");
                if (chkMataDataIsMand.Enabled)
                    chkMataDataIsMand.Checked = (chkMataDataIsMandSelectAll.Checked) ? true : false;
            }
            gdvMataData.HeaderRow.TableSection = TableRowSection.TableHeader;
        }

        protected void nxt3_Click(object sender, EventArgs e)
        {
            List<DAMServices.AttributeFieldsInfo> comList;
            List<DAMServices.AttributeFieldsInfo> othList;
            List<DAMServices.AttributeFieldsInfo> metaList;
            try
            {
                comList = new List<DAMServices.AttributeFieldsInfo>();
                for (int i = 0; i < gdvCommon.Rows.Count; i++)
                {
                    Label lblComFieldCaption = (Label)gdvCommon.Rows[i].FindControl("lblComFieldCaption");
                    CheckBox chkCommonAdd = (CheckBox)gdvCommon.Rows[i].FindControl("chkCommonAdd");
                    HiddenField hdnCommonFieldId = (HiddenField)gdvCommon.Rows[i].FindControl("hdnCommonFieldId");
                    if (chkCommonAdd.Checked)
                    {
                        comList.Add(new DAMServices.AttributeFieldsInfo {
                            FieldId = Convert.ToInt32(hdnCommonFieldId.Value),
                            FieldCaption = lblComFieldCaption.Text
                        });
                    }
                }
                grdvCommonData.DataSource = comList;
                grdvCommonData.DataBind();

                othList = new List<DAMServices.AttributeFieldsInfo>();
                for (int i = 0; i < gdvOther.Rows.Count; i++)
                {
                    Label lblOthFieldCaption = (Label)gdvOther.Rows[i].FindControl("lblOthFieldCaption");
                    CheckBox chkOtherAdd = (CheckBox)gdvOther.Rows[i].FindControl("chkOtherAdd");
                    HiddenField hdnOtherFieldId = (HiddenField)gdvOther.Rows[i].FindControl("hdnOtherFieldId");
                    if (chkOtherAdd.Checked)
                    {
                        othList.Add(new DAMServices.AttributeFieldsInfo
                        {
                            FieldId = Convert.ToInt32(hdnOtherFieldId.Value),
                            FieldCaption = lblOthFieldCaption.Text
                        });
                    }
                }
                grdvOtherData.DataSource = othList;
                grdvOtherData.DataBind();

                metaList = new List<DAMServices.AttributeFieldsInfo>();
                for (int i = 0; i < gdvMataData.Rows.Count; i++)
                {
                    Label lblMetFieldCaption = (Label)gdvMataData.Rows[i].FindControl("lblMetFieldCaption");
                    CheckBox chkMataDataAdd = (CheckBox)gdvMataData.Rows[i].FindControl("chkMataDataAdd");
                    CheckBox chkMataDataIsMand = (CheckBox)gdvMataData.Rows[i].FindControl("chkMataDataIsMand");
                    HiddenField hdnMataDataFieldId = (HiddenField)gdvMataData.Rows[i].FindControl("hdnMataDataFieldId");
                    if (chkMataDataAdd.Checked)
                    {
                        metaList.Add(new DAMServices.AttributeFieldsInfo
                        {
                            FieldId = Convert.ToInt32(hdnMataDataFieldId.Value),
                            FieldCaption = lblMetFieldCaption.Text,
                            IsMandatory = (chkMataDataIsMand.Checked) ? true : false
                        });
                    }
                }
                grdvMetaData.DataSource = metaList;
                grdvMetaData.DataBind();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                //obje = null;
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.LibraryMasterInfo lList;
            DAMServices.ContentTypeInfo conList;
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            try
            {
                if (lblLibraryName.InnerText != "")
                {
                    lList = new DAMServices.LibraryMasterInfo();
                    lList.LibName = Server.HtmlEncode(txtLibraryName.Value);
                    lList.CreatedBy = UserId;
                    lList.IPAddress = GetIPAddress();
                    if (lblLibraryName.InnerText != "")
                    {
                        conList = new DAMServices.ContentTypeInfo();
                        conList.Description = Server.HtmlEncode(ddlContentType.SelectedItem.Text);
                        conList.CreatedBy = UserId;
                        conList.IPAddress = lList.IPAddress;
                        if (grdvCommonData.Rows.Count > 0 || grdvOtherData.Rows.Count > 0 || grdvMetaData.Rows.Count > 0)
                        {
                            String strLmMasterDetails = String.Empty;
                            Int32 ColumnOrder = 0;
                            for (int i = 0; i < grdvCommonData.Rows.Count; i++)
                            {
                                HiddenField hdnCDataFieldId = (HiddenField)grdvCommonData.Rows[i].FindControl("hdnCDataFieldId");
                                ColumnOrder = ColumnOrder + 1;
                                strLmMasterDetails += hdnCDataFieldId.Value + "," + "Common" + "," + "true" + "," + ColumnOrder + "," + UserId + "," + lList.IPAddress + "|";
                            }

                            for (int i = 0; i < grdvOtherData.Rows.Count; i++)
                            {
                                HiddenField hdnODataFieldId = (HiddenField)grdvOtherData.Rows[i].FindControl("hdnODataFieldId");
                                ColumnOrder = ColumnOrder + 1;
                                strLmMasterDetails += hdnODataFieldId.Value + "," + "Other" + "," + "true" + "," + ColumnOrder + "," + UserId + "," + lList.IPAddress + "|";
                            }

                            for (int i = 0; i < grdvMetaData.Rows.Count; i++)
                            {
                                HiddenField hdnMDataFieldId = (HiddenField)grdvMetaData.Rows[i].FindControl("hdnMDataFieldId");
                                CheckBox chkMIsMandatory = (CheckBox)grdvMetaData.Rows[i].FindControl("chkMIsMandatory");
                                ColumnOrder = ColumnOrder + 1;
                                strLmMasterDetails += hdnMDataFieldId.Value + "," + "MetaData" + "," + ((chkMIsMandatory.Checked) ? "true" : "false") + "," + ColumnOrder + "," + UserId + "," + lList.IPAddress + "|";
                            }

                            if (strLmMasterDetails != "")
                            {
                                strLmMasterDetails = strLmMasterDetails.Remove(strLmMasterDetails.Length - 1);
                                if (strLmMasterDetails != "")
                                {
                                    objDAM = new DAMServices.ServiceContractClient();
                                    Int32 Returnval = objDAM.InsertLibraryMaster(lList, conList, strLmMasterDetails);
                                    if (Returnval > 0)
                                        Response.Redirect("~/library-master/index.aspx");
                                    else
                                    {
                                        confirmMsg.InnerHtml = "";
                                        divError.Attributes.Add("style", "display:block");
                                        divConfirm.Attributes.Add("style", "display:none");
                                        errorMsg.InnerHtml = Constant.UPDATE_ATTRIBUTE_STATUS_ALERT;
                                    }
                                }
                                else
                                {
                                    confirmMsg.InnerHtml = "";
                                    divError.Attributes.Add("style", "display:block");
                                    divConfirm.Attributes.Add("style", "display:none");
                                    errorMsg.InnerHtml = Constant.UPDATE_ATTRIBUTE_STATUS_ALERT;
                                }
                            }
                            else
                            {
                                confirmMsg.InnerHtml = "";
                                divError.Attributes.Add("style", "display:block");
                                divConfirm.Attributes.Add("style", "display:none");
                                errorMsg.InnerHtml = Constant.UPDATE_ATTRIBUTE_STATUS_ALERT;
                            }
                        }
                    }
                    else
                    { }
                }
                else
                { }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/library-new/index.aspx");
        }

        protected void chkMataDataAdd_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow Row = ((GridViewRow)((Control)sender).Parent.Parent);
            CheckBox chkMataDataSelectAll = (CheckBox)gdvMataData.HeaderRow.FindControl("chkMataDataSelectAll");
            CheckBox chkMataDataIsMandSelectAll = (CheckBox)gdvMataData.HeaderRow.FindControl("chkMataDataIsMandSelectAll");
            CheckBox chkMataDataAdd = (CheckBox)Row.FindControl("chkMataDataAdd");
            CheckBox chkMataDataIsMand = (CheckBox)Row.FindControl("chkMataDataIsMand");
            chkMataDataIsMand.Enabled = (chkMataDataAdd.Checked) ? true : false;
            if (!chkMataDataAdd.Checked)
            {
                chkMataDataIsMand.Checked = false;
                chkMataDataSelectAll.Checked = false;
                chkMataDataIsMandSelectAll.Checked = false;
            }
            gdvMataData.HeaderRow.TableSection = TableRowSection.TableHeader;
        }

        protected void chkMataDataIsMand_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow Row = ((GridViewRow)((Control)sender).Parent.Parent);
            CheckBox chkMataDataIsMandSelectAll = (CheckBox)gdvMataData.HeaderRow.FindControl("chkMataDataIsMandSelectAll");
            CheckBox chkMataDataIsMand = (CheckBox)Row.FindControl("chkMataDataIsMand");
            if (!chkMataDataIsMand.Checked)
                chkMataDataIsMandSelectAll.Checked = false;
            gdvMataData.HeaderRow.TableSection = TableRowSection.TableHeader;
        }

        protected void chkCommonAdd_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow Row = ((GridViewRow)((Control)sender).Parent.Parent);
            CheckBox chkCommonSelectAll = (CheckBox)gdvCommon.HeaderRow.FindControl("chkCommonSelectAll");
            CheckBox chkCommonAdd = (CheckBox)Row.FindControl("chkCommonAdd");
            if (!chkCommonAdd.Checked)
                chkCommonSelectAll.Checked = false;
            gdvCommon.HeaderRow.TableSection = TableRowSection.TableHeader;
            gdvOther.HeaderRow.TableSection = TableRowSection.TableHeader;
        }

        protected void chkOtherAdd_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow Row = ((GridViewRow)((Control)sender).Parent.Parent);
            CheckBox chkOtherSelectAll = (CheckBox)gdvOther.HeaderRow.FindControl("chkOtherSelectAll");
            CheckBox chkOtherAdd = (CheckBox)Row.FindControl("chkOtherAdd");
            if (!chkOtherAdd.Checked)
                chkOtherSelectAll.Checked = false;
            gdvOther.HeaderRow.TableSection = TableRowSection.TableHeader;
            gdvCommon.HeaderRow.TableSection = TableRowSection.TableHeader;
        }
        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }
    }
}