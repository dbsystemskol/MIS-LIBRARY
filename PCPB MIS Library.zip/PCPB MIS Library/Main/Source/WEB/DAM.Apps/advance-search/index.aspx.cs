﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AjaxControlToolkit;
using DAM.Apps.CommonClasses;
using System.Configuration;
using log4net;
using log4net.Config;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data;
using System.IO;
using System.Drawing.Imaging;
using QueryStringEncryption;
using System.Text;
using System.Globalization;
using System.Web.Configuration;

namespace DAM.Apps.advance_search
{
    public partial class index : System.Web.UI.Page
    {
        private Int32 UserId;
        private Int32 LibId;
        private Int32 TeamId;
        static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            ////HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);
                
                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() == "System Administrator" || Session["TeamName"].ToString() == "Application Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                UserId = Convert.ToInt32(Session["UserId"].ToString());
                LibId = Convert.ToInt32(Session["LibId"].ToString());
                TeamId = Convert.ToInt32(Session["TeamId"].ToString());
                lblTeamName.Text = "Role : " + Session["TeamName"].ToString();
                lblLibrary.Text = "Library : " + Session["Library"].ToString();
                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {

                //btnBack.NavigateUrl = HttpContext.Current.Request.UrlReferrer.ToString();

                PopulateContentType(LibId);
                BindNotification(TeamId, UserId, LibId);
                BindSaveSearch(UserId, LibId, TeamId);
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "hideresultKey", "<script>hideResult();</script>", false);
                String encURL = "";
                encURL = Request.RawUrl;
                if (!encURL.Contains("?"))
                    return;
                encURL = encURL.Substring(encURL.IndexOf('?') + 1);
                if (!encURL.Equals(""))
                {
                    encURL = DecryptQueryString(encURL);
                    String[] queryStr = encURL.Split('^');
                    String[] sText = queryStr[0].Split('~');    // Search text
                    String[] cType = queryStr[1].Split('~');   //Content Type
                    String[] sCriteria = queryStr[2].Split('~');   //Search criteria
                    BindAdvanceSearchResult(sText[1].ToString(),sCriteria[1].ToString(), Convert.ToInt32(cType[1]));
                    hdnContentTypeId.Value = cType[1].ToString();
                    hdnSearchText.Value = sText[1].ToString();
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "showresultKey", "<script>showResult();</script>", false);
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "hidesearchKey", "<script>hideSearch();</script>", false);
                }
            }
        }
        private void BindSaveSearch(Int32 UserId, Int32 LibId, Int32 TeamId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                gdvSaveSearch.DataSource = objDAM.GetSaveSearch(UserId, LibId, TeamId);
                gdvSaveSearch.DataBind();
                gdvSaveSearch.HeaderRow.TableSection = TableRowSection.TableHeader;

            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
            }
        }
        
        
        protected void gdvSaveSearch_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                if (e.CommandName == "_Search")
                {
                    GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
                    LinkButton lstText = (LinkButton)row.FindControl("btnSearch");
                    HiddenField hdnBindText = (HiddenField)row.FindControl("hdnBindText");
                    Session["AdvText"] = lstText.Text;
                    Session["AdvanceSearchText"] = e.CommandArgument;
                    Session["BindText"] = hdnBindText.Value;
                    BindSaveSearchValue(hdnBindText.Value);
                }

                else if (e.CommandName == "_Delete")
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    objDAM.DeleteSaveSearch(Convert.ToInt32(e.CommandArgument));
                    BindSaveSearch(UserId, LibId, TeamId);
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        private string[] GetPrivilegeDetail(Int32 privilege)
        {
            string[] privilegeArray = new string[4];
            switch (privilege)
            {
                case 2:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 3:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = "0";
                    break;
                case 8:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 10:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 11:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = UserId.ToString();
                    privilegeArray[2] = "No";
                    privilegeArray[3] = "0";
                    break;
                case 12:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = "0";
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 14:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = "0";
                    privilegeArray[2] = "No";
                    privilegeArray[3] = UserId.ToString();
                    break;
                case 15:
                    privilegeArray[0] = "Yes";
                    privilegeArray[1] = "0";
                    privilegeArray[2] = "No";
                    privilegeArray[3] = "0";
                    break;
            }
            return privilegeArray;
        }
        private void BindAdvanceSearchResult(String WhereClause,String SearchCriteria, Int32 ContentTypeId)
        {
            hdnContentTypeId.Value = ContentTypeId.ToString();
            hdnSearchText.Value = WhereClause;
            divSearchText.InnerText = "";
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            DAMServices.ServiceContractClient objDAM;
            DAMServices.FreeTextSearchFiles dt;
            DAMServices.FreeTextSearchFiles dtTag;
            DAMServices.FreeTextSearchFiles dtC;
            DAMServices.FreeTextSearchFiles dtCTag;
            DAMServices.FreeTextSearchFiles dtG;
            DAMServices.FreeTextSearchFiles dtGTag;
            String html = String.Empty;
            String tagHtml = String.Empty;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = new DAMServices.FreeTextSearchFiles();
                dtTag = new DAMServices.FreeTextSearchFiles();
                if (WhereClause.Length > 0 && ContentTypeId > 0)
                {
                    var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                    var searchPrivilegeAll = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();
                    int counter = 0;
                    for (int i = 0; i < searchPrivilegeAll.Count(); i++)
                    {
                        dtCTag = new DAMServices.FreeTextSearchFiles();
                        dtGTag = new DAMServices.FreeTextSearchFiles();
                        string[] privilage = GetPrivilegeDetail(searchPrivilegeAll[i].Permission);
                        dtCTag = objDAM.AdvanceSearch(WhereClause, privilage[0], searchPrivilegeAll[i].ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[1]), searchPrivilegeAll[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]),UserId);
                        dtGTag = objDAM.AdvanceSearch(WhereClause, privilage[2], searchPrivilegeAll[i].ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[3]), searchPrivilegeAll[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]),UserId);

                        if (counter == 0 && dtCTag.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dtTag.FreeTextSearchTable = dtCTag.FreeTextSearchTable.Copy();
                            counter++;
                        }
                        else if (counter == 0 && dtGTag.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dtTag.FreeTextSearchTable = dtGTag.FreeTextSearchTable.Copy();
                            counter++;
                        }
                        else if (counter > 0 && dtCTag.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dtTag.FreeTextSearchTable.Merge(dtCTag.FreeTextSearchTable);
                        }
                        else if (counter > 0 && dtGTag.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dtTag.FreeTextSearchTable.Merge(dtGTag.FreeTextSearchTable);
                        }
                        //if (i == 0)
                        //{                            
                        //    dtTag.FreeTextSearchTable = dtCTag.FreeTextSearchTable.Copy();
                        //    dtTag.FreeTextSearchTable.Merge(dtGTag.FreeTextSearchTable);
                        //}
                        //else
                        //{
                        //    dtTag.FreeTextSearchTable.Merge(dtCTag.FreeTextSearchTable);
                        //    dtTag.FreeTextSearchTable.Merge(dtGTag.FreeTextSearchTable);
                        //}
                    }
                    counter = 0;
                    var searchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search" && x.ContentTypeId == ContentTypeId).ToList();
                    for (int i = 0; i < searchPrivilege.Count(); i++)
                    {
                        dtC = new DAMServices.FreeTextSearchFiles();
                        dtG = new DAMServices.FreeTextSearchFiles();
                        
                        string[] privilage = GetPrivilegeDetail(searchPrivilege[i].Permission);
                        dtC = objDAM.AdvanceSearch(WhereClause, privilage[0], ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[1]), searchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]), UserId);
                        dtG = objDAM.AdvanceSearch(WhereClause, privilage[2], ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[3]), searchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]), UserId);
                        if (counter == 0 && dtC.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dt.FreeTextSearchTable = dtC.FreeTextSearchTable.Copy();
                            counter++;
                        }
                        else if (counter == 0 && dtG.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dt.FreeTextSearchTable = dtG.FreeTextSearchTable.Copy();
                            counter++;
                        }
                        //if (i == 0)
                        //{
                        //    dt.FreeTextSearchTable = dtC.FreeTextSearchTable.Copy();
                        //    dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);
                        //    //dtTag.FreeTextSearchTable = dtCTag.FreeTextSearchTable.Copy();
                        //    //dtTag.FreeTextSearchTable.Merge(dtGTag.FreeTextSearchTable);
                        //}
                        //else
                        //{
                        //    dt.FreeTextSearchTable.Merge(dtC.FreeTextSearchTable);
                        //    dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);
                        //    //dtTag.FreeTextSearchTable.Merge(dtCTag.FreeTextSearchTable);
                        //    //dtTag.FreeTextSearchTable.Merge(dtGTag.FreeTextSearchTable);
                        //}
                    }
                }
                else if (WhereClause.Length > 0 && ContentTypeId == 0)
                {
                     var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                    var searchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();
                    int counter = 0;
                    for (int i = 0; i < searchPrivilege.Count(); i++)
                    {
                        dtC = new DAMServices.FreeTextSearchFiles();
                        dtCTag = new DAMServices.FreeTextSearchFiles();
                        dtG = new DAMServices.FreeTextSearchFiles();
                        dtGTag = new DAMServices.FreeTextSearchFiles();
                        string[] privilage = GetPrivilegeDetail(searchPrivilege[i].Permission);
                        dtC = objDAM.AdvanceSearch(WhereClause, privilage[0], searchPrivilege[i].ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[1]), searchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]),UserId);
                        //dtCTag = dtC;

                        dtG = objDAM.AdvanceSearch(WhereClause, privilage[2], searchPrivilege[i].ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[3]), searchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]),UserId);
                        //dtGTag = dtG;
                        if (dtC.FreeTextSearchTable.Rows.Count > 0)
                            dtCTag = dtC;
                        if (dtG.FreeTextSearchTable.Rows.Count > 0)
                            dtGTag = dtG;
                        if (counter == 0 && dtC.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dt.FreeTextSearchTable = dtC.FreeTextSearchTable.Copy();
                            dtTag.FreeTextSearchTable = dtCTag.FreeTextSearchTable.Copy();
                            counter++;
                        }
                        else if (counter == 0 && dtG.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dt.FreeTextSearchTable = dtG.FreeTextSearchTable.Copy();
                            dtTag.FreeTextSearchTable = dtGTag.FreeTextSearchTable.Copy();
                            counter++;
                        }
                        else if (counter > 0 && dtC.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dtTag.FreeTextSearchTable.Merge(dtCTag.FreeTextSearchTable);
                        }
                        else if (counter > 0 && dtG.FreeTextSearchTable.Rows.Count > 0)
                        {
                            dtTag.FreeTextSearchTable.Merge(dtGTag.FreeTextSearchTable);
                        }
                        //if (i == 0)
                        //{
                        //    dt.FreeTextSearchTable = dtC.FreeTextSearchTable.Copy();
                        //    dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);
                        //    dtTag.FreeTextSearchTable = dtCTag.FreeTextSearchTable.Copy();
                        //    dtTag.FreeTextSearchTable.Merge(dtGTag.FreeTextSearchTable);
                        //}
                        //else
                        //{
                        //    dt.FreeTextSearchTable.Merge(dtC.FreeTextSearchTable);
                        //    dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);
                        //    dtTag.FreeTextSearchTable.Merge(dtCTag.FreeTextSearchTable);
                        //    dtTag.FreeTextSearchTable.Merge(dtGTag.FreeTextSearchTable);
                        //}
                    }
                }
                if (dtTag.FreeTextSearchTable.Rows.Count > 0)
                {
                    var groupedData = from b in dtTag.FreeTextSearchTable.AsEnumerable()
                                      group b by new
                                      {
                                          ContentType = b.Field<string>("ContentType"),
                                          ContentTypeId = b.Field<int>("ContentTypeId")
                                      } into g
                                      select new
                                      {
                                          TagId = g.Key.ContentTypeId,
                                          TagName = g.Key.ContentType,
                                          Count = g.Count()
                                      };
                    String encThisURL = String.Empty;
                    encThisURL = "../advance-search/index.aspx?" + EncryptQueryString(String.Format("sText~{0}^cType~{1}^sCriteria~{2}", WhereClause, 0, SearchCriteria));
                    //if (groupedData.Count() > 1 && ContentTypeId == 0)
                    //    tagHtml += String.Format("<li><a href='{2}' >{0} ({1})</a></li>", "All", dtTag.FreeTextSearchTable.Rows.Count, encThisURL);
                    //else if (ContentTypeId == 0)
                    //tagHtml += String.Format("<li><a href='{2}' >{0} ({1})</a></li>", "All", dtTag.FreeTextSearchTable.Rows.Count, encThisURL);
                    foreach (var item in groupedData)
                    {
                        encThisURL = "../advance-search/index.aspx?" + EncryptQueryString(String.Format("sText~{0}^cType~{1}^sCriteria~{2}", WhereClause, item.TagId, SearchCriteria));
                        tagHtml += String.Format("<li><a href='{2}' >{0} ({1})</a></li>", item.TagName, item.Count, encThisURL);
                    }
                    ulTag.InnerHtml = tagHtml;
                }
                if (dt.FreeTextSearchTable.Rows.Count > 0)
                {
                    divSearchText.InnerText = "Results for " + SearchCriteria;
                    html = "<table id='tblSearchResult' width='100%' cellpadding='0' cellspacing='0' ><thead><tr>";
                    foreach (DataColumn dcol in dt.FreeTextSearchTable.Columns)
                    {
                        if (dcol.ColumnName == "Confidential" || dcol.ColumnName == "ContentTypeId" || dcol.ColumnName == "DocId")
                        { }
                        //else if(dcol.ColumnName == "DocId")
                        //{
                        //    html += String.Format("<th>{0}</th>", "Doc No.");
                        //}
                        //else if (dcol.ColumnName == "ContentType")
                        //{
                        //    html += String.Format("<th style='display:none'>{0}</th>", dcol.ColumnName);
                        //}
                        else
                            html += String.Format("<th>{0}</th>", dcol.ColumnName);
                    }
                    html += String.Format("<th>{0}</th>", "");
                    html += "</tr></thead><tbody id='tbltbody'>";
                    String encURL = String.Empty;
                    foreach (DataRow row in dt.FreeTextSearchTable.Rows)
                    {
                        html += "<tr>";
                        foreach (DataColumn column in dt.FreeTextSearchTable.Columns)
                        {
                            if (column.ColumnName == "Confidential" || column.ColumnName == "ContentTypeId" || column.ColumnName == "DocId")
                            { }
                            //else if (column.ColumnName == "DocId")
                            //{
                            //    html += "<td>";
                            //    html += row[column.ColumnName];
                            //    html += "</td>";
                            //}
                            else if (column.ColumnName == "Title")
                            {
                                if (row["Confidential"].ToString() == "Yes")
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += " &nbsp;<img class='lock' title='Locked' alt='Locked' src='../img/nav-icons/icon_lock.png'></td>";
                                }
                                else if (row["Confidential"].ToString() == "No")
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += "</td>";
                                }
                                else
                                {
                                    html += "<td>";
                                    html += row[column.ColumnName];
                                    html += "</td>";
                                }
                            }
                            //else if (column.ColumnName == "ContentType")
                            //{
                            //    html += String.Format("<td style='display:none'>{0}</td>", row[column.ColumnName]);
                            //}
                            else
                            {
                                html += "<td>";
                                html += row[column.ColumnName];
                                html += "</td>";
                            }
                        }
                        encURL = "../file-preview/index.aspx?" + EncryptQueryString(String.Format("fid={0}&docid={1}",0, row["DocId"]));
                        html += "<td>";
                        html += String.Format("<a href='{0}'><img src='../img/nav-icons/view.png' alt=''></a>", encURL);
                        html += "</td>";
                        html += "</tr>";
                    }
                    html += "</tbody></table>";
                    divSearch.InnerHtml = "";
                    divSearch.InnerHtml = html;
                }
                else
                {
                    divSearch.InnerHtml = "";
                    ulTag.InnerHtml = "";
                    divConfirm.Attributes.Add("style", "display:none");
                    divError.Attributes.Add("style", "display:block");
                    confirmMsg.InnerHtml = "";
                    errorMsg.InnerHtml = "No data found.";
                    divSearchText.InnerText = "No results for " + SearchCriteria;
                }
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "Key", "<script>tableSorting();</script>", false);
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "hidesearchKey", "<script>hideSearch();</script>", false);
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "showresultKey", "<script>showResult();</script>", false);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void btnSearchAgain_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);
            //Response.Redirect("~/advance-search/index.aspx",true);
        }
        private void BindNotification(Int32 TeamId, Int32 VisiterUserId, Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            StringBuilder sb;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                sb = new StringBuilder();
                var mList = objDAM.GetUserNotification(TeamId, VisiterUserId, LibId);
                if (mList.Count() > 0)
                {                    
                    var list = mList.GroupBy(a => a.NotificationType)
                                .Select(n => new { Text = n.Key, Value = n.Count() }).ToList();
                    notificationCount.InnerText = list.Count().ToString();
                    sb.Append("<ul class='jq-dropdown-menu'>");

                    foreach (var l in list)
                    {
                        String encURL = String.Empty;
                        encURL = "../notification-list/index.aspx?" + EncryptQueryString(String.Format("sType={0}", l.Text));
                        sb.AppendFormat("<li><a href='{0}'>{1} ({2})</a></li>", encURL, l.Text, l.Value);
                    }
                    sb.Append("</ul>");
                    jqdropdown4.InnerHtml = sb.ToString();
                }
                else
                {
                    notificationCount.InnerText = "0";
                    String abc = String.Empty;
                    abc += abc + @"<ul class='jq-dropdown-menu'>
                                <li><a href='#'>Notification 1</a></li>
                                <li><a href='#'>Notification 2</a></li>
                                <li><a href='#'>Notification 3</a></li>
                                </ul>";
                    jqdropdown4.InnerHtml = "";
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                objDAM = null;
                sb = null;
            }
        }
        private void PopulateContentType(Int32 LibId)
        {
            DAMServices.ServiceContractClient objDAM;
            List<DAMServices.ContentTypeInfo> mList;
            try
            {
                mList = new List<DAMServices.ContentTypeInfo>();
                objDAM = new DAMServices.ServiceContractClient();
                mList = objDAM.GetContentTypeByLibId(LibId).ToList();
                mList.Insert(0, new DAMServices.ContentTypeInfo
                {
                    ContentTypeId = -1,
                    Description = "Entire Library",
                    IsActive = true,
                });
                mList.Insert(1, new DAMServices.ContentTypeInfo
                {
                    ContentTypeId = 0,
                    Description = "Common",
                    IsActive = true,
                });   
                var list = mList.Where(x => x.IsActive == true);
                if (list.Count() > 0)
                {
                    rblContentType.DataSource = list;
                    rblContentType.DataValueField = "ContentTypeId";
                    rblContentType.DataTextField = "Description";
                    rblContentType.DataBind();
                    if(Session["ContentType"] == null)
                        if (rblContentType.Items.Count > 0)
                            rblContentType.Items[0].Selected = true;
                }
                else
                {
                    //lblErrorMsg.Text = Constant.BRAND_UNAVAILABLE;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            BindControls();
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "hideresultKey", "<script>hideResult();</script>", false);
        }
        private void BindSaveSearchValue(String BindText)
        {
            try
            {
                String[] bindTextList = BindText.Split('^');
                String[] contentype = bindTextList[0].Split(':');
                for (int i = 0; i < rblContentType.Items.Count; i++)
                {
                    if (rblContentType.Items[i].Value == contentype[1])
                    {
                        rblContentType.Items[i].Selected = true;
                        Session["ContentType"] = contentype[1];
                        break;
                    }
                }
                for (int j = 1; j < bindTextList.Count(); j++)
                {
                    String[] metadata = bindTextList[j].Split(':');
                    Session[metadata[0].ToString()] = metadata[1].ToString();
                }
                
                BindControls();
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {

            }
        }
        private void BindControls()
        {
            plcHldCommon.Controls.Clear(); //to remove all controls
            plcHldMetadata.Controls.Clear();
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                int contentype = 0;
                if(IsSearchAgain.Value == "1")
                {
                    contentype = Convert.ToInt32(rblContentType.SelectedValue);
                }
                else if (Session["ContentType"] != null && IsSearchAgain.Value != "1")
                {
                    contentype = Convert.ToInt32(Session["ContentType"].ToString());
                    for (int i = 0; i < rblContentType.Items.Count; i++)
                    {
                        if (rblContentType.Items[i].Value == contentype.ToString())
                        {
                            rblContentType.Items[i].Selected = true;
                            Session.Remove("ContentType");
                            break;
                        }
                    }
                }
                else
                    contentype = Convert.ToInt32(rblContentType.SelectedValue);
                if (contentype > 0)
                {
                    var list = objDAM.GetLibraryAttributeSetByContentTypeId(contentype);
                    var mList = list.Where(x => x.IsActive == true);
                    var commonList = mList.Where(x => x.AttributeType != "MetaData").ToList();
                    var metadataList = mList.Where(x => x.AttributeType == "MetaData").ToList();
                    if (commonList.Count() > 0)
                    {
                        for (int i = 0; i < commonList.Count(); i++)
                        {
                            generateDynamicControls(commonList[i].AttributeType, commonList[i].FieldId, commonList[i].FieldCaption, commonList[i].FieldType, commonList[i].IsMandatory, i % 2);
                        }
                    }
                    if (metadataList.Count() > 0)
                    {
                        for (int i = 0; i < metadataList.Count(); i++)
                        {
                            generateDynamicControls(metadataList[i].AttributeType, metadataList[i].FieldId, metadataList[i].FieldCaption, metadataList[i].FieldType, metadataList[i].IsMandatory, i % 2);
                        }
                    }
                }
                else if (contentype == 0)
                {
                    var list = objDAM.GetCommonLibraryAttributeSet(LibId);
                    var commonList = list.Where(x => x.AttributeType != "MetaData").ToList();
                    if (commonList.Count() > 0)
                    {
                        for (int i = 0; i < commonList.Count(); i++)
                        {
                            generateDynamicControls(commonList[i].AttributeType, commonList[i].FieldId, commonList[i].FieldCaption, commonList[i].FieldType, commonList[i].IsMandatory, i % 2);
                        }
                    }
                }
                else if (contentype == -1)
                {
                    var list = objDAM.GetLibraryAttributeSetByLibId(LibId);
                    var mList = list.Where(x => x.IsActive == true).ToList();
                    var commonList = mList.Where(x => x.AttributeType != "MetaData").ToList();
                    var metadataList = mList.Where(x => x.AttributeType == "MetaData").ToList();
                    if (commonList.Count() > 0)
                    {
                        for (int i = 0; i < commonList.Count(); i++)
                        {
                            generateDynamicControls(commonList[i].AttributeType, commonList[i].FieldId, commonList[i].FieldCaption, commonList[i].FieldType, commonList[i].IsMandatory, i % 2);
                        }
                    }
                    if (metadataList.Count() > 0)
                    {
                        for (int i = 0; i < metadataList.Count(); i++)
                        {
                            generateDynamicControls(metadataList[i].AttributeType, metadataList[i].FieldId, metadataList[i].FieldCaption, metadataList[i].FieldType, metadataList[i].IsMandatory, i % 2);
                        }
                    }
                }
                
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void btnSaveSearch_Click(object sender, EventArgs e)
        {
            DAMServices.SaveSearchInfo dList;
            DAMServices.ServiceContractClient objDAM;
            try
            {
                dList = new DAMServices.SaveSearchInfo();
                objDAM = new DAMServices.ServiceContractClient();
                dList.UserId = UserId;
                dList.LibId = LibId;
                dList.TeamId = TeamId;
                dList.WhereText = Session["AdvanceSearchText"].ToString();
                dList.SearchText = Session["AdvText"].ToString();
                String BindText = Session["BindText"].ToString();
                BindText = BindText.Remove(BindText.Length - 1);
                dList.BindText = BindText;
                Int32 ReturnVal = objDAM.InsertSaveSearch(dList);
                if (ReturnVal > 0)
                {
                    btnSaveSearch.Visible = false;
                    BindSaveSearch(UserId, LibId, TeamId);
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            finally
            {
                dList = null;
                objDAM = null;
            }
        }
        public void generateDynamicControls(String AttributeType, Int32 FieldId, String FieldName, String FieldType, Boolean IsRequired, int bgCss)
        {
            ViewState["control"] = FieldName + FieldId;
            switch (FieldType.ToLower())
            {
                case "texttype":
                    createDynamicTextBox(AttributeType, FieldId, FieldName, IsRequired, bgCss);
                    break;
                case "listtype":
                    createDynamicDropDownList(AttributeType, FieldId, FieldName, IsRequired, bgCss);
                    break;
                case "datetimetype":
                    createDynamicDateTime(AttributeType, FieldId, FieldName, IsRequired, bgCss);
                    break;
                case "textareatype":
                    createDynamicTextArea(AttributeType, FieldId, FieldName, IsRequired, bgCss);
                    break;
                case "numerictype":
                    createDynamicNumericTextBox(AttributeType, FieldId, FieldName, IsRequired, bgCss);
                    break;
                default:
                    break;
            }
        }
        public void createDynamicTextBox(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss)
        {
            HtmlGenericControl tr = new HtmlGenericControl("tr");
            HtmlGenericControl td1 = new HtmlGenericControl("td");
            td1.Attributes.Add("style", "width:20%");
            if (bgCss == 0)
                tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
            else
                tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
            Label lbl = new Label();
            lbl.ID = "lbl" + FieldId.ToString();
            lbl.Text = FieldName;
            lbl.Font.Bold = true;
            td1.Controls.Add(lbl);
            tr.Controls.Add(td1);

            HtmlGenericControl td2 = new HtmlGenericControl("td");
            TextBox txtBox = new TextBox();
            txtBox.ID = "txt" + FieldId.ToString();
            if (Session["txt" + FieldId.ToString()] != null)
            {
                txtBox.Text = Session["txt" + FieldId.ToString()].ToString();
                Session.Remove("txt" + FieldId.ToString());
            }
            td2.Controls.Add(txtBox);
            tr.Controls.Add(td2);
            tr.EnableViewState = true;
            tr.ViewStateMode = ViewStateMode.Enabled;
            if (AttributeType == "MetaData")
                plcHldMetadata.Controls.Add(tr);
            else
                plcHldCommon.Controls.Add(tr);
        }

        public void createDynamicDropDownList(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss)
        {
            HtmlGenericControl tr = new HtmlGenericControl("tr");
            HtmlGenericControl td1 = new HtmlGenericControl("td");
            if (bgCss == 0)
                tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
            else
                tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
            td1.Attributes.Add("style", "width:20%");
            Label lbl = new Label();
            lbl.ID = "lbl" + FieldId.ToString();
            lbl.Text = FieldName;
            lbl.Font.Bold = true;
            td1.Controls.Add(lbl);
            tr.Controls.Add(td1);

            HtmlGenericControl td2 = new HtmlGenericControl("td");
            DropDownList ddl = new DropDownList();
            ddl.ID = "ddl" + FieldId.ToString();
            ddl.Width = 270;
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var list = objDAM.GetLookupMasterByFieldId(FieldId, LibId).Where(x => x.IsActive == true).ToList();
                var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                var SearchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();
                if (SearchPrivilege[0].IsBrandCategoryMapped)
                {
                    if (FieldId == 1 || FieldId == 2)
                    {
                        var mList = objDAM.GetUserBrandCategoryByFieldId(FieldId, UserId).ToList();
                        if (mList.Count() > 0)
                        {
                            ddl.DataSource = mList;
                            ddl.DataValueField = "LookupId";
                            ddl.DataTextField = "FieldValue";
                            ddl.DataBind();
                        }
                        else
                        {
                            //lblErrorMsg.Text = Constant.BRAND_UNAVAILABLE;
                        }
                    }
                    else
                    {
                        var mList = list.Where(x => x.IsActive == true);
                        if (mList.Count() > 0)
                        {
                            ddl.DataSource = mList;
                            ddl.DataValueField = "LookupId";
                            ddl.DataTextField = "FieldValue";
                            ddl.DataBind();
                        }
                        else
                        {
                            //lblErrorMsg.Text = Constant.BRAND_UNAVAILABLE;
                        }
                    }
                }
                else
                {
                    var mList = list.Where(x => x.IsActive == true);
                    if (mList.Count() > 0)
                    {
                        ddl.DataSource = mList;
                        ddl.DataValueField = "LookupId";
                        ddl.DataTextField = "FieldValue";
                        ddl.DataBind();
                    }
                    else
                    {
                        //lblErrorMsg.Text = Constant.BRAND_UNAVAILABLE;
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
            
            if (Session["ddl" + FieldId.ToString()] != null)
            {
                if (ddl.Items.FindByText(Session["ddl" + FieldId.ToString()].ToString()) != null)
                    ddl.Items.FindByText(Session["ddl" + FieldId.ToString()].ToString()).Selected = true;
                Session.Remove("ddl" + FieldId.ToString());
            }
            if (FieldName == "Confidential")
            {
                if (Convert.ToInt32(rblContentType.SelectedValue) > 0)
                {
                    var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                    var searchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search" && x.ContentTypeId == Convert.ToInt32(rblContentType.SelectedValue)).ToList();
                    if (GetSelfPrivilege(searchPrivilege[0].Permission) == 0 || GetSelfPrivilege(searchPrivilege[0].Permission) == 1)
                        tr.Attributes.Add("style", "display: none");
                    else if (GetSelfPrivilege(searchPrivilege[0].Permission) == 2)
                        ddl.Items.Remove(ddl.Items.FindByText("No"));
                    else if (GetSelfPrivilege(searchPrivilege[0].Permission) == 3)
                        ddl.Items.Insert(0, new ListItem("--Select--", "0"));
                }
                else
                    ddl.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
                ddl.Items.Insert(0, new ListItem("--Select--", "0"));
            
            td2.Controls.Add(ddl);
            tr.Controls.Add(td2);
            tr.EnableViewState = true;
            tr.ViewStateMode = ViewStateMode.Enabled;
            if (AttributeType == "MetaData")
                plcHldMetadata.Controls.Add(tr);
            else
                plcHldCommon.Controls.Add(tr);
        }
        private int GetSelfPrivilege(Int32 privilege)
        {
            int privilegeValue = 0;
            switch (privilege)
            {
                case 2:
                case 3:
                    privilegeValue = 1;
                    break;
                case 8:
                case 12:
                    privilegeValue = 2;
                    break;
                case 10:
                case 11:
                case 14:
                case 15:
                    privilegeValue = 3;
                    break;
            }
            return privilegeValue;
        }
        public void createDynamicDateTime(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss)
        {
            HtmlGenericControl tr = new HtmlGenericControl("tr");
            HtmlGenericControl td1 = new HtmlGenericControl("td");
            if (bgCss == 0)
                tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
            else
                tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
            td1.Attributes.Add("style", "width:20%");
            Label lbl = new Label();
            lbl.ID = "lbl" + FieldId.ToString();
            lbl.Text = FieldName;
            lbl.Font.Bold = true;
            td1.Controls.Add(lbl);
            tr.Controls.Add(td1);

            Label lblTo = new Label();
            lblTo.Text = "To";
            lblTo.Font.Bold = true;

            HtmlGenericControl td2 = new HtmlGenericControl("td");
            TextBox txtBox1 = new TextBox();
            txtBox1.ID = "txtFrom" + FieldId.ToString();
            txtBox1.CssClass = "date";
            txtBox1.Attributes.Add("style", "background-image: url('../img/nav-icons/calender.png');background-position: right center;background-repeat: no-repeat");
            TextBox txtBox2 = new TextBox();
            txtBox2.ID = "txtTo" + FieldId.ToString();
            txtBox2.CssClass = "date";
            txtBox2.Attributes.Add("style", "background-image: url('../img/nav-icons/calender.png');background-position: right center;background-repeat: no-repeat");
            if (Session["txtFrom" + FieldId.ToString()] != null)
            {
                txtBox1.Text = Session["txtFrom" + FieldId.ToString()].ToString();
                Session.Remove("txtFrom" + FieldId.ToString());
            }
            if (Session["txtTo" + FieldId.ToString()] != null)
            {
                txtBox2.Text = Session["txtTo" + FieldId.ToString()].ToString();
                Session.Remove("txtTo" + FieldId.ToString());
            }
            td2.Controls.Add(txtBox1);
            td2.Controls.Add(lblTo);
            td2.Controls.Add(txtBox2);
            tr.Controls.Add(td2);
            tr.EnableViewState = true;
            tr.ViewStateMode = ViewStateMode.Enabled;
            if (AttributeType == "MetaData")
                plcHldMetadata.Controls.Add(tr);
            else
                plcHldCommon.Controls.Add(tr);
        }

        public void createDynamicTextArea(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss)
        {
            HtmlGenericControl tr = new HtmlGenericControl("tr");
            HtmlGenericControl td1 = new HtmlGenericControl("td");
            if (bgCss == 0)
                tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
            else
                tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
            td1.Attributes.Add("style", "width:20%");
            Label lbl = new Label();
            lbl.ID = "lbl" + FieldId.ToString();
            lbl.Text = FieldName;
            lbl.Font.Bold = true;
            td1.Controls.Add(lbl);
            tr.Controls.Add(td1);

            HtmlGenericControl td2 = new HtmlGenericControl("td");
            TextBox txtBox = new TextBox();
            txtBox.ID = "txt" + FieldId.ToString();
            txtBox.TextMode = TextBoxMode.MultiLine;
            if (Session["txt" + FieldId.ToString()] != null)
            {
                txtBox.Text = Session["txt" + FieldId.ToString()].ToString();
                Session.Remove("txt" + FieldId.ToString());
            }
            td2.Controls.Add(txtBox);
            tr.Controls.Add(td2);
            tr.EnableViewState = true;
            tr.ViewStateMode = ViewStateMode.Enabled;
            if (AttributeType == "MetaData")
                plcHldMetadata.Controls.Add(tr);
            else
                plcHldCommon.Controls.Add(tr);
        }

        public void createDynamicNumericTextBox(String AttributeType, Int32 FieldId, String FieldName, Boolean IsRequired, int bgCss)
        {
            HtmlGenericControl tr = new HtmlGenericControl("tr");
            HtmlGenericControl td1 = new HtmlGenericControl("td");
            if (bgCss == 0)
                tr.Attributes.Add("style", "background-color: rgb(250, 250, 250)");
            else
                tr.Attributes.Add("style", "background-color: rgb(255, 255, 255)");
            td1.Attributes.Add("style", "width:20%");
            Label lbl = new Label();
            lbl.ID = "lbl" + FieldId.ToString();
            lbl.Text = FieldName;
            lbl.Font.Bold = true;
            td1.Controls.Add(lbl);
            tr.Controls.Add(td1);

            HtmlGenericControl td2 = new HtmlGenericControl("td");
            TextBox txtBox = new TextBox();
            txtBox.ID = "txt" + FieldId.ToString();
            txtBox.Attributes.Add("onkeypress", "return allowOnlyNumber(event);");
            if (Session["txt" + FieldId.ToString()] != null)
            {
                txtBox.Text = Session["txt" + FieldId.ToString()].ToString();
                Session.Remove("txt" + FieldId.ToString());
            }
            td2.Controls.Add(txtBox);
            tr.Controls.Add(td2);
            tr.EnableViewState = true;
            tr.ViewStateMode = ViewStateMode.Enabled;
            if (AttributeType == "MetaData")
                plcHldMetadata.Controls.Add(tr);
            else
                plcHldCommon.Controls.Add(tr);
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            DAMServices.ServiceContractClient objDAM;
            try
            {                
                objDAM = new DAMServices.ServiceContractClient();
                StringBuilder strWhereClause = new StringBuilder();
                StringBuilder strSearchText = new StringBuilder();
                StringBuilder strBindText = new StringBuilder();
                strSearchText.AppendFormat("{0} :", rblContentType.SelectedItem.Text);
                Session["ContentType"] = rblContentType.SelectedValue;
                if (Convert.ToInt32(rblContentType.SelectedValue) > 0)
                {
                    strBindText.AppendFormat("{0}:{1}^", "ContentType", rblContentType.SelectedValue);
                    var mList = objDAM.GetLibraryAttributeSetByContentTypeId(Convert.ToInt32(rblContentType.SelectedValue));
                    //var mList = list.Where(x => x.IsActive = true).ToList();
                    for (int i = 0; i < mList.Count(); i++)
                    {
                        if (mList[i].AttributeType == "MetaData") //find in metadata tab
                        {
                            switch (mList[i].FieldType.ToLower())
                            {
                                case "texttype":
                                case "textareatype":                                    
                                    TextBox txt = (TextBox)plcHldMetadata.FindControl("txt" + mList[i].FieldId.ToString());
                                    Session["txt" + mList[i].FieldId.ToString()] = txt.Text;
                                    if (txt.Text.Length > 0)
                                    {
                                        Label lbl = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                        if(strWhereClause.Length == 0)
                                            strWhereClause.AppendFormat(" [{0}] like '%{1}%' ", lbl.Text, txt.Text);
                                        else
                                            strWhereClause.AppendFormat(" AND [{0}] like '%{1}%' ", lbl.Text, txt.Text);

                                        strSearchText.AppendFormat("({0} - {1})", lbl.Text,txt.Text);

                                        strBindText.AppendFormat("{0}:{1}^", "txt" + mList[i].FieldId, txt.Text);
                                    }
                                    break;
                                case "numerictype":
                                    TextBox txt1 = (TextBox)plcHldMetadata.FindControl("txt" + mList[i].FieldId.ToString());
                                    Session["txt" + mList[i].FieldId.ToString()] = txt1.Text;
                                    if (txt1.Text.Length > 0)
                                    {
                                        Label lbl = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                        if (strWhereClause.Length == 0)
                                            strWhereClause.AppendFormat(" [{0}] = '{1}' ", lbl.Text, txt1.Text);
                                        else
                                            strWhereClause.AppendFormat(" AND [{0}] = '{1}' ", lbl.Text, txt1.Text);
                                        
                                        strSearchText.AppendFormat("({0} - {1})", lbl.Text, txt1.Text);

                                        strBindText.AppendFormat("{0}:{1}^", "txt" + mList[i].FieldId, txt1.Text);
                                    }
                                    break;
                                case "datetimetype":
                                    TextBox txtF = (TextBox)plcHldMetadata.FindControl("txtFrom" + mList[i].FieldId.ToString());
                                    TextBox txtT = (TextBox)plcHldMetadata.FindControl("txtTo" + mList[i].FieldId.ToString());
                                    Session["txtFrom" + mList[i].FieldId.ToString()] = txtF.Text;
                                    Session["txtTo" + mList[i].FieldId.ToString()] = txtT.Text;
                                    Boolean fromflag;
                                    Boolean toflag;
                                    DateTime fromdate;
                                    DateTime todate;
                                    if (txtF.Text.Length > 0 && txtT.Text.Length > 0)
                                    {
                                        fromflag = DateTime.TryParse(Convert.ToDateTime(txtF.Text, new CultureInfo("hi-IN").DateTimeFormat).ToString(), out fromdate);
                                        toflag = DateTime.TryParse(Convert.ToDateTime(txtT.Text, new CultureInfo("hi-IN").DateTimeFormat).ToString(), out todate);
                                        if (!fromflag)
                                        {
                                            Label lbl1 = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                            divConfirm.Attributes.Add("style", "display:none");
                                            divError.Attributes.Add("style", "display:block");
                                            confirmMsg.InnerHtml = "";
                                            errorMsg.InnerHtml = "Invalid " + lbl1.Text;
                                            return;
                                        }
                                        if (!toflag)
                                        {
                                            Label lbl1 = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                            divConfirm.Attributes.Add("style", "display:none");
                                            divError.Attributes.Add("style", "display:block");
                                            confirmMsg.InnerHtml = "";
                                            errorMsg.InnerHtml = "Invalid " + lbl1.Text;
                                            return;
                                        }
                                        if (fromdate > todate)
                                        {
                                            Label lbl1 = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                            divConfirm.Attributes.Add("style", "display:none");
                                            divError.Attributes.Add("style", "display:block");
                                            confirmMsg.InnerHtml = "";
                                            errorMsg.InnerHtml = "Invalid " + lbl1.Text;
                                            return;
                                        }

                                        Label lbl = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                        if (strWhereClause.Length == 0)
                                            strWhereClause.AppendFormat(" (CONVERT(datetime,[{0}],105) BETWEEN CONVERT(datetime,'{1}',105) and CONVERT(datetime,'{2}',105)) ", lbl.Text, txtF.Text, txtT.Text);
                                        else
                                            strWhereClause.AppendFormat(" AND (CONVERT(datetime,[{0}],105) BETWEEN CONVERT(datetime,'{1}',105) and CONVERT(datetime,'{2}',105)) ", lbl.Text, txtF.Text, txtT.Text);

                                        
                                        strSearchText.AppendFormat("({0} - {1} AND {2})", lbl.Text, txtF.Text, txtT.Text);

                                        strBindText.AppendFormat("{0}:{1}^", "txtFrom" + mList[i].FieldId, txtF.Text);
                                        strBindText.AppendFormat("{0}:{1}^", "txtTo" + mList[i].FieldId, txtT.Text);
                                    }
                                    break;
                                case "listtype":
                                    DropDownList ddl = (DropDownList)plcHldMetadata.FindControl("ddl" + mList[i].FieldId.ToString());
                                    Session["ddl" + mList[i].FieldId.ToString()] = ddl.SelectedItem.Text;
                                    if (ddl.SelectedIndex > 0)
                                    {
                                        Label lbl = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                        if (strWhereClause.Length == 0)
                                            strWhereClause.AppendFormat(" [{0}] = '{1}' ", lbl.Text, ddl.SelectedItem);
                                        else
                                            strWhereClause.AppendFormat(" AND [{0}] = '{1}' ", lbl.Text, ddl.SelectedItem);

                                        
                                        strSearchText.AppendFormat("({0} - {1})", lbl.Text, ddl.SelectedItem);

                                        strBindText.AppendFormat("{0}:{1}^", "ddl" + mList[i].FieldId, ddl.SelectedItem);
                                    }
                                    break;
                            }
                        }
                        else                                    //find in uploads tab
                        {
                            switch (mList[i].FieldType.ToLower())
                            {
                                case "texttype":
                                case "textareatype":
                                    TextBox txt = (TextBox)plcHldCommon.FindControl("txt" + mList[i].FieldId.ToString());
                                    Session["txt" + mList[i].FieldId.ToString()] = txt.Text;
                                    if (txt.Text.Length > 0)
                                    {
                                        Label lbl = (Label)plcHldCommon.FindControl("lbl" + mList[i].FieldId.ToString());
                                        if (strWhereClause.Length == 0)
                                            strWhereClause.AppendFormat(" [{0}] like '%{1}%' ", lbl.Text, txt.Text);
                                        else
                                            strWhereClause.AppendFormat(" AND [{0}] like '%{1}%' ", lbl.Text, txt.Text);
                                        
                                        strSearchText.AppendFormat("({0} - {1})", lbl.Text, txt.Text);

                                        strBindText.AppendFormat("{0}:{1}^", "txt" + mList[i].FieldId, txt.Text);
                                    }
                                    break;
                                case "numerictype":
                                    TextBox txt1 = (TextBox)plcHldCommon.FindControl("txt" + mList[i].FieldId.ToString());
                                    Session["txt" + mList[i].FieldId.ToString()] = txt1.Text;
                                    if (txt1.Text.Length > 0)
                                    {
                                        Label lbl = (Label)plcHldCommon.FindControl("lbl" + mList[i].FieldId.ToString());
                                        if (strWhereClause.Length == 0)
                                            strWhereClause.AppendFormat(" [{0}] = '{1}' ", lbl.Text, txt1.Text);
                                        else
                                            strWhereClause.AppendFormat(" AND  [{0}] = '{1}' ", lbl.Text, txt1.Text);
                                        
                                        strSearchText.AppendFormat("({0} - {1})", lbl.Text, txt1.Text);

                                        strBindText.AppendFormat("{0}:{1}^", "txt" + mList[i].FieldId, txt1.Text);
                                    }
                                    break;
                                case "datetimetype":
                                    TextBox txtF = (TextBox)plcHldCommon.FindControl("txtFrom" + mList[i].FieldId.ToString());
                                    TextBox txtT = (TextBox)plcHldCommon.FindControl("txtTo" + mList[i].FieldId.ToString());
                                    Session["txtFrom" + mList[i].FieldId.ToString()] = txtF.Text;
                                    Session["txtTo" + mList[i].FieldId.ToString()] = txtT.Text;
                                    Boolean fromflag;
                                    Boolean toflag;
                                    DateTime fromdate;
                                    DateTime todate;
                                    if (txtF.Text.Length > 0 && txtT.Text.Length > 0)
                                    {
                                        fromflag = DateTime.TryParse(Convert.ToDateTime(txtF.Text, new CultureInfo("hi-IN").DateTimeFormat).ToString(), out fromdate);
                                        toflag = DateTime.TryParse(Convert.ToDateTime(txtT.Text, new CultureInfo("hi-IN").DateTimeFormat).ToString(), out todate);
                                        if (!fromflag)
                                        {
                                            Label lbl1 = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                            divConfirm.Attributes.Add("style", "display:none");
                                            divError.Attributes.Add("style", "display:block");
                                            confirmMsg.InnerHtml = "";
                                            errorMsg.InnerHtml = "Invalid " + lbl1.Text;
                                            return;
                                        }
                                        if (!toflag)
                                        {
                                            Label lbl1 = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                            divConfirm.Attributes.Add("style", "display:none");
                                            divError.Attributes.Add("style", "display:block");
                                            confirmMsg.InnerHtml = "";
                                            errorMsg.InnerHtml = "Invalid " + lbl1.Text;
                                            return;
                                        }
                                        if (fromdate > todate)
                                        {
                                            Label lbl1 = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                            divConfirm.Attributes.Add("style", "display:none");
                                            divError.Attributes.Add("style", "display:block");
                                            confirmMsg.InnerHtml = "";
                                            errorMsg.InnerHtml = "Invalid " + lbl1.Text;
                                            return;
                                        }
                                        Label lbl = (Label)plcHldCommon.FindControl("lbl" + mList[i].FieldId.ToString());
                                        if (strWhereClause.Length == 0)
                                            strWhereClause.AppendFormat(" (CONVERT(datetime,[{0}],105) BETWEEN CONVERT(datetime,'{1}',105) and CONVERT(datetime,'{2}',105)) ", lbl.Text, txtF.Text, txtT.Text);
                                        else
                                            strWhereClause.AppendFormat(" AND (CONVERT(datetime,[{0}],105) BETWEEN CONVERT(datetime,'{1}',105) and CONVERT(datetime,'{2}',105)) ", lbl.Text, txtF.Text, txtT.Text);
                                        
                                        strSearchText.AppendFormat("({0} - {1} AND {2})", lbl.Text, txtF.Text, txtT.Text);

                                        strBindText.AppendFormat("{0}:{1}^", "txtFrom" + mList[i].FieldId, txtF.Text);
                                        strBindText.AppendFormat("{0}:{1}^", "txtTo" + mList[i].FieldId, txtT.Text);
                                    }
                                    break;
                                case "listtype":
                                    DropDownList ddl = (DropDownList)plcHldCommon.FindControl("ddl" + mList[i].FieldId.ToString());
                                    Session["ddl" + mList[i].FieldId.ToString()] = ddl.SelectedItem.Text;
                                    if (ddl.SelectedIndex > 0)
                                    {
                                        Label lbl = (Label)plcHldCommon.FindControl("lbl" + mList[i].FieldId.ToString());
                                        if (strWhereClause.Length == 0)
                                            strWhereClause.AppendFormat(" [{0}] = '{1}' ", lbl.Text, ddl.SelectedItem);
                                        else
                                            strWhereClause.AppendFormat(" AND [{0}] = '{1}' ", lbl.Text, ddl.SelectedItem);
                                        
                                        strSearchText.AppendFormat("({0} - {1})", lbl.Text, ddl.SelectedItem);

                                        strBindText.AppendFormat("{0}:{1}^", "ddl" + mList[i].FieldId, ddl.SelectedItem);
                                    }
                                    break;
                            }
                        }
                    }
                    if (strWhereClause.Length == 0)
                        return;
                    //strWhereClause.AppendFormat(" AND (a.ContentType = '{0}')", rblContentType.SelectedItem );

                    Session["BindText"] = strBindText;
                    Session["AdvText"] = strSearchText;
                    Session["AdvanceSearchText"] = strWhereClause;
                    
                    BindAdvanceSearchResult(strWhereClause.ToString(),strSearchText.ToString(), Convert.ToInt32(rblContentType.SelectedValue));
                }
                else if (Convert.ToInt32(rblContentType.SelectedValue) == 0)
                {
                    strBindText.AppendFormat("{0}:{1}^", "ContentType", 0);
                    var list = objDAM.GetLibraryAttributeSetByContentTypeId(Convert.ToInt32(rblContentType.Items[2].Value));
                    var mList = list.Where(x => x.IsActive == true).ToList();
                    for (int i = 0; i < mList.Count(); i++)
                    {
                        if (mList[i].AttributeType != "MetaData")
                        {
                            switch (mList[i].FieldType.ToLower())
                            {
                                case "texttype":
                                case "textareatype":
                                    TextBox txt = (TextBox)plcHldCommon.FindControl("txt" + mList[i].FieldId.ToString());
                                    Session["txt" + mList[i].FieldId.ToString()] = txt.Text;
                                    if (txt.Text.Length > 0)
                                    {
                                        Label lbl = (Label)plcHldCommon.FindControl("lbl" + mList[i].FieldId.ToString());
                                        if(strWhereClause.Length == 0)
                                            strWhereClause.AppendFormat(" [{0}] like '%{1}%' ", lbl.Text, txt.Text);
                                        else
                                            strWhereClause.AppendFormat(" AND [{0}] like '%{1}%' ", lbl.Text, txt.Text);
                                        
                                        strSearchText.AppendFormat("({0} - {1})", lbl.Text, txt.Text);

                                        strBindText.AppendFormat("{0}:{1}^", "txt" + mList[i].FieldId, txt.Text);
                                    }
                                    break;
                                case "numerictype":
                                    TextBox txt1 = (TextBox)plcHldCommon.FindControl("txt" + mList[i].FieldId.ToString());
                                    Session["txt" + mList[i].FieldId.ToString()] = txt1.Text;
                                    if (txt1.Text.Length > 0)
                                    {
                                        Label lbl = (Label)plcHldCommon.FindControl("lbl" + mList[i].FieldId.ToString());
                                        if (strWhereClause.Length == 0)
                                            strWhereClause.AppendFormat(" [{0}] = '{1}' ", lbl.Text, txt1.Text);
                                        else
                                            strWhereClause.AppendFormat(" AND [{0}] = '{1}' ", lbl.Text, txt1.Text);
                                        
                                        strSearchText.AppendFormat("({0} - {1})", lbl.Text, txt1.Text);

                                        strBindText.AppendFormat("{0}:{1}^", "txt" + mList[i].FieldId, txt1.Text);
                                    }
                                    break;
                                case "datetimetype":
                                    TextBox txtF = (TextBox)plcHldCommon.FindControl("txtFrom" + mList[i].FieldId.ToString());
                                    TextBox txtT = (TextBox)plcHldCommon.FindControl("txtTo" + mList[i].FieldId.ToString());
                                    Session["txtFrom" + mList[i].FieldId.ToString()] = txtF.Text;
                                    Session["txtTo" + mList[i].FieldId.ToString()] = txtT.Text;
                                    Boolean fromflag;
                                    Boolean toflag;
                                    DateTime fromdate;
                                    DateTime todate;
                                    if (txtF.Text.Length > 0 && txtT.Text.Length > 0)
                                    {
                                        fromflag = DateTime.TryParse(Convert.ToDateTime(txtF.Text, new CultureInfo("hi-IN").DateTimeFormat).ToString(), out fromdate);
                                        toflag = DateTime.TryParse(Convert.ToDateTime(txtT.Text, new CultureInfo("hi-IN").DateTimeFormat).ToString(), out todate);
                                        if (!fromflag)
                                        {
                                            Label lbl1 = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                            divConfirm.Attributes.Add("style", "display:none");
                                            divError.Attributes.Add("style", "display:block");
                                            confirmMsg.InnerHtml = "";
                                            errorMsg.InnerHtml = "Invalid " + lbl1.Text;
                                            return;
                                        }
                                        if (!toflag)
                                        {
                                            Label lbl1 = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                            divConfirm.Attributes.Add("style", "display:none");
                                            divError.Attributes.Add("style", "display:block");
                                            confirmMsg.InnerHtml = "";
                                            errorMsg.InnerHtml = "Invalid " + lbl1.Text;
                                            return;
                                        }
                                        if (fromdate > todate)
                                        {
                                            Label lbl1 = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                            divConfirm.Attributes.Add("style", "display:none");
                                            divError.Attributes.Add("style", "display:block");
                                            confirmMsg.InnerHtml = "";
                                            errorMsg.InnerHtml = "Invalid " + lbl1.Text;
                                            return;
                                        }
                                        Label lbl = (Label)plcHldCommon.FindControl("lbl" + mList[i].FieldId.ToString());
                                        if (strWhereClause.Length == 0)
                                            strWhereClause.AppendFormat(" (CONVERT(datetime,[{0}],105) BETWEEN CONVERT(datetime,'{1}',105) and CONVERT(datetime,'{2}',105)) ", lbl.Text, txtF.Text, txtT.Text);
                                        else
                                            strWhereClause.AppendFormat(" AND (CONVERT(datetime,[{0}],105) BETWEEN CONVERT(datetime,'{1}',105) and CONVERT(datetime,'{2}',105)) ", lbl.Text, txtF.Text, txtT.Text);
                                        
                                        strSearchText.AppendFormat("({0} - {1} AND {2})", lbl.Text, txtF.Text, txtT.Text);

                                        strBindText.AppendFormat("{0}:{1}^", "txtFrom" + mList[i].FieldId, txtF.Text);
                                        strBindText.AppendFormat("{0}:{1}^", "txtTo" + mList[i].FieldId, txtT.Text);
                                     }
                                    break;
                                case "listtype":
                                    DropDownList ddl = (DropDownList)plcHldCommon.FindControl("ddl" + mList[i].FieldId.ToString());
                                    Session["ddl" + mList[i].FieldId.ToString()] = ddl.SelectedItem.Text;
                                    if (ddl.SelectedIndex > 0)
                                    {
                                        Label lbl = (Label)plcHldCommon.FindControl("lbl" + mList[i].FieldId.ToString());
                                        if (strWhereClause.Length == 0)
                                            strWhereClause.AppendFormat(" [{0}] = '{1}' ", lbl.Text, ddl.SelectedItem);
                                        else
                                            strWhereClause.AppendFormat(" AND [{0}] = '{1}' ", lbl.Text, ddl.SelectedItem);
                                        
                                        strSearchText.AppendFormat("({0} - {1})", lbl.Text, ddl.SelectedItem);

                                        strBindText.AppendFormat("{0}:{1}^", "ddl" + mList[i].FieldId, ddl.SelectedItem);
                                    }
                                    break;
                            }
                        }
                    }
                    if (strWhereClause.Length == 0)
                        return;
                    
                    Session["BindText"] = strBindText;
                    Session["AdvText"] = strSearchText;
                    Session["AdvanceSearchText"] = strWhereClause;
                    BindAdvanceSearchResult(strWhereClause.ToString(), strSearchText.ToString(), 0);
                }
                else if (Convert.ToInt32(rblContentType.SelectedValue) == -1)
                {
                    strBindText.AppendFormat("{0}:{1}^", "ContentType", 0);
                    var list = objDAM.GetLibraryAttributeSetByLibId(LibId);
                    var mList = list.Where(x => x.IsActive == true).ToList();
                    for (int i = 0; i < mList.Count(); i++)
                    {
                        if (mList[i].AttributeType != "MetaData")
                        {
                            switch (mList[i].FieldType.ToLower())
                            {
                                case "texttype":
                                case "textareatype":
                                    TextBox txt = (TextBox)plcHldCommon.FindControl("txt" + mList[i].FieldId.ToString());
                                    Session["txt" + mList[i].FieldId.ToString()] = txt.Text;
                                    if (txt.Text.Length > 0)
                                    {
                                        Label lbl = (Label)plcHldCommon.FindControl("lbl" + mList[i].FieldId.ToString());
                                        if (strWhereClause.Length == 0)
                                            strWhereClause.AppendFormat(" [{0}] like '%{1}%' ", lbl.Text, txt.Text);
                                        else
                                            strWhereClause.AppendFormat(" AND [{0}] like '%{1}%' ", lbl.Text, txt.Text);

                                        strSearchText.AppendFormat("({0} - {1})", lbl.Text, txt.Text);

                                        strBindText.AppendFormat("{0}:{1}^", "txt" + mList[i].FieldId, txt.Text);
                                    }
                                    break;
                                case "numerictype":
                                    TextBox txt1 = (TextBox)plcHldCommon.FindControl("txt" + mList[i].FieldId.ToString());
                                    Session["txt" + mList[i].FieldId.ToString()] = txt1.Text;
                                    if (txt1.Text.Length > 0)
                                    {
                                        Label lbl = (Label)plcHldCommon.FindControl("lbl" + mList[i].FieldId.ToString());
                                        if (strWhereClause.Length == 0)
                                            strWhereClause.AppendFormat(" [{0}] = '{1}' ", lbl.Text, txt1.Text);
                                        else
                                            strWhereClause.AppendFormat(" AND [{0}] = '{1}' ", lbl.Text, txt1.Text);

                                        strSearchText.AppendFormat("({0} - {1})", lbl.Text, txt1.Text);

                                        strBindText.AppendFormat("{0}:{1}^", "txt" + mList[i].FieldId, txt1.Text);
                                    }
                                    break;
                                case "datetimetype":
                                    TextBox txtF = (TextBox)plcHldCommon.FindControl("txtFrom" + mList[i].FieldId.ToString());
                                    TextBox txtT = (TextBox)plcHldCommon.FindControl("txtTo" + mList[i].FieldId.ToString());
                                    Session["txtFrom" + mList[i].FieldId.ToString()] = txtF.Text;
                                    Session["txtTo" + mList[i].FieldId.ToString()] = txtT.Text;
                                    Boolean fromflag;
                                    Boolean toflag;
                                    DateTime fromdate;
                                    DateTime todate;
                                    if (txtF.Text.Length > 0 && txtT.Text.Length > 0)
                                    {
                                        fromflag = DateTime.TryParse(Convert.ToDateTime(txtF.Text, new CultureInfo("hi-IN").DateTimeFormat).ToString(), out fromdate);
                                        toflag = DateTime.TryParse(Convert.ToDateTime(txtT.Text, new CultureInfo("hi-IN").DateTimeFormat).ToString(), out todate);
                                        if (!fromflag)
                                        {
                                            Label lbl1 = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                            divConfirm.Attributes.Add("style", "display:none");
                                            divError.Attributes.Add("style", "display:block");
                                            confirmMsg.InnerHtml = "";
                                            errorMsg.InnerHtml = "Invalid " + lbl1.Text;
                                            return;
                                        }
                                        if (!toflag)
                                        {
                                            Label lbl1 = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                            divConfirm.Attributes.Add("style", "display:none");
                                            divError.Attributes.Add("style", "display:block");
                                            confirmMsg.InnerHtml = "";
                                            errorMsg.InnerHtml = "Invalid " + lbl1.Text;
                                            return;
                                        }
                                        if (fromdate > todate)
                                        {
                                            Label lbl1 = (Label)plcHldMetadata.FindControl("lbl" + mList[i].FieldId.ToString());
                                            divConfirm.Attributes.Add("style", "display:none");
                                            divError.Attributes.Add("style", "display:block");
                                            confirmMsg.InnerHtml = "";
                                            errorMsg.InnerHtml = "Invalid " + lbl1.Text;
                                            return;
                                        }
                                        Label lbl = (Label)plcHldCommon.FindControl("lbl" + mList[i].FieldId.ToString());
                                        if (strWhereClause.Length == 0)
                                            strWhereClause.AppendFormat(" (CONVERT(datetime,[{0}],105) BETWEEN CONVERT(datetime,'{1}',105) and CONVERT(datetime,'{2}',105)) ", lbl.Text, txtF.Text, txtT.Text);
                                        else
                                            strWhereClause.AppendFormat(" AND (CONVERT(datetime,[{0}],105) BETWEEN CONVERT(datetime,'{1}',105) and CONVERT(datetime,'{2}',105)) ", lbl.Text, txtF.Text, txtT.Text);

                                        strSearchText.AppendFormat("({0} - {1} AND {2})", lbl.Text, txtF.Text, txtT.Text);

                                        strBindText.AppendFormat("{0}:{1}^", "txtFrom" + mList[i].FieldId, txtF.Text);
                                        strBindText.AppendFormat("{0}:{1}^", "txtTo" + mList[i].FieldId, txtT.Text);
                                    }
                                    break;
                                case "listtype":
                                    DropDownList ddl = (DropDownList)plcHldCommon.FindControl("ddl" + mList[i].FieldId.ToString());
                                    Session["ddl" + mList[i].FieldId.ToString()] = ddl.SelectedItem.Text;
                                    if (ddl.SelectedIndex > 0)
                                    {
                                        Label lbl = (Label)plcHldCommon.FindControl("lbl" + mList[i].FieldId.ToString());
                                        if (strWhereClause.Length == 0)
                                            strWhereClause.AppendFormat(" [{0}] = '{1}' ", lbl.Text, ddl.SelectedItem);
                                        else
                                            strWhereClause.AppendFormat(" AND [{0}] = '{1}' ", lbl.Text, ddl.SelectedItem);

                                        strSearchText.AppendFormat("({0} - {1})", lbl.Text, ddl.SelectedItem);

                                        strBindText.AppendFormat("{0}:{1}^", "ddl" + mList[i].FieldId, ddl.SelectedItem);
                                    }
                                    break;
                            }
                        }
                    }
                    if (strWhereClause.Length == 0)
                        return;

                    Session["BindText"] = strBindText;
                    Session["AdvText"] = strSearchText;
                    Session["AdvanceSearchText"] = strWhereClause;
                    BindAdvanceSearchResult(strWhereClause.ToString(), strSearchText.ToString(), 0);
                }

            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void btnExport_Click(Object sender, EventArgs e)
        {
            divSearchText.InnerText = "";
            divConfirm.Attributes.Add("style", "display:none");
            divError.Attributes.Add("style", "display:none");
            confirmMsg.InnerHtml = "";
            errorMsg.InnerHtml = "";
            DAMServices.ServiceContractClient objDAM;
            DAMServices.FreeTextSearchFiles dt;            
            DAMServices.FreeTextSearchFiles dtC;            
            DAMServices.FreeTextSearchFiles dtG;            
            String html = String.Empty;
            String tagHtml = String.Empty;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                dt = new DAMServices.FreeTextSearchFiles();
                if (hdnSearchText.Value.Length > 0 && Convert.ToInt32(hdnContentTypeId.Value) > 0)
                {
                    var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                    var searchPrivilegeAll = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();

                    var searchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search" && x.ContentTypeId == Convert.ToInt32(hdnContentTypeId.Value)).ToList();
                    for (int i = 0; i < searchPrivilege.Count(); i++)
                    {
                        dtC = new DAMServices.FreeTextSearchFiles();
                        dtG = new DAMServices.FreeTextSearchFiles();

                        string[] privilage = GetPrivilegeDetail(searchPrivilege[i].Permission);
                        dtC = objDAM.AdvanceSearchByContentType(hdnSearchText.Value, privilage[0], Convert.ToInt32(hdnContentTypeId.Value), LibId, TeamId, Convert.ToInt32(privilage[1]), searchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]), UserId);
                        dtG = objDAM.AdvanceSearchByContentType(hdnSearchText.Value, privilage[2], Convert.ToInt32(hdnContentTypeId.Value), LibId, TeamId, Convert.ToInt32(privilage[3]), searchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]), UserId);
                        if (i == 0)
                        {
                            dt.FreeTextSearchTable = dtC.FreeTextSearchTable.Copy();
                            dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);
                        }
                        else
                        {
                            dt.FreeTextSearchTable.Merge(dtC.FreeTextSearchTable);
                            dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);
                        }
                    }
                }
                else if (hdnSearchText.Value.Length > 0 && Convert.ToInt32(hdnContentTypeId.Value) == 0)
                {
                    var UserPrivilege = (DAMServices.TeamInPrivilegeInfo[])Session["UserPrivilege"];
                    var searchPrivilege = UserPrivilege.Where(x => x.PrivilegeName == "Search").ToList();
                    for (int i = 0; i < searchPrivilege.Count(); i++)
                    {
                        dtC = new DAMServices.FreeTextSearchFiles();
                        dtG = new DAMServices.FreeTextSearchFiles();
                        string[] privilage = GetPrivilegeDetail(searchPrivilege[i].Permission);
                        dtC = objDAM.AdvanceSearch(hdnSearchText.Value, privilage[0], searchPrivilege[i].ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[1]), searchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]),UserId);


                        dtG = objDAM.AdvanceSearch(hdnSearchText.Value, privilage[2], searchPrivilege[i].ContentTypeId, LibId, TeamId, Convert.ToInt32(privilage[3]), searchPrivilege[i].IsBrandCategoryMapped, Convert.ToBoolean(Session["IsGroupSpecific"]),UserId);
                        

                        if (i == 0)
                        {
                            dt.FreeTextSearchTable = dtC.FreeTextSearchTable.Copy();
                            dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);                            
                        }
                        else
                        {
                            dt.FreeTextSearchTable.Merge(dtC.FreeTextSearchTable);
                            dt.FreeTextSearchTable.Merge(dtG.FreeTextSearchTable);                            
                        }
                    }
                }
                if (dt.FreeTextSearchTable.Rows.Count > 0)
                {
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ClearContent();
                    HttpContext.Current.Response.ClearHeaders();
                    HttpContext.Current.Response.Buffer = true;
                    HttpContext.Current.Response.ContentType = "application/ms-excel";
                    //HttpContext.Current.Response.ContentType = "application/ms-word";
                    HttpContext.Current.Response.Write(@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.0 Transitional//EN"">");
                    HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=Export.xls");
                    //HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=Reports.doc");
                    HttpContext.Current.Response.Charset = "utf-8";
                    HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("windows-1250");
                    HttpContext.Current.Response.Write("<font style='font-size:10.0pt; font-family:Calibri;'>");
                    HttpContext.Current.Response.Write("<BR><BR><BR>");
                    HttpContext.Current.Response.Write("<Table border='1' bgColor='#ffffff' borderColor='#000000' cellSpacing='0' cellPadding='0' style='font-size:10.0pt; font-family:Calibri; background:white;'> <TR>");
                    int columnscount = dt.FreeTextSearchTable.Columns.Count;
                    foreach (DataColumn column in dt.FreeTextSearchTable.Columns)
                    {
                        if (column.ColumnName == "DocId")
                        {

                        }
                        
                        else if (column.ColumnName == "ContentTypeId")
                        {

                        }
                        else if (column.ColumnName == "LinkCount")
                        {

                        }
                        else if (column.ColumnName == "SerialNo")
                        {

                        }
                        else
                        {
                            HttpContext.Current.Response.Write("<Td>");
                            HttpContext.Current.Response.Write("<B>");
                            HttpContext.Current.Response.Write(column.ColumnName);
                            HttpContext.Current.Response.Write("</B>");
                            HttpContext.Current.Response.Write("</Td>");
                        }
                    }
                    HttpContext.Current.Response.Write("</TR>");
                    foreach (DataRow row in dt.FreeTextSearchTable.Rows)
                    {
                        HttpContext.Current.Response.Write("<TR>");
                        foreach (DataColumn column in dt.FreeTextSearchTable.Columns)
                        {
                            if (column.ColumnName == "DocId")
                            {

                            }
                            
                            else if (column.ColumnName == "ContentTypeId")
                            {

                            }
                            else if (column.ColumnName == "LinkCount")
                            {

                            }
                            else if (column.ColumnName == "SerialNo")
                            {

                            }
                            else
                            {
                                HttpContext.Current.Response.Write("<Td>");
                                HttpContext.Current.Response.Write(row[column].ToString());
                                HttpContext.Current.Response.Write("</Td>");
                            }
                        }

                        HttpContext.Current.Response.Write("</TR>");
                    }
                    HttpContext.Current.Response.Write("</Table>");
                    HttpContext.Current.Response.Write("</font>");
                    HttpContext.Current.Response.Flush();
                    HttpContext.Current.Response.End();                    
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/dashboard/index.aspx", false);
        }
        private string DecryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Decrypt(strQueryString, "r0b1nr0y");
        }

        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
    }
}