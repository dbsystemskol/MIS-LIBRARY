﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using log4net;
using System.IO;
using DAM.Apps.CommonClasses;
using System.Web.Configuration;

namespace DAM.Apps.actitity_log
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));
        private Int32 UserId;
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            ////HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "System Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
            }
            else
            {
                Response.Redirect("~/Default.aspx", false);
            }
            if (!IsPostBack)
            {
                PopulateUser();
            }
        }

        private void PopulateUser()
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var mList = objDAM.GetAllUserMaster(Session["TeamName"].ToString());

                ddlUser.DataSource = mList;
                ddlUser.DataValueField = "UserId";
                ddlUser.DataTextField = "UserName";
                ddlUser.DataBind();
                ddlUser.Items.Insert(0, new ListItem("--Select User--", "0"));
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }
        private void PopulateGrid()
        {
            DAMServices.ServiceContractClient obje;
            try
            {
                obje = new DAMServices.ServiceContractClient();
                if (txtFromDate.Text != "")
                {
                    DateTime outFromDate;
                    DateTime outToDate;
                    System.Globalization.CultureInfo cultureinfo = new System.Globalization.CultureInfo("hi-IN");
                    DateTime date = DateTime.Parse(txtFromDate.Text, cultureinfo);
                    if (DateTime.TryParse(date.ToString(), out outFromDate))
                    {
                        date = DateTime.Parse(txtToDate.Text, cultureinfo);
                        if (DateTime.TryParse(date.ToString(), out outToDate))
                        {
                            var mList = obje.GetActivityInfo(Convert.ToInt32(ddlUser.SelectedValue), Convert.ToDateTime(outFromDate), Convert.ToDateTime(outToDate));
                            if (mList.Count() > 0)
                            {
                                gdvActivityLog.DataSource = mList;
                                gdvActivityLog.DataBind();
                                gdvActivityLog.HeaderRow.TableSection = TableRowSection.TableHeader;
                            }
                            else
                            {
                                //lblMsg.Text = "No activity available for this user";
                            }
                        }
                    }
                }
                else
                {
                    var mList = obje.GetActivityInfo(Convert.ToInt32(ddlUser.SelectedValue), Convert.ToDateTime("1900-01-01"), Convert.ToDateTime("1900-01-01"));
                    if (mList.Count() > 0)
                    {
                        gdvActivityLog.DataSource = mList;
                        gdvActivityLog.DataBind();
                        gdvActivityLog.HeaderRow.TableSection = TableRowSection.TableHeader;
                    }
                    else
                    {
                        //lblMsg.Text = "No activity available for this user";
                    }
                }

            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
            }
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (ddlUser.SelectedValue != "0")
            {
                PopulateGrid();
            }
        }

        protected void gdvActivityLog_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnOldId = (HiddenField)e.Row.FindControl("hdnOldId");
                    HiddenField hdnNewId = (HiddenField)e.Row.FindControl("hdnNewId");
                    LinkButton btnOldId = (LinkButton)e.Row.FindControl("btnOldId");
                    LinkButton btnNewId = (LinkButton)e.Row.FindControl("btnNewId");
                    Image imgOld = (Image)e.Row.FindControl("imgOld");
                    Image imgNew = (Image)e.Row.FindControl("imgNew");
                    Label lblAcitvityName = (Label)e.Row.FindControl("lblAcitvityName");

                    if (Convert.ToInt64(hdnOldId.Value) > 0)
                    {
                        btnOldId.Visible = true;
                        imgOld.Visible = true;
                    }
                    else
                    {
                        btnOldId.Visible = false;
                        imgOld.Visible = false;
                    }
                    if (Convert.ToInt64(hdnNewId.Value) > 0)
                    {
                        btnNewId.Visible = true;
                        imgNew.Visible = true;
                    }
                    else
                    {
                        btnNewId.Visible = false;
                        imgNew.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {

            }
        }
        protected void gdvActivityLog_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string[] arg = new string[2];
            arg = e.CommandArgument.ToString().Split(';');
            Int64 ReferenceId = Convert.ToInt64(arg[0]);
            String TableName = arg[1];
            DAMServices.ServiceContractClient objDAM;
            String html = String.Empty;
            try
            {
                html = "";
                objDAM = new DAMServices.ServiceContractClient();
                if (e.CommandName == "_Old")
                {
                    html = objDAM.GetActivityDetail(ReferenceId, true, TableName);
                    popup.Show();
                }
                if (e.CommandName == "_New")
                {
                    html = objDAM.GetActivityDetail(ReferenceId, false, TableName);
                    popup.Show();
                }
                activityContent.InnerHtml = html;
                gdvActivityLog.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
        
        
        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
    }
}