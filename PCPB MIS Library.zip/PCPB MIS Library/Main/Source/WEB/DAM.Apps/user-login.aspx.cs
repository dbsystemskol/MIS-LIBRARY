﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Security.Principal;
using System.Configuration;
using System.Text;
using log4net;
using log4net.Config;
using System.Globalization;
using System.Web.Configuration;

namespace DAM.Apps
{
    public partial class user_login : System.Web.UI.Page
    {
        static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            ////HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (!IsPostBack)
            {
                //log.Info("reached user login page");
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);
                if (Session["UserId"] != null)
                {
                    //log.Info("User Id found");
                    //log.Info(Session["UserId"].ToString());
                    DAMServices.ServiceContractClient objDAM = new DAMServices.ServiceContractClient();
                    lblUserName.Text = Session["UserName"].ToString();
                    lblName.Text = Session["FirstName"].ToString() + " " + Session["LastName"].ToString();
                    BindTeamByUserId(Convert.ToInt32(Session["UserId"]));
                    //log.Info(ddlTeam.SelectedValue);
                    if(ddlTeam.SelectedValue != null)
                        BindLibraryByUserId(Convert.ToInt32(Session["UserId"]),Convert.ToInt32(ddlTeam.SelectedValue));
                    Session["Configuration"] = objDAM.GetAllConfiguration();
                    if (ddlTeam.SelectedItem.Text == "System Administrator")
                    {
                        Session["LibId"] = "0";
                        Session["TeamName"] = ddlTeam.SelectedItem.Text;
                        //DAMServices.ServiceContractClient objDAM = new DAMServices.ServiceContractClient();
                        Session["LoginHistoryId"] = objDAM.InsertUserLoginHistory(Convert.ToInt32(Session["UserId"]));
                        Response.Redirect("~/user-master/index.aspx");
                    }
                    else if (ddlTeam.SelectedItem.Text == "Application Administrator")
                    {
                        if (ddlTeam.Items.Count == 1 && ddlLibrary.Items.Count == 1)
                        {
                            Session["LibId"] = ddlLibrary.SelectedValue;
                            Session["TeamName"] = ddlTeam.SelectedItem.Text;
                            Session["Library"] = ddlLibrary.SelectedItem.Text;
                            //DAMServices.ServiceContractClient objDAM = new DAMServices.ServiceContractClient();
                            Session["LoginHistoryId"] = objDAM.InsertUserLoginHistory(Convert.ToInt32(Session["UserId"]));
                            Response.Redirect("~/sys-admin/index.aspx");
                        }
                    }
                    else
                    {
                        if (ddlTeam.Items.Count == 1 && ddlLibrary.Items.Count == 1)
                        {
                            
                            Session["LibId"] = ddlLibrary.SelectedValue;
                            Session["TeamName"] = ddlTeam.SelectedItem.Text;
                            Session["TeamId"] = ddlTeam.SelectedValue;
                            Session["Library"] = ddlLibrary.SelectedItem.Text;
                            var privilegeList = objDAM.GetTeamInPrivilegeByTeamId(Convert.ToInt32(ddlTeam.SelectedValue), Convert.ToInt32(ddlLibrary.SelectedValue));
                            Session["UserPrivilege"] = privilegeList;

                            Session["LoginHistoryId"] = objDAM.InsertUserLoginHistory(Convert.ToInt32(Session["UserId"]));
                            Response.Redirect("~/dashboard/index.aspx");
                        }
                    }                   
                }
                else
                {
                    Response.Redirect("~/Logout.aspx");
                }
            }
        }

        protected void ddlTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindLibraryByUserId(Convert.ToInt32(Session["UserId"]),Convert.ToInt32(ddlTeam.SelectedValue));
        }
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(ddlLibrary.SelectedValue) > 0)
            {
                Session["LibId"] = ddlLibrary.SelectedValue;
                Session["TeamName"] = ddlTeam.SelectedItem.Text;
                Session["TeamId"] = ddlTeam.SelectedValue;
                Session["Library"] = ddlLibrary.SelectedItem.Text;
                DAMServices.ServiceContractClient objDAM = new DAMServices.ServiceContractClient();
                Session["LoginHistoryId"] = objDAM.InsertUserLoginHistory(Convert.ToInt32(Session["UserId"]));
                Session["Configuration"] = objDAM.GetAllConfiguration();
                if (ddlTeam.SelectedItem.Text == "System Administrator")
                {
                    Response.Redirect("~/user-master/index.aspx");
                }
                else if (ddlTeam.SelectedItem.Text == "Application Administrator")
                {
                    Response.Redirect("~/sys-admin/index.aspx");
                }
                else
                {
                    var privilegeList = objDAM.GetTeamInPrivilegeByTeamId(Convert.ToInt32(ddlTeam.SelectedValue),Convert.ToInt32(ddlLibrary.SelectedValue));
                    Session["UserPrivilege"] = privilegeList;
                    var Configuration = (DAMServices.ConfigurationInfo[])Session["Configuration"];
                    var groupConfig = Configuration.Where(x => x.ConfigurationAlias == "GL").ToList();
                    if(groupConfig[0].IsActive)
                    {
                        var userGroup = objDAM.GetAllActiveGroupMasterUserList().Where(x => x.UserId == Convert.ToInt32(Session["UserId"].ToString()) && x.DefaultType == true).ToList();
                        if (userGroup.Count() > 0)
                            Session["IsGroupSpecific"] = true;
                        else
                            Session["IsGroupSpecific"] = false;
                    }
                    else
                        Session["IsGroupSpecific"] = false;
                    Response.Redirect("~/dashboard/index.aspx");
                }
            }
        }
        protected void btnLogout_Click(object sender, EventArgs e)
        {            
             Response.Redirect("~/logout.aspx");
        }
        private void BindLibraryByUserId(Int32 UserId, Int32 TeamId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var mList = objDAM.GetLibraryMasterByUserId(UserId, TeamId).Where(x => x.IsActive == true);
                ddlLibrary.DataSource = mList;
                ddlLibrary.DataTextField = "LibName";
                ddlLibrary.DataValueField = "LibId";
                ddlLibrary.DataBind();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }

        private void BindTeamByUserId(Int32 UserId)
        {
            DAMServices.ServiceContractClient objDAM;
            try
            {
                objDAM = new DAMServices.ServiceContractClient();
                var mList = objDAM.GetTeamMasterByUserId(UserId);
                ddlTeam.DataSource = mList;
                ddlTeam.DataTextField = "TeamName";
                ddlTeam.DataValueField = "TeamId";
                ddlTeam.DataBind();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
            }
        }
    }
}