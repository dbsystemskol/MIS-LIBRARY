﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace DAM.Apps.CommonClasses
{
    public static class Constant
    {
        public const String SUCCESS = "Data has been saved successfully";
        public const String ADD_SUCCESS = "Data has been created successfully";
        public const String ADD_ERROR = "Unable to create the data";
        public const String EDIT_SUCCESS = "Data has been updated successfully";
        public const String EDIT_ERROR = "Unable to update the data";
        public const String EDIT_FAIL = "No data changed for update";
        public const String DELETE_SUCCESS = "File has been deleted successfully";
        public const String DELETE_ERROR = "Unable to delete the file";
        public const String DUPLICATE = "Data already exists";
        public const String EMAIL_VERIFY = "Invalid email-id";
        public const String ACTIVATE_DATA = "Do you want activate the data";
        public const String DEACTIVATE_DATA = "Do you want de-activate the data";
        public const String FILE_UPLOAD_SUCCESS = "File uploaded successfully";
        public const String FILE_UPLOAD_FAILURE = "Unlable to upload the file. Please try again";
        public const String FILE_NAME_FAILURE = "File name too large";
        public const String FILE_INVALID = "Invalid file format";
        public const String FILE_CORRUPT = "Invalid file";
        public const String FILE_SIZE_FAILURE = "Max. 60MB file is allowed";
        public const String FILE_EXTENSION = "Please upload file extension with .docx, .doc, .xls, .xlsx, .pdf, .zip and .txt";
        public const String BRAND_EXTENSION = "Please upload file extension with .png, .jpg and .jpeg";
        public const String PROJECT_TYPE_UNAVAILABLE = "Project type unavailable";
        public const String BRAND_UNAVAILABLE = "Brand unavailable";
        public const String PRODUCT_CATAGORY_UNAVAILABLE = "Product category unavailable";
        public const String DATE_INVALID = "Invalid date";
        public const String DATA_NOT_FOUND = "No record found";
        public const String UPDATE_STATUS_ALERT = "Select atleast one status";
        public const String PROJECT_CLOSE = "Project closed successfully";
        public const String PROJECT_CLOSE_ERROR = "Unable to close the project";
        public const String DOCUMENT_NOT_ATTACHED = "All required documents are not attached";
        public const String PROJECT_CANCEL = "Project canceled successfully";
        public const String PROJECT_CANCEL_ERROR = "Unable to cancel the project";
        public const String PROJECT_INACTIVE = "Project inactivated successfully";
        public const String PROJECT_INACTIVE_ERROR = "Unable to inactivate the project";
        public const String NO_FILE = "Please upload file to update";
        public const String UPDATE_ATTRIBUTE_STATUS_ALERT = "Select atleast one attribute";
    }
}