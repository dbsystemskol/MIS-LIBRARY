﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using log4net;
using DAM.Apps.CommonClasses;
using System.Text;
using System.IO;
using System.Web.Configuration;
using QueryStringEncryption;

namespace DAM.Apps.library_master
{
    public partial class index : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(index));
        private Int32 UserId;
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "System Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
            }
            else
            {
                Response.Redirect("~/Logout.aspx", false);
            }
            if (!IsPostBack)
            {
                PopulateLibraryMasterList();
            }
        }
        
        private string GetIPAddress()
        {
            //IP Address
            string ipaddress;
            ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];
            return ipaddress;
        }

        protected void PopulateLibraryMasterList()
        {
            DAMServices.ServiceContractClient obje;
            try
            {
                obje = new DAMServices.ServiceContractClient();
                gdvLibraryMaster.DataSource = obje.GetAllLibraryMasterContentType();
                gdvLibraryMaster.DataBind();
                gdvLibraryMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
            }
        }

        

        protected void gdvLibraryMaster_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    HiddenField hdnActive = (HiddenField)e.Row.FindControl("hdnActive");
                    Image imgActive = (Image)e.Row.FindControl("imgActive");
                    Image imgDeactive = (Image)e.Row.FindControl("imgDeactive");
                    imgActive.Visible = (hdnActive.Value == "True") ? true : false;
                    imgDeactive.Visible = (hdnActive.Value == "True") ? false : true;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                //throw ex;
            }
            finally
            {

            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DAMServices.ServiceContractClient obje;
            try
            {
                obje = new DAMServices.ServiceContractClient();
                gdvLibraryMaster.DataSource = obje.GetLibraryMasterSearch(Server.HtmlEncode(txtSearchLibrary.Value));
                gdvLibraryMaster.DataBind();
                gdvLibraryMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                obje = null;
            }
        }

        protected void gdvLibraryMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DAMServices.ServiceContractClient objDAM;
            DAMServices.LibraryMasterInfo mData;
            try
            {
                if (UserId != 0)
                {
                    objDAM = new DAMServices.ServiceContractClient();
                    mData = new DAMServices.LibraryMasterInfo();
                    if (e.CommandName == "_ActiveDeactive")
                    {
                        String[] CommandArgs = e.CommandArgument.ToString().Split(new char[] { '|' });
                        Int32 RowLibId = Convert.ToInt32(CommandArgs[0]);
                        Int32 ContentTypeId = Convert.ToInt32(CommandArgs[1]);
                        Boolean Status = Convert.ToBoolean(CommandArgs[2]);
                        mData.LibId = RowLibId;
                        mData.ContentTypeId = ContentTypeId;
                        mData.ModifiedBy = UserId;
                        mData.IPAddress = GetIPAddress();
                        mData.IsActive = (Status) ? false : true;
                        Int32 r = objDAM.ActivateDeactivateLibraryMaster(mData);
                        if (r > 0)
                        {
                            PopulateLibraryMasterList();
                            confirmMsg.InnerHtml = Constant.EDIT_SUCCESS;
                            errorMsg.InnerHtml = "";
                        }
                        else
                        {
                            confirmMsg.InnerHtml = "";
                            errorMsg.InnerHtml = Constant.EDIT_ERROR;
                        }

                    }                   
                    if (e.CommandName == "_View")
                    {
                        String[] CommandArgs = e.CommandArgument.ToString().Split(new char[] { '|' });
                        Int32 RowLibId = Convert.ToInt32(CommandArgs[0]);
                        Int32 ContentTypeId = Convert.ToInt32(CommandArgs[1]);
                        hdnSelectLibId.Value = RowLibId.ToString();
                        var mList = objDAM.GetLibraryMasterRowDetailsById(RowLibId, ContentTypeId).Where(x => x.IsActive == true).ToList();
                        lblLibraryName.InnerText = Server.HtmlDecode(mList[0].LibName);
                        lblContentType.InnerText = Server.HtmlDecode(mList[0].Description);
                        lblCreatedBy.InnerText = Server.HtmlDecode(mList[0].Name);
                        lblCretedOn.InnerText = mList[0].CreatedOn.ToShortDateString();
                        var cList = mList.Where(b => b.AttributeType == "Common").Select(b => new DAMServices.LibraryMasterInfo
                        {
                            FieldCaption = b.FieldCaption
                        }).ToList();
                        StringBuilder sbc = new StringBuilder();
                        sbc.AppendFormat(@"<table id='Table1' style='BorderWidth: 0; Width:100%'><tbody>");
                        if (cList.Count() > 0)
                        {
                            for (int i = 0; i < cList.Count(); i++)
                            {
                                sbc.AppendFormat(@"<tr>
                                <td>
                                    {0}
                                </td>
                            </tr>", Server.HtmlDecode(cList[i].FieldCaption));
                            }
                        }
                        sbc.AppendFormat(@"</tbody></table>");
                        gdvCommon.InnerHtml = sbc.ToString();

                        //_______________________________________________________________
                        var mtList = mList.Where(b => b.AttributeType == "MetaData").Select(b => new DAMServices.LibraryMasterInfo
                        {
                            FieldCaption = b.FieldCaption,
                        }).ToList();
                        StringBuilder sbm = new StringBuilder();
                        sbm.AppendFormat(@"<table id='Table1' style='BorderWidth: 0; Width:100%'><tbody>");
                        if (mtList.Count() > 0)
                        {
                            for (int i = 0; i < mtList.Count(); i++)
                            {
                                sbm.AppendFormat(@"<tr>
                                <td>
                                    {0}
                                </td>
                            </tr>", Server.HtmlDecode(mtList[i].FieldCaption));
                            }
                        }
                        sbm.AppendFormat(@"</tbody></table>");
                        gdvMatadata.InnerHtml = sbm.ToString();

                        //_______________________________________________________________
                        var oList = mList.Where(b => b.AttributeType == "Other").Select(b => new DAMServices.LibraryMasterInfo
                        {
                            FieldCaption = b.FieldCaption,
                        }).ToList();
                        StringBuilder sbo = new StringBuilder();
                        sbo.AppendFormat(@"<table id='Table1' style='BorderWidth: 0; Width:100%'><thead>
                                    <tr>
                                        <th>
                                            <h3 style='width:99.3%;padding: 0 0 6px'>Other</h3>
                                        </th>
                                    </tr></thead><tbody>");
                        if (oList.Count() > 0)
                        {
                            for (int i = 0; i < oList.Count(); i++)
                            {
                                sbo.AppendFormat(@"<tr>
                                <td>
                                    {0}
                                </td>
                            </tr>", Server.HtmlDecode(oList[i].FieldCaption));
                            }
                        }
                        sbo.AppendFormat(@"</tbody></table>");
                        gdvOther.InnerHtml = sbo.ToString();
                        gdvLibraryMaster.HeaderRow.TableSection = TableRowSection.TableHeader;
                        popup.Show();
                    }
                    if (e.CommandName == "_Edit")
                    {
                        String[] CommandArgs = e.CommandArgument.ToString().Split(new char[] { '|' });
                        Int32 RowLibId = Convert.ToInt32(CommandArgs[0]);
                        Int32 ContentTypeId = Convert.ToInt32(CommandArgs[1]);
                        Response.Redirect("~/library-edit/index.aspx?" + EncryptQueryString(String.Format("libid={0}&contenttypeid={1}", RowLibId, ContentTypeId)));
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
                objDAM = null;
                mData = null;
            }
        }
        public string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, "r0b1nr0y");
        }
        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/library-new/index.aspx");
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (gdvLibraryMaster.Rows.Count > 0)
                {
                    Response.ClearContent();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "Library.xls"));
                    Response.ContentType = "application/ms-excel";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter htw = new HtmlTextWriter(sw);
                    gdvLibraryMaster.AllowPaging = false;
                    //Change the Header Row back to white color
                    gdvLibraryMaster.HeaderRow.Style.Add("background-color", "#FFFFFF");
                    gdvLibraryMaster.HeaderRow.Style.Add("color", "#fff");
                    for (int i = 0; i < gdvLibraryMaster.HeaderRow.Cells.Count; i++)
                        gdvLibraryMaster.HeaderRow.Cells[i].Style.Add("background-color", "#1B1BBA");
                    for (int i = 0; i < gdvLibraryMaster.Columns.Count; i++)
                    {
                        if (gdvLibraryMaster.Columns[i].HeaderText == "Active" || gdvLibraryMaster.Columns[i].HeaderText == "View")
                            gdvLibraryMaster.Columns[i].Visible = false;
                        if (gdvLibraryMaster.Columns[i].HeaderText == "IsActive")
                            gdvLibraryMaster.Columns[i].Visible = true;
                    }
                    gdvLibraryMaster.RenderControl(htw);
                    Response.Write(sw.ToString());
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            finally
            {
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
    }
}