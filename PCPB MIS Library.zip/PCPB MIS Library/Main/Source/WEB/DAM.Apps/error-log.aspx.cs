﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using log4net;
using System.IO;
using DAM.Apps.CommonClasses;
using System.Web.Configuration;
using System.Text;

namespace DAM.Apps
{
    public partial class error_log : System.Web.UI.Page
    {
        protected static ILog log = LogManager.GetLogger(typeof(error_log));
        private Int32 UserId;
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.User =  new System.Security.Principal.GenericPrincipal(new System.Security.Principal.GenericIdentity("Administrator"), new string[] { "PO" });
            if (Page.User.Identity.IsAuthenticated)
            {
                Session["Reset"] = true;
                Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
                SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
                int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
                int sessionAlert = Convert.ToInt32(ConfigurationManager.AppSettings["SessionAlert"].ToString()) * 60;
                ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + "," + sessionAlert + ");", true);

                if (Session["TeamName"] != null)
                {
                    if (Session["TeamName"].ToString() != "System Administrator")
                    {
                        Response.Redirect(ConfigurationManager.AppSettings["AuthorizationPage"].ToString());
                    }
                }
                else
                    Response.Redirect(ConfigurationManager.AppSettings["UnAuthorizationPage"].ToString());

                Uname.InnerText = "Hi " + Session["FirstName"].ToString();
                UserId = Convert.ToInt32(Session["UserId"].ToString());
            }
            else
            {
                Response.Redirect("~/Default.aspx", false);
            }
            if (!IsPostBack)
            {
                BindLog(System.DateTime.Now.ToString("dd-MM-yyyy"));
            }
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtFromDate.Text.Length > 0)
            {
                BindLog(txtFromDate.Text);
            }
        }
        private void BindLog(String strDate)
        {
            string sourcePath = ConfigurationManager.AppSettings["logPath"].ToString();
            string destination = Path.GetTempPath();

            if (!System.IO.Directory.Exists(destination))
            {
                System.IO.Directory.CreateDirectory(destination);
            }

            destination = System.IO.Path.Combine(destination, System.IO.Path.GetFileName(sourcePath));
            if (File.Exists(destination))
            {
                File.Delete(destination);
            }
            System.IO.File.Copy(sourcePath, destination);
            StringBuilder sBuilder = new StringBuilder();
            string currentLine = String.Empty;
            using (var streamReader = new StreamReader(destination, Encoding.UTF8))
            {
                while ((currentLine = streamReader.ReadLine()) != null)
                {
                    if (currentLine.Contains(strDate))
                    {
                        if (currentLine.EndsWith(" ---"))
                        {
                            sBuilder.Append(Environment.NewLine);
                            sBuilder.Append(Environment.NewLine);
                        }
                        else
                        {
                            sBuilder.Append(currentLine);
                            sBuilder.Append(Environment.NewLine);
                            sBuilder.Append(Environment.NewLine);
                        }
                    }
                }
                divResult.InnerText = sBuilder.ToString();
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
    }
}