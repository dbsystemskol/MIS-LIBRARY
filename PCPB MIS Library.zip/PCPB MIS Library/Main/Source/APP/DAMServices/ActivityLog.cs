﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;
using System.Data.SqlClient;

namespace DAM.Apps.Utility
{
    public class ActivityLog
    {
        protected static ILog log = LogManager.GetLogger(typeof(ActivityLog));

        public DataTable GetActivityDetail(Int64 ReferenceId, Boolean IsOriginal, String TableName)
        {
            SqlDataReader mList;
            DataTable dt = new DataTable();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GetActivityDetail";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@ReferenceId", SqlDbType.BigInt, DataParameterDirection.Input, 8, ReferenceId);
                mCmd.AddParameter("@IsOriginal", SqlDbType.Bit, DataParameterDirection.Input, 1, IsOriginal);
                mCmd.AddParameter("@TableName", SqlDbType.VarChar, DataParameterDirection.Input, 100, TableName);
                // execute
                try
                {
                    mList = mCmd.ExecuteReaderWithSqlReader();
                    dt.Load(mList);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return dt;
        }

        public List<ActivityLogInfo> GetActivityInfo(Int32 UserId, DateTime FromDate, DateTime ToDate)
        {
            List<ActivityLogInfo> mList = new List<ActivityLogInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GetActivityLogByUser";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
                if (FromDate != Convert.ToDateTime("1900-01-01"))
                    mCmd.AddParameter("@FromDate", SqlDbType.SmallDateTime, DataParameterDirection.Input, 10, FromDate);
                else
                    mCmd.AddParameter("@FromDate", SqlDbType.SmallDateTime, DataParameterDirection.Input, 10, null);
                if (ToDate != Convert.ToDateTime("1900-01-01"))
                    mCmd.AddParameter("@ToDate", SqlDbType.SmallDateTime, DataParameterDirection.Input, 10, ToDate);
                else
                    mCmd.AddParameter("@ToDate", SqlDbType.SmallDateTime, DataParameterDirection.Input, 10, null);
                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new ActivityLogInfo
                        {
                            ActivityLogId = mCmd.GetFieldValue<Int64>("ActivityLogId"),
                            AcitvityName = mCmd.GetFieldValue<String>("AcitvityName"),
                            ActivityDate = mCmd.GetFieldValue<DateTime>("ActivityDate"),
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            OriginalReferenceId = mCmd.GetFieldValue<Int64>("OriginalReferenceId"),
                            ChangedReferenceId = mCmd.GetFieldValue<Int64>("ChangedReferenceId"),
                            ActivityIP = mCmd.GetFieldValue<String>("ActivityIP"),
                            ActivityType = mCmd.GetFieldValue<String>("ActivityType"),
                            TableName = mCmd.GetFieldValue<String>("TableName"),

                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
