﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAM.Apps.Utility
{
    public class GroupMaster
    {
        protected static ILog log = LogManager.GetLogger(typeof(GroupMaster));

        public List<GroupMasterInfo> GetAllGroupMaster()
        {
            List<GroupMasterInfo> mList = new List<GroupMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GroupMasterSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new GroupMasterInfo
                        {
                            GroupId = mCmd.GetFieldValue<Int32>("GroupId"),
                            Alias = mCmd.GetFieldValue<String>("Alias"),
                            GroupName = mCmd.GetFieldValue<String>("GroupName"),
                            DefaultType = mCmd.GetFieldValue<Boolean>("DefaultType"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<GroupMasterInfo> GetGroupMasterById(Int32 GroupId)
        {
            List<GroupMasterInfo> mList = new List<GroupMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GroupMasterSelectRow";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@GroupId", SqlDbType.Int, DataParameterDirection.Input, 4, GroupId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new GroupMasterInfo
                        {
                            GroupId = mCmd.GetFieldValue<Int32>("GroupId"),
                            Alias = mCmd.GetFieldValue<String>("Alias"),
                            GroupName = mCmd.GetFieldValue<String>("GroupName"),
                            DefaultType = mCmd.GetFieldValue<Boolean>("DefaultType"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 InsertGroupMaster(GroupMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "GroupMasterInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@Alias", SqlDbType.VarChar, DataParameterDirection.Input, 10, mData.Alias);
            mCmd.AddParameter("@GroupName", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.GroupName);
            mCmd.AddParameter("@DefaultType", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.DefaultType);
            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.CreatedBy);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 UpdateGroupMaster(GroupMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "GroupMasterUpdate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@GroupId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.GroupId);
            mCmd.AddParameter("@Alias", SqlDbType.VarChar, DataParameterDirection.Input, 10, mData.Alias);
            mCmd.AddParameter("@GroupName", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.GroupName);
            mCmd.AddParameter("@DefaultType", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.DefaultType);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<GroupMasterInfo> GetAllActiveGroupMaster()
        {
            List<GroupMasterInfo> mList = new List<GroupMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GroupMasterSelectAllActiveRows";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new GroupMasterInfo
                        {
                            GroupId = mCmd.GetFieldValue<Int32>("GroupId"),
                            Alias = mCmd.GetFieldValue<String>("Alias"),
                            GroupName = mCmd.GetFieldValue<String>("GroupName"),
                            DefaultType = mCmd.GetFieldValue<Boolean>("DefaultType"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 ActivateDeactivateGroupMaster(GroupMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "GroupMasterActivateDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@GroupId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.GroupId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<GroupMasterInfo> SearchGroupMaster(String SearchText)
        {
            List<GroupMasterInfo> mList = new List<GroupMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GroupMasterSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@SearchText", SqlDbType.VarChar, DataParameterDirection.Input, 100, SearchText);
                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new GroupMasterInfo
                        {
                            GroupId = mCmd.GetFieldValue<Int32>("GroupId"),
                            Alias = mCmd.GetFieldValue<String>("Alias"),
                            GroupName = mCmd.GetFieldValue<String>("GroupName"),
                            DefaultType = mCmd.GetFieldValue<Boolean>("DefaultType"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public void DocGroupLog(Int32 DocId, String ChangeField,String FieldName, String ValueBefore, String ValueAfter, Int32 ChangedBy)
        {
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "DocLogDetailsInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
            mCmd.AddParameter("@ChangeField", SqlDbType.VarChar, DataParameterDirection.Input,100, ChangeField);
            mCmd.AddParameter("@FieldName", SqlDbType.VarChar, DataParameterDirection.Input, 100, FieldName);
            mCmd.AddParameter("@ValueBefore", SqlDbType.VarChar, DataParameterDirection.Input, 100, ValueBefore);
            mCmd.AddParameter("@ValueAfter", SqlDbType.VarChar, DataParameterDirection.Input, 100, ValueAfter);
            mCmd.AddParameter("@ChangedBy", SqlDbType.Int, DataParameterDirection.Input, 4, ChangedBy);

            try
            {
                mCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
        }

        public List<DocLogDetailsInfo> DocLogDetailsSearch(String FromDate, String ToDate)
        {
            List<DocLogDetailsInfo> mList = new List<DocLogDetailsInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "DocLogDetailsSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                if (FromDate != "")
                    mCmd.AddParameter("@FromDate", SqlDbType.VarChar, DataParameterDirection.Input, 10, FromDate);
                else
                    mCmd.AddParameter("@FromDate", SqlDbType.VarChar, DataParameterDirection.Input, 10, null);
                if (ToDate != "")
                    mCmd.AddParameter("@ToDate", SqlDbType.VarChar, DataParameterDirection.Input, 10, ToDate);
                else
                    mCmd.AddParameter("@ToDate", SqlDbType.VarChar, DataParameterDirection.Input, 10, null);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new DocLogDetailsInfo
                        {
                            DocNo = mCmd.GetFieldValue<Int32>("DocNo"),
                            Title = mCmd.GetFieldValue<String>("Title"),
                            ChangeField = mCmd.GetFieldValue<String>("ChangeField"),
                            ValueBefore = mCmd.GetFieldValue<String>("ValueBefore"),
                            ValueAfter = mCmd.GetFieldValue<String>("ValueAfter"),
                            ChangedById = mCmd.GetFieldValue<String>("ChangedById"),
                            ChangedByName = mCmd.GetFieldValue<String>("ChangedByName"),
                            ChangedOn = mCmd.GetFieldValue<DateTime>("ChangedOn"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
