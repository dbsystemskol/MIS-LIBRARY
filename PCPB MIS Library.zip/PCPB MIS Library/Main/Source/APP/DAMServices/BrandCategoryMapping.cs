﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAM.Apps.Utility
{
    public class BrandCategoryMapping
    {
        protected static ILog log = LogManager.GetLogger(typeof(BrandCategoryMapping));

        public List<BrandCategoryMappingInfo> GetBrandCategoryMapping(Int32 BrandId, Int32 CategoryId)
        {
            List<BrandCategoryMappingInfo> mList = new List<BrandCategoryMappingInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "BrandCategoryMappingList";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@BrandId", SqlDbType.Int, DataParameterDirection.Input, 4, BrandId);
                mCmd.AddParameter("@CategoryId", SqlDbType.Int, DataParameterDirection.Input, 4, CategoryId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new BrandCategoryMappingInfo
                        {
                            BrandCategoryMappingId = mCmd.GetFieldValue<Int32>("BrandCategoryMappingId"),
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            BrandId = mCmd.GetFieldValue<Int32>("BrandId"),
                            CategoryId = mCmd.GetFieldValue<Int32>("CategoryId"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                            EmailId = mCmd.GetFieldValue<String>("EmailId"),
                            IsAppAdmin = mCmd.GetFieldValue<Boolean>("IsAppAdmin"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive")
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<BrandCategoryMappingInfo> GetUserNotInBrandCategory(Int32 BrandId, Int32 CategoryId)
        {
            List<BrandCategoryMappingInfo> mList = new List<BrandCategoryMappingInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "UserNotInBrandCategoryMailMapping";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@BrandId", SqlDbType.Int, DataParameterDirection.Input, 4, BrandId);
                mCmd.AddParameter("@CategoryId", SqlDbType.Int, DataParameterDirection.Input, 4, CategoryId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new BrandCategoryMappingInfo
                        {
                            
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                            EmailId = mCmd.GetFieldValue<String>("EmailId"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public void InsertBrandCategoryMapping(List<BrandCategoryMappingInfo> mInfo)
        {
            DataCommand mCmd = null;
            try
            {
                foreach (var uList in mInfo)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@BrandId", SqlDbType.Int, DataParameterDirection.Input, 4, uList.BrandId);
                    mCmd.AddParameter("@CategoryId", SqlDbType.Int, DataParameterDirection.Input, 4, uList.CategoryId);
                    mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, uList.UserId);
                    mCmd.AddParameter("@EmailId", SqlDbType.VarChar, DataParameterDirection.Input, 100, uList.EmailId);
                    mCmd.AddParameter("@Permission", SqlDbType.TinyInt, DataParameterDirection.Input, 4, uList.Permission);
                    mCmd.AddParameter("@IsAppAdmin", SqlDbType.Bit, DataParameterDirection.Input, 1, uList.IsAppAdmin);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, uList.CreatedBy);
                    mCmd.CommandText = "BrandCategoryMappingInsert";
                    mCmd.ExecuteNonQuery();
                    mCmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
        }

        public Int32 ActivateDeactivateBrandCategoryMapping(BrandCategoryMappingInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "BrandCategoryMappingActivateDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@BrandCategoryMappingId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.BrandCategoryMappingId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 UpdateBrandCategoryMapping(BrandCategoryMappingInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "BrandCategoryMappingUpdate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@BrandCategoryMappingId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.BrandCategoryMappingId);
            mCmd.AddParameter("@Permission", SqlDbType.TinyInt, DataParameterDirection.Input, 4, mData.Permission);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<BrandCategoryMappingInfo> GetAllBrandCategoryMapping()
        {
            List<BrandCategoryMappingInfo> mList = new List<BrandCategoryMappingInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "BrandCategoryMappingSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new BrandCategoryMappingInfo
                        {
                            BrandCategoryMappingId = mCmd.GetFieldValue<Int32>("BrandCategoryMappingId"),
                            BrandId = mCmd.GetFieldValue<Int32>("BrandId"),
                            Brand = mCmd.GetFieldValue<String>("Brand"),
                            CategoryId = mCmd.GetFieldValue<Int32>("CategoryId"),
                            Category = mCmd.GetFieldValue<String>("Category"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                            EmailId = mCmd.GetFieldValue<String>("EmailId"),
                            Permission = mCmd.GetFieldValue<Int16>("Permission"),
                            IsAppAdmin = mCmd.GetFieldValue<Boolean>("IsAppAdmin"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<BrandCategoryMappingInfo> BrandCategoryMappingInfoSearch(String SearchString)
        {
            List<BrandCategoryMappingInfo> mList = new List<BrandCategoryMappingInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "BrandCategoryMappingSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@SearchString", SqlDbType.VarChar, DataParameterDirection.Input, 100, SearchString);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new BrandCategoryMappingInfo
                        {
                            BrandCategoryMappingId = mCmd.GetFieldValue<Int32>("BrandCategoryMappingId"),
                            BrandId = mCmd.GetFieldValue<Int32>("BrandId"),
                            Brand = mCmd.GetFieldValue<String>("Brand"),
                            CategoryId = mCmd.GetFieldValue<Int32>("CategoryId"),
                            Category = mCmd.GetFieldValue<String>("Category"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                            EmailId = mCmd.GetFieldValue<String>("EmailId"),
                            Permission = mCmd.GetFieldValue<Int16>("Permission"),
                            IsAppAdmin = mCmd.GetFieldValue<Boolean>("IsAppAdmin"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<BrandCategoryMappingInfo> GetUserEmailByDocId(Int32 DocId)
        {
            List<BrandCategoryMappingInfo> mList = new List<BrandCategoryMappingInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GetUserEmailByDocId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new BrandCategoryMappingInfo
                        {
                            EmailId = mCmd.GetFieldValue<String>("EmailId"),
                            IsAppAdmin = mCmd.GetFieldValue<Boolean>("IsAppAdmin"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
