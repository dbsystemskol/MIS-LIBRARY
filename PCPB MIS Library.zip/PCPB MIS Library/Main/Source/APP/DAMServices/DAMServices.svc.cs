﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using DAM.Apps.Utility;
using System.Data;
using System.Data.SqlClient;
using System.Web;
//using log4net;
//using log4net.Config;

namespace DAMServices
{
    public class DAMServices : IServiceContract
    {
        //static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        #region FileExtensionMaster
        public List<FileExtensionInfo> GetAllFileExtension()
        {
            List<FileExtensionInfo> mInfo;
            FileExtensionMaster mData;
            try
            {
                mInfo = new List<FileExtensionInfo>();
                mData = new FileExtensionMaster();
                mInfo = mData.GetAllFileExtension();
                return mInfo;                
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<FileExtensionInfo> GetFileExtensionMasterById(Int32 FileExtensionId)
        {
            List<FileExtensionInfo> mInfo;
            FileExtensionMaster mData;
            try
            {
                mInfo = new List<FileExtensionInfo>();
                mData = new FileExtensionMaster();

                mInfo = mData.GetFileExtensionMasterById(FileExtensionId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 InsertFileExtensionMaster(FileExtensionInfo mObj)
        {
            FileExtensionMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new FileExtensionMaster();
                _returnValue = mData.InsertFileExtensionMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 UpdateFileExtensionMaster(FileExtensionInfo mObj)
        {
            FileExtensionMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new FileExtensionMaster();
                _returnValue = mData.UpdateFileExtensionMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 ActivateDeactivateFileExtensionMaster(FileExtensionInfo mObj)
        {
            FileExtensionMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new FileExtensionMaster();
                _returnValue = mData.ActivateDeactivateFileExtensionMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<FileExtensionInfo> GetAllActiveFileExtensionMaster()
        {
            List<FileExtensionInfo> mInfo;
            FileExtensionMaster mData;
            try
            {
                mInfo = new List<FileExtensionInfo>();
                mData = new FileExtensionMaster();

                mInfo = mData.GetAllActiveFileExtensionMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<FileExtensionInfo> GetFileExtensionMasterSearch(String FileExtensionName)
        {
            List<FileExtensionInfo> mInfo;
            FileExtensionMaster mData;
            try
            {
                mInfo = new List<FileExtensionInfo>();
                mData = new FileExtensionMaster();

                mInfo = mData.SearchFileExtension(FileExtensionName);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        #endregion

        public List<FileExtensionInfo> GetPreviewImageByFileExtension(String FileExtension)
        {
            List<FileExtensionInfo> mInfo;
            FileExtensionMaster mData;
            try
            {
                mInfo = new List<FileExtensionInfo>();
                mData = new FileExtensionMaster();

                mInfo = mData.GetPreviewImageByFileExtension(FileExtension);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<LibraryMasterInfo> GetAllLibraryMaster()
        {
            List<LibraryMasterInfo> mInfo;
            LibraryMaster mData;
            try
            {
                mInfo = new List<LibraryMasterInfo>();
                mData = new LibraryMaster();

                mInfo = mData.GetAllLibraryMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<LibraryMasterInfo> GetLibraryMasterById(Int32 LibId)
        {
            List<LibraryMasterInfo> mInfo;
            LibraryMaster mData;
            try
            {
                mInfo = new List<LibraryMasterInfo>();
                mData = new LibraryMaster();

                mInfo = mData.GetLibraryMasterById(LibId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<TeamMasterInfo> GetAllTeamMaster()
        {
            List<TeamMasterInfo> mInfo;
            TeamMaster mData;
            try
            {
                mInfo = new List<TeamMasterInfo>();
                mData = new TeamMaster();

                mInfo = mData.GetAllTeamMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<TeamMasterInfo> GetTeamMasterById(Int32 TeamId)
        {
            List<TeamMasterInfo> mInfo;
            TeamMaster mData;
            try
            {
                mInfo = new List<TeamMasterInfo>();
                mData = new TeamMaster();

                mInfo = mData.GetTeamMasterById(TeamId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<TeamMasterInfo> GetTeamMasterByUserId(Int32 UserId)
        {
            List<TeamMasterInfo> mInfo;
            TeamMasterData mData;
            try
            {
                mInfo = new List<TeamMasterInfo>();
                mData = new TeamMasterData();

                mInfo = mData.GetTeamMasterByUserId(UserId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<ContentTypeInfo> GetContentTypeByLibId(Int32 LibId)
        {
            List<ContentTypeInfo> mInfo;
            ContentType mData;
            try
            {
                mInfo = new List<ContentTypeInfo>();
                mData = new ContentType();
                mInfo = mData.GetContentTypeByLibId(LibId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<ContentTypeInfo> GetContentTypeById(Int32 ContentTypeId)
        {
            List<ContentTypeInfo> mInfo;
            ContentType mData;
            try
            {
                mInfo = new List<ContentTypeInfo>();
                mData = new ContentType();
                mInfo = mData.GetContentTypeById(ContentTypeId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        public List<FileExtensionInfo> GetFileExtensionMasterByExtension(String FileExtension)
        {
            List<FileExtensionInfo> mInfo;
            FileExtensionMaster mData;
            try
            {
                mInfo = new List<FileExtensionInfo>();
                mData = new FileExtensionMaster();

                mInfo = mData.FileExtensionByExtension(FileExtension);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        public List<LibraryAttributeSetInfo> GetLibraryAttributeSetByContentTypeId(Int32 ContentTypeId)
        {
            List<LibraryAttributeSetInfo> mInfo;
            LibraryAttributeSet mData;
            try
            {
                mInfo = new List<LibraryAttributeSetInfo>();
                mData = new LibraryAttributeSet();
                mInfo = mData.GetLibraryAttributeSetByContentTypeId(ContentTypeId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<LibraryAttributeSetInfo> GetCommonLibraryAttributeSet(Int32 LibId)
        {
            List<LibraryAttributeSetInfo> mInfo;
            LibraryAttributeSet mData;
            try
            {
                mInfo = new List<LibraryAttributeSetInfo>();
                mData = new LibraryAttributeSet();
                mInfo = mData.GetCommonLibraryAttributeSet(LibId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<LibraryAttributeSetInfo> GetLibraryAttributeSetByLibId(Int32 LibId)
        {
            List<LibraryAttributeSetInfo> mInfo;
            LibraryAttributeSet mData;
            try
            {
                mInfo = new List<LibraryAttributeSetInfo>();
                mData = new LibraryAttributeSet();
                mInfo = mData.GetLibraryAttributeSetByLibId(LibId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<LookupMasterInfo> GetLookupMasterByFieldId(Int32 FieldId, Int32 LibId)
        {
            List<LookupMasterInfo> mInfo;
            LookupMaster mData;
            try
            {
                mInfo = new List<LookupMasterInfo>();
                mData = new LookupMaster();
                mInfo = mData.GetLookupMasterByFieldId(FieldId, LibId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 InsertFileMaster(String strFileMaster,
                                      FileVersionInfo mFileVersion,
                                      DocomentMasterInfo mDocMaster,
                                      String strDocDetails,
                                      String strFileLinks, String strGroupLinks, Int32 TeamId, Int32 LibId, String NotificationType, String IPAddress)
        {
            FileMaster mData;
            Int32 returnValue = 0;
            List<FileInfo> mFileInfo;
            FileInfo objFileInfo;

            List<DocumentDetailInfo> mDocDetails;
            DocumentDetailInfo objDocDetail;

            List<FileLinkDetailInfo> mFileLink;
            FileLinkDetailInfo objFileLink;

            List<DocumentInGroupInfo> mGroupLink;
            DocumentInGroupInfo objGroupLink;
            try
            {
                mData = new FileMaster();
                mFileInfo = new List<FileInfo>();
                mDocDetails = new List<DocumentDetailInfo>();
                mFileLink = new List<FileLinkDetailInfo>();
                mGroupLink = new List<DocumentInGroupInfo>();
                if (strFileMaster.Length > 0)
                {
                    String[] FileInfoDetails = strFileMaster.Split('|');
                    for (int i = 0; i < FileInfoDetails.Length; i++)
                    {
                        String[] FileInfoDetail = FileInfoDetails[i].Split('^');
                        objFileInfo = new FileInfo();
                        objFileInfo.ContentTypeId = Convert.ToInt32(FileInfoDetail[0]);
                        objFileInfo.FileName = FileInfoDetail[1];
                        objFileInfo.GuidName = FileInfoDetail[2];
                        objFileInfo.FileExtension = FileInfoDetail[3];
                        objFileInfo.FileSize = Convert.ToInt64(FileInfoDetail[4]);
                        objFileInfo.CreatedBy = Convert.ToInt32(FileInfoDetail[5]);
                        mFileInfo.Add(objFileInfo);
                        objFileInfo = null;
                    }
                }

                if (strDocDetails.Length > 0)
                {
                    String[] docDetails = strDocDetails.Split('|');
                    for (int i = 0; i < docDetails.Length; i++)
                    {
                        String[] docDetail = docDetails[i].Split('^');
                        objDocDetail = new DocumentDetailInfo();
                        objDocDetail.FieldId = Convert.ToInt32(docDetail[0]);
                        objDocDetail.LoopupId = Convert.ToInt32(docDetail[1]);
                        objDocDetail.FieldValue = docDetail[2];
                        objDocDetail.CreatedBy = Convert.ToInt32(docDetail[3]);
                        objDocDetail.IPAddress = IPAddress;
                        mDocDetails.Add(objDocDetail);
                        objDocDetail = null;
                    }
                }
                if (strFileLinks.Length > 0)
                {
                    String[] strFileLink = strFileLinks.Split('|');
                    for (int i = 0; i < strFileLink.Length; i++)
                    {
                        String[] strLink = strFileLink[i].Split('^');
                        objFileLink = new FileLinkDetailInfo();
                        objFileLink.LinkedFileId = 0;
                        objFileLink.LinkedDocId = Convert.ToInt32(strLink[0]);
                        objFileLink.CreatedBy = Convert.ToInt32(strLink[1]);
                        mFileLink.Add(objFileLink);
                        objFileLink = null;
                    }
                }
                if (strGroupLinks.Length > 0)
                {
                    String[] strGroupLink = strGroupLinks.Split('|');
                    for (int i = 0; i < strGroupLink.Length; i++)
                    {
                        objGroupLink = new DocumentInGroupInfo();
                        objGroupLink.GroupId = Convert.ToInt32(strGroupLink[i]);
                        mGroupLink.Add(objGroupLink);
                        objGroupLink = null;
                    }
                }
                returnValue = mData.InsertFileMaster(mFileInfo, mFileVersion, mDocMaster, mDocDetails, mFileLink,mGroupLink, TeamId, LibId, NotificationType);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return returnValue;
        }

        public DashboardNewFiles GetDashboardNewFiles(String Isconfidential, Int32 ContentTypeId, Int32 LibraryId, Int32 UserId, Int32 TeamId, Boolean IsUserMapped, Boolean IsGroupSpecific)
        {
            FileMaster mData;
            DataTable dt;
            DashboardNewFiles list;
            try
            {
                list = new DashboardNewFiles();
                mData = new FileMaster();
                dt = new DataTable();
                dt = mData.GetDashboardNewFiles(Isconfidential, ContentTypeId, LibraryId, UserId, TeamId, IsUserMapped, IsGroupSpecific);
                dt.TableName = "FileList";
                list.DashboardNewFilesTable = dt;

                return list;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
                list = null;
            }
        }

        public DashboardRecentFiles GetDashboardRecentFiles(String IsConfidential, Int32 ContentTypeId, Int32 LibId, Int32 UserId, Int32 TeamId, Boolean IsUserMapped, Boolean IsGroupSpecific)
        {
            FileMaster mData;
            DataTable dt;
            DashboardRecentFiles list;
            try
            {
                list = new DashboardRecentFiles();
                mData = new FileMaster();
                dt = new DataTable();
                dt = mData.GetDashboardRecentFiles(IsConfidential, ContentTypeId, LibId, UserId, TeamId, IsUserMapped, IsGroupSpecific);
                dt.TableName = "FileList";
                list.DashboardRecentFilesTable = dt;

                return list;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
                list = null;
            }
        }

        public FavouriteDocumentList GetFavouriteDocumentByUserId(Int32 LibraryId, Int32 UserId)
        {
            FavouriteDocument mData;
            DataTable dt;
            FavouriteDocumentList list;
            try
            {
                list = new FavouriteDocumentList();
                mData = new FavouriteDocument();
                dt = new DataTable();
                dt = mData.GetFavouriteDocumentByUserId(LibraryId, UserId);
                dt.TableName = "FavList";
                list.FavouriteDocumentTable = dt;

                return list;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
                list = null;
            }
        }

        public FreeTextSearchFiles GetFreeTextSearchFiles(String SearchText, String IsConfidential, Int32 ContentTypeId, Int32 LibraryId, Int32 TeamId, Int32 UserId, Boolean IsUserMapped, Boolean IsGroupSpecific, Int32 LoggedId)
        {
            FileMaster mData;
            DataTable dt;
            FreeTextSearchFiles list;
            try
            {
                list = new FreeTextSearchFiles();
                mData = new FileMaster();
                dt = new DataTable();
                dt = mData.GetFreeTextSearchFiles(SearchText, IsConfidential, ContentTypeId, LibraryId, TeamId, UserId, IsUserMapped, IsGroupSpecific, LoggedId);
                dt.TableName = "FileList";
                list.FreeTextSearchTable = dt;

                return list;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
                list = null;
            }
        }

        public FreeTextSearchFiles GetFreeTextSearchByContentType(String SearchText, String IsConfidential, Int32 ContentTypeId, Int32 LibraryId, Int32 TeamId, Int32 UserId, Boolean IsUserMapped, Boolean IsGroupSpecific, Int32 LoggedId)
        {
            FileMaster mData;
            DataTable dt;
            FreeTextSearchFiles list;
            try
            {
                list = new FreeTextSearchFiles();
                mData = new FileMaster();
                dt = new DataTable();
                dt = mData.GetFreeTextSearchByContentType(SearchText, IsConfidential, ContentTypeId, LibraryId, TeamId, UserId, IsUserMapped, IsGroupSpecific, LoggedId);
                dt.TableName = "FileList";
                list.FreeTextSearchTable = dt;

                return list;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
                list = null;
            }
        }

        public List<FileInfo> GetFileInfoById(Int32 FileInfoId)
        {
            List<FileInfo> mInfo;
            FileMaster mData;
            try
            {
                mInfo = new List<FileInfo>();
                mData = new FileMaster();

                mInfo = mData.GetFileInfoById(FileInfoId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<FileInfo> GetFileInfoByDocId(Int32 DocId)
        {
            List<FileInfo> mInfo;
            FileMaster mData;
            try
            {
                mInfo = new List<FileInfo>();
                mData = new FileMaster();

                mInfo = mData.GetFileInfoByDocId(DocId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<DocumentDetailInfo> GetFileDocumentDetailsByDocId(Int32 DocId)
        {
            List<DocumentDetailInfo> mInfo;
            FileMaster mData;
            try
            {
                mInfo = new List<DocumentDetailInfo>();
                mData = new FileMaster();

                mInfo = mData.GetFileDocumentDetailsByDocId(DocId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<DocumentDetailInfo> GetUpdatedDocumentDetailsForMail(Int32 DocId)
        {
            List<DocumentDetailInfo> mInfo;
            FileMaster mData;
            try
            {
                mInfo = new List<DocumentDetailInfo>();
                mData = new FileMaster();

                mInfo = mData.GetUpdatedDocumentDetailsForMail(DocId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public LinkedFile GetLinkedFiles(Int32 DocId, Int32 LibId)
        {
            FileMaster mData;
            DataTable dt;
            LinkedFile list;
            try
            {
                list = new LinkedFile();
                mData = new FileMaster();
                dt = new DataTable();
                dt = mData.GetLinkedFiles(DocId, LibId);
                dt.TableName = "FileList";
                list.LinkedFileTable = dt;

                return list;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
                list = null;
            }
        }

        public LinkedFile GetLinkedFilesForUpdate(Int32 DocId, Int32 LibId)
        {
            FileMaster mData;
            DataTable dt;
            LinkedFile list;
            try
            {
                list = new LinkedFile();
                mData = new FileMaster();
                dt = new DataTable();
                dt = mData.GetLinkedFilesForUpdate(DocId, LibId);
                dt.TableName = "FileList";
                list.LinkedFileTable = dt;

                return list;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
                list = null;
            }
        }

        public List<FileVersionInfo> GetFileVersionByDocId(Int32 DocId)
        {
            List<FileVersionInfo> mInfo;
            FileVersion mData;
            try
            {
                mInfo = new List<FileVersionInfo>();
                mData = new FileVersion();

                mInfo = mData.GetFileVersionByDocId(DocId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        #region UserMaster
        public Int32 InsertUserMaster(UserMasterInfo mObj)
        {
            UserMasterData mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new UserMasterData();
                _returnValue = mData.InsertUserMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 UpdateUserMaster(UserMasterInfo mObj)
        {
            UserMasterData mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new UserMasterData();
                _returnValue = mData.UpdateUserMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 ActivateDeactivateUserMaster(UserMasterInfo mObj)
        {
            UserMasterData mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new UserMasterData();
                _returnValue = mData.ActivateDeactivateUserMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<UserMasterInfo> GetAllUserMaster(String LoginUserTeam)
        {
            List<UserMasterInfo> mInfo;
            UserMasterData mData;
            try
            {
                mInfo = new List<UserMasterInfo>();
                mData = new UserMasterData();

                mInfo = mData.GetAllUserMaster(LoginUserTeam);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<UserMasterInfo> GetAllActiveUserMaster()
        {
            List<UserMasterInfo> mInfo;
            UserMasterData mData;
            try
            {
                mInfo = new List<UserMasterInfo>();
                mData = new UserMasterData();
                mInfo = mData.GetAllActiveUserMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                throw (ex);
                //log.Error(ex.Message);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
            
        }

        public List<UserMasterInfo> GetUserMasterById(Int32 UserId)
        {
            List<UserMasterInfo> mInfo;
            UserMasterData mData;
            try
            {
                mInfo = new List<UserMasterInfo>();
                mData = new UserMasterData();

                mInfo = mData.GetUserMasterById(UserId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<UserMasterInfo> GetUserMasterByUserName(String UserName)
        {
            List<UserMasterInfo> mInfo;
            UserMasterData mData;
            try
            {
                mInfo = new List<UserMasterInfo>();
                mData = new UserMasterData();

                mInfo = mData.GetUserMasterByUserName(UserName);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<UserMasterInfo> GetUserMasterSearch(String UserName, String LoginUserTeam)
        {
            List<UserMasterInfo> mInfo;
            UserMasterData mData;
            try
            {
                mInfo = new List<UserMasterInfo>();
                mData = new UserMasterData();

                mInfo = mData.SearchUser(UserName, LoginUserTeam);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        #endregion

        public Int32 InsertFileVersion(FileInfo mFileMaster,
                                      DocumentInFileInfo mDocumentInFile,
                                      FileVersionInfo mFileVersion)
        {
            Int32 returnValue;
            FileMaster mData;
            try
            {
                mData = new FileMaster();
                returnValue = mData.InsertFileVersion(mFileMaster, mDocumentInFile, mFileVersion);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return returnValue;
        }

        public Int32 InsertFileToDocument(FileInfo mFileMaster,Int32 DocId)
        {
            Int32 returnValue;
            FileMaster mData;
            try
            {
                mData = new FileMaster();
                returnValue = mData.InsertFileToDocument(mFileMaster, DocId);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return returnValue;
        }

        public Int32 DocumentInfoDetailUpdate(String strDocDetails)
        {
            Int32 returnValue;
            DocomentMaster mData;
            List<DocumentDetailInfo> mDocDetails;
            DocumentDetailInfo objDocDetail;
            try
            {
                mData = new DocomentMaster();
                mDocDetails = new List<DocumentDetailInfo>();

                if (strDocDetails.Length > 0)
                {
                    String[] docDetails = strDocDetails.Split('|');
                    for (int i = 0; i < docDetails.Length; i++)
                    {
                        String[] docDetail = docDetails[i].Split(',');
                        objDocDetail = new DocumentDetailInfo();
                        objDocDetail.DocId = Convert.ToInt32(docDetail[0]);
                        objDocDetail.FieldId = Convert.ToInt32(docDetail[1]);
                        objDocDetail.LoopupId = Convert.ToInt32(docDetail[2]);
                        objDocDetail.FieldValue = docDetail[3];
                        objDocDetail.ModifiedBy = Convert.ToInt32(docDetail[4]);
                        objDocDetail.IPAddress = docDetail[5];
                        mDocDetails.Add(objDocDetail);
                        objDocDetail = null;
                    }
                }
                returnValue = mData.DocumentInfoDetailUpdate(mDocDetails);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return returnValue;
        }

        #region TeamMaster
        public Int32 InsertTeamMaster(TeamMasterInfo mObj)
        {
            TeamMasterData mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new TeamMasterData();
                _returnValue = mData.InsertTeamMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 UpdateTeamMaster(TeamMasterInfo mObj)
        {
            TeamMasterData mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new TeamMasterData();
                _returnValue = mData.UpdateTeamMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 ActivateDeactivateTeamMaster(TeamMasterInfo mObj)
        {
            TeamMasterData mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new TeamMasterData();
                _returnValue = mData.ActivateDeactivateTeamMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<TeamMasterInfo> GetAllActiveTeamMaster()
        {
            List<TeamMasterInfo> mInfo;
            TeamMasterData mData;
            try
            {
                mInfo = new List<TeamMasterInfo>();
                mData = new TeamMasterData();

                mInfo = mData.GetAllActiveTeamMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<TeamMasterInfo> GetTeamMasterSearch(String TeamName)
        {
            List<TeamMasterInfo> mInfo;
            TeamMasterData mData;
            try
            {
                mInfo = new List<TeamMasterInfo>();
                mData = new TeamMasterData();

                mInfo = mData.SearchTeam(TeamName);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        #endregion

        #region PrivilegeMaster
        public Int32 InsertPrivilegeMaster(PrivilegeMasterInfo mObj)
        {
            PrivilegeMasterData mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new PrivilegeMasterData();
                _returnValue = mData.InsertPrivilegeMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 UpdatePrivilegeMaster(PrivilegeMasterInfo mObj)
        {
            PrivilegeMasterData mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new PrivilegeMasterData();
                _returnValue = mData.UpdatePrivilegeMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 ActivateDeactivatePrivilegeMaster(PrivilegeMasterInfo mObj)
        {
            PrivilegeMasterData mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new PrivilegeMasterData();
                _returnValue = mData.ActivateDeactivatePrivilegeMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<PrivilegeMasterInfo> GetAllPrivilegeMaster()
        {
            List<PrivilegeMasterInfo> mInfo;
            PrivilegeMasterData mData;
            try
            {
                mInfo = new List<PrivilegeMasterInfo>();
                mData = new PrivilegeMasterData();

                mInfo = mData.GetAllPrivilegeMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<PrivilegeMasterInfo> GetAllActivePrivilegeMaster()
        {
            List<PrivilegeMasterInfo> mInfo;
            PrivilegeMasterData mData;
            try
            {
                mInfo = new List<PrivilegeMasterInfo>();
                mData = new PrivilegeMasterData();

                mInfo = mData.GetAllActivePrivilegeMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<PrivilegeMasterInfo> GetPrivilegeMasterById(Int32 PrivilegeId)
        {
            List<PrivilegeMasterInfo> mInfo;
            PrivilegeMasterData mData;
            try
            {
                mInfo = new List<PrivilegeMasterInfo>();
                mData = new PrivilegeMasterData();

                mInfo = mData.GetPrivilegeMasterById(PrivilegeId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<PrivilegeMasterInfo> GetPrivilegeMasterSearch(String PrivilegeName)
        {
            List<PrivilegeMasterInfo> mInfo;
            PrivilegeMasterData mData;
            try
            {
                mInfo = new List<PrivilegeMasterInfo>();
                mData = new PrivilegeMasterData();

                mInfo = mData.SearchPrivilege(PrivilegeName);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        #endregion

        #region UserInTeam
        public List<UserInTeamInfo> GetTeamMasterUserList(Int32 TeamId)
        {
            List<UserInTeamInfo> mInfo;
            UserInTeamData mData;
            try
            {
                mInfo = new List<UserInTeamInfo>();
                mData = new UserInTeamData();

                mInfo = mData.GetTeamMasterUserListByTeamId(TeamId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<UserInTeamInfo> GetUserListNotInParticularTeam(Int32 TeamId)
        {
            List<UserInTeamInfo> mInfo;
            UserInTeamData mData;
            try
            {
                mInfo = new List<UserInTeamInfo>();
                mData = new UserInTeamData();

                mInfo = mData.GetUserListNotInParticularTeam(TeamId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public void InsertUserInTeam(String UsrTmDtl)
        {
            UserInTeamData mData;
            List<UserInTeamInfo> mInfo;
            UserInTeamInfo uList;
            try
            {
                mData = new UserInTeamData();
                mInfo = new List<UserInTeamInfo>();
                if (UsrTmDtl.Length > 0)
                {
                    String[] strUsrTmDtl = UsrTmDtl.Split('|');
                    for (int i = 0; i < strUsrTmDtl.Length; i++)
                    {
                        String[] strLink = strUsrTmDtl[i].Split(',');
                        uList = new UserInTeamInfo();
                        uList.UserId = Convert.ToInt32(strLink[0]);
                        uList.TeamId = Convert.ToInt32(strLink[1]);
                        uList.CreatedBy = Convert.ToInt32(strLink[2]);
                        uList.IPAddress = Convert.ToString(strLink[3]);
                        mInfo.Add(uList);
                        strLink = null;
                    }
                }
                mData.InsertUserInTeamMaster(mInfo);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
        }

        public Int32 ActivateDeactivateUserInTeam(UserInTeamInfo mObj)
        {
            UserInTeamData mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new UserInTeamData();
                _returnValue = mData.ActivateDeactivateUserInTeamMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }
        #endregion

        #region AttributeMaster
        public Int32 InsertAttributeMaster(AttributeFieldsInfo mObj)
        {
            AttributeMasterData mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new AttributeMasterData();
                _returnValue = mData.InsertAttributeMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 UpdateAttributeMaster(AttributeFieldsInfo mObj)
        {
            AttributeMasterData mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new AttributeMasterData();
                _returnValue = mData.UpdateAttributeMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 ActivateDeactivateAttributeMaster(AttributeFieldsInfo mObj)
        {
            AttributeMasterData mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new AttributeMasterData();
                _returnValue = mData.ActivateDeactivateAttributeMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }
        public List<AttributeFieldsInfo> GetAllAttributeMaster()
        {
            List<AttributeFieldsInfo> mInfo;
            AttributeMasterData mData;
            try
            {
                mInfo = new List<AttributeFieldsInfo>();
                mData = new AttributeMasterData();

                mInfo = mData.GetAllAttributeMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<AttributeFieldsInfo> GetAllActiveAttributeMaster()
        {
            List<AttributeFieldsInfo> mInfo;
            AttributeMasterData mData;
            try
            {
                mInfo = new List<AttributeFieldsInfo>();
                mData = new AttributeMasterData();

                mInfo = mData.GetActiveAllListTypeAttributeMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<AttributeFieldsInfo> GetAttributeMasterById(Int32 FieldId)
        {
            List<AttributeFieldsInfo> mInfo;
            AttributeMasterData mData;
            try
            {
                mInfo = new List<AttributeFieldsInfo>();
                mData = new AttributeMasterData();

                mInfo = mData.GetAttributeMasterById(FieldId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<AttributeFieldsInfo> GetAttributeMasterSearch(String FieldName)
        {
            List<AttributeFieldsInfo> mInfo;
            AttributeMasterData mData;
            try
            {
                mInfo = new List<AttributeFieldsInfo>();
                mData = new AttributeMasterData();

                mInfo = mData.SearchAttribute(FieldName);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        #endregion

        public Int32 UpdateFileVersion(Int32 DocId, Int32 FileInfoId, Int32 ModifiedBy)
        {
            FileVersion mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new FileVersion();
                _returnValue = mData.UpdateFileVersion(DocId, FileInfoId, ModifiedBy);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 UpdateDocomentInfoMaster(Int32 DocId, String Keywords, Int32 ModifiedBy, String IPAddress)
        {
            DocomentMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new DocomentMaster();
                _returnValue = mData.UpdateDocomentInfoMaster(DocId, Keywords, ModifiedBy, IPAddress);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 DeactivateFileLinkDetail(Int32 DocId)
        {
            FileMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new FileMaster();
                _returnValue = mData.DeactivateFileLinkDetail(DocId);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }


        public Int32 UpdateFileLinkDetail(Int32 DocId, String strFileLinks, String IPAddress)
        {
            FileMaster mData;
            Int32 returnVal;
            List<FileLinkDetailInfo> mFileLink;
            FileLinkDetailInfo objFileLink;
            try
            {
                mData = new FileMaster();
                mFileLink = new List<FileLinkDetailInfo>();
                if (strFileLinks.Length > 0)
                {
                    String[] strFileLink = strFileLinks.Split('|');
                    for (int i = 0; i < strFileLink.Length; i++)
                    {
                        String[] strLink = strFileLink[i].Split(',');
                        objFileLink = new FileLinkDetailInfo();
                        objFileLink.LinkedFileId = 0;
                        objFileLink.LinkedDocId = Convert.ToInt32(strLink[0]);
                        objFileLink.CreatedBy = Convert.ToInt32(strLink[1]);
                        mFileLink.Add(objFileLink);
                        objFileLink = null;
                    }
                }
                returnVal = mData.UpdateFileLinkDetail(DocId, mFileLink , IPAddress);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return returnVal;
        }

        public Int32 InsertUserLoginHistory(Int32 UserId)
        {
            UserMasterData mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new UserMasterData();
                _returnValue = mData.InsertUserLoginHistory(UserId);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 UpdateUserLogoutHistory(Int32 UserId)
        {
            UserMasterData mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new UserMasterData();
                _returnValue = mData.UpdateUserLogoutHistory(UserId);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<LibraryMasterInfo> GetLibraryMasterByUserId(Int32 UserId, Int32 TeamId)
        {
            List<LibraryMasterInfo> mInfo;
            LibraryMaster mData;
            try
            {
                mInfo = new List<LibraryMasterInfo>();
                mData = new LibraryMaster();

                mInfo = mData.GetLibraryMasterByUserId(UserId, TeamId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        #region LookupMaster
        public List<LookupMasterInfo> GetAttributeMasterLookupList(Int32 FieldId)
        {
            List<LookupMasterInfo> mInfo;
            LookupMaster mData;
            try
            {
                mInfo = new List<LookupMasterInfo>();
                mData = new LookupMaster();

                mInfo = mData.GetAttributeMasterLookupListByFieldId(FieldId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<LibraryMasterInfo> GetAllActiveLibraryMaster()
        {
            List<LibraryMasterInfo> mInfo;
            LibraryMaster mData;
            try
            {
                mInfo = new List<LibraryMasterInfo>();
                mData = new LibraryMaster();

                mInfo = mData.GetAllActiveLibraryMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<AttributeFieldsInfo> GetAllActiveListTypeAttributeMaster()
        {
            List<AttributeFieldsInfo> mInfo;
            AttributeMasterData mData;
            try
            {
                mInfo = new List<AttributeFieldsInfo>();
                mData = new AttributeMasterData();

                mInfo = mData.GetActiveAllListTypeAttributeMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<LookupMasterInfo> GetLookupMasterById(Int32 LookupId)
        {
            List<LookupMasterInfo> mInfo;
            LookupMaster mData;
            try
            {
                mInfo = new List<LookupMasterInfo>();
                mData = new LookupMaster();

                mInfo = mData.GetLookupMasterByLookupId(LookupId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 InsertLookupMaster(LookupMasterInfo mObj)
        {
            LookupMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new LookupMaster();
                _returnValue = mData.InsertLookupMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 UpdateLookupMaster(LookupMasterInfo mObj)
        {
            LookupMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new LookupMaster();
                _returnValue = mData.UpdateLookupMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 ActivateDeactivateLookupMaster(LookupMasterInfo mObj)
        {
            LookupMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new LookupMaster();
                _returnValue = mData.ActivateDeactivateLookupMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 ActivateDeactivateLookupMasterAll(LookupMasterInfo mObj)
        {
            LookupMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new LookupMaster();
                _returnValue = mData.ActivateDeactivateLookupMasterAll(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }
        #endregion
        #region TeamInPrivilege
        public List<TeamInPrivilegeInfo> GetAllActiveTeamInPrivilege(Int32 ContentTypeId)
        {
            List<TeamInPrivilegeInfo> mInfo;
            TeamInPrivilege mData;
            try
            {
                mInfo = new List<TeamInPrivilegeInfo>();
                mData = new TeamInPrivilege();

                mInfo = mData.GetAllTeamInPrivilege(ContentTypeId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<TeamInPrivilegeInfo> GetAllTeamMasterRowsNotInTeamInPrivilegeServ()
        {
            List<TeamInPrivilegeInfo> mInfo;
            TeamInPrivilege mData;
            try
            {
                mInfo = new List<TeamInPrivilegeInfo>();
                mData = new TeamInPrivilege();

                mInfo = mData.GetAllTeamMasterRowsNotInTeamInPrivilege();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<TeamInPrivilegeInfo> GetAllPrivilegeMasterRowsNotInTeamInPrivilegeServ(Int32 ContentTypeId, Int32 TeamId)
        {
            List<TeamInPrivilegeInfo> mInfo;
            TeamInPrivilege mData;
            try
            {
                mInfo = new List<TeamInPrivilegeInfo>();
                mData = new TeamInPrivilege();

                mInfo = mData.GetAllPrivilegeMasterRowsNotInTeamInPrivilege(ContentTypeId, TeamId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<TeamInPrivilegeInfo> GetTeamInPrivilegeByTeamId(Int32 TeamId,Int32 LibId)
        {
            List<TeamInPrivilegeInfo> mInfo;
            TeamInPrivilege mData;
            try
            {
                mInfo = new List<TeamInPrivilegeInfo>();
                mData = new TeamInPrivilege();

                mInfo = mData.GetTeamInPrivilegeByTeamId(TeamId, LibId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public void InsertTeamInPrivilege(String TmPrvDtl)
        {
            TeamInPrivilege mData;
            List<TeamInPrivilegeInfo> mInfo;
            TeamInPrivilegeInfo uList;
            try
            {
                mData = new TeamInPrivilege();
                mInfo = new List<TeamInPrivilegeInfo>();
                if (TmPrvDtl.Length > 0)
                {
                    String[] strUsrTmDtl = TmPrvDtl.Split('|');
                    for (int i = 0; i < strUsrTmDtl.Length; i++)
                    {
                        String[] strLink = strUsrTmDtl[i].Split(',');
                        uList = new TeamInPrivilegeInfo();
                        uList.TeamId = Convert.ToInt32(strLink[0]);
                        uList.PrivilegeId = Convert.ToInt32(strLink[1]);
                        uList.Permission = Convert.ToInt32(strLink[2]);
                        uList.ContentTypeId = Convert.ToInt32(strLink[3]);
                        uList.LibId = Convert.ToInt32(strLink[4]);
                        uList.IsBrandCategoryMapped = Convert.ToBoolean(strLink[5]);
                        uList.CreatedBy = Convert.ToInt32(strLink[6]);
                        uList.IPAddress = Convert.ToString(strLink[7]);
                        mInfo.Add(uList);
                        strLink = null;
                    }
                }
                mData.InsertTeamInPrivilege(mInfo);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
        }
        #endregion
        public Int32 ActivateDeactivateLibraryMaster(LibraryMasterInfo mData)
        {
            LibraryMaster lData;
            Int32 _returnValue = 0;
            try
            {
                lData = new LibraryMaster();
                _returnValue = lData.ActivateDeactivateLibraryMaster(mData);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }
        public Int32 InsertLibraryMaster(LibraryMasterInfo lMaster, ContentTypeInfo cType, String laSet)
        {
            LibraryMaster mData;
            List<LibraryAttributeSetInfo> mInfo;
            LibraryAttributeSetInfo uList;
            Int32 _returnValue = 0;
            try
            {
                mData = new LibraryMaster();
                mInfo = new List<LibraryAttributeSetInfo>();
                if (laSet.Length > 0)
                {
                    String[] strLibAtrSet = laSet.Split('|');
                    for (int i = 0; i < strLibAtrSet.Length; i++)
                    {
                        String[] strLink = strLibAtrSet[i].Split(',');
                        uList = new LibraryAttributeSetInfo();
                        uList.FieldId = Convert.ToInt32(strLink[0]);
                        uList.AttributeType = Convert.ToString(strLink[1]);
                        uList.IsMandatory = Convert.ToBoolean(strLink[2]);
                        uList.ColumnOrder = Convert.ToInt32(strLink[3]);
                        uList.CreatedBy = Convert.ToInt32(strLink[4]);
                        uList.IPAddress = Convert.ToString(strLink[5]);
                        mInfo.Add(uList);
                        strLink = null;
                    }
                }
                _returnValue = mData.InsertLibraryMaster(lMaster, cType, mInfo);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public void UpdateLibraryMaster(String laSet)
        {
            LibraryMaster mData;
            List<LibraryAttributeSetInfo> mInfo;
            LibraryAttributeSetInfo uList;
            try
            {
                mData = new LibraryMaster();
                mInfo = new List<LibraryAttributeSetInfo>();
                if (laSet.Length > 0)
                {
                    String[] strLibAtrSet = laSet.Split('|');
                    for (int i = 0; i < strLibAtrSet.Length; i++)
                    {
                        String[] strLink = strLibAtrSet[i].Split(',');
                        uList = new LibraryAttributeSetInfo();
                        uList.FieldId = Convert.ToInt32(strLink[0]);
                        uList.ContentTypeId = Convert.ToInt32(strLink[1]);
                        uList.AttributeType = Convert.ToString(strLink[2]);
                        uList.IsMandatory = Convert.ToBoolean(strLink[3]);
                        uList.ColumnOrder = Convert.ToInt32(strLink[4]);
                        uList.CreatedBy = Convert.ToInt32(strLink[5]);
                        mInfo.Add(uList);
                        strLink = null;
                    }
                }
                mData.UpdateLibraryMaster(mInfo);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
        }

        public List<ContentTypeInfo> GetContentTypeAutoComplete(String Description)
        {
            List<ContentTypeInfo> mInfo;
            ContentType mData;
            try
            {
                mInfo = new List<ContentTypeInfo>();
                mData = new ContentType();
                mInfo = mData.GetContentTypeParticularRows(Description);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        public List<AttributeFieldsInfo> GetAllActiveAttributeMasterForLibrary()
        {
            List<AttributeFieldsInfo> mInfo;
            LibraryMaster mData;
            try
            {
                mInfo = new List<AttributeFieldsInfo>();
                mData = new LibraryMaster();

                mInfo = mData.GetAllActiveAttributeMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        public List<LibraryMasterInfo> GetAllLibraryMasterContentType()
        {
            List<LibraryMasterInfo> mInfo;
            LibraryMaster mData;
            try
            {
                mInfo = new List<LibraryMasterInfo>();
                mData = new LibraryMaster();

                mInfo = mData.GetAllLibraryMasterContentType();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        public List<LibraryMasterInfo> GetLibraryMasterRowDetailsById(Int32 LibId, Int32 ContentTypeId)
        {
            List<LibraryMasterInfo> mInfo;
            LibraryMaster mData;
            try
            {
                mInfo = new List<LibraryMasterInfo>();
                mData = new LibraryMaster();

                mInfo = mData.GetLibraryMasterRowDetailById(LibId, ContentTypeId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        public List<LibraryMasterInfo> GetLibraryMasterSearch(String LibraryName)
        {
            List<LibraryMasterInfo> mInfo;
            LibraryMaster mData;
            try
            {
                mInfo = new List<LibraryMasterInfo>();
                mData = new LibraryMaster();

                mInfo = mData.GetLibraryMasterSearch(LibraryName);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        public Int32 AddRemoveFavourite(Int32 DocId, Boolean IsFavourite, Int32 CreatedBy)
        {
            FavouriteDocument mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new FavouriteDocument();
                _returnValue = mData.AddRemoveFavourite(DocId, IsFavourite, CreatedBy);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<FavouriteDocumentInfo> GetFavouriteDocumentByDocId(Int32 DocId, Int32 CreatedBy)
        {
            List<FavouriteDocumentInfo> mInfo;
            FavouriteDocument mData;
            try
            {
                mInfo = new List<FavouriteDocumentInfo>();
                mData = new FavouriteDocument();

                mInfo = mData.GetFavouriteDocumentByDocId(DocId, CreatedBy);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        public List<LookupMasterInfo> GetAllActiveAttributeMasterLookupList()
        {
            List<LookupMasterInfo> mInfo;
            LookupMaster mData;
            try
            {
                mInfo = new List<LookupMasterInfo>();
                mData = new LookupMaster();

                mInfo = mData.GetSelectAllActiveAttributeMasterLookupList();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        public List<UserInTeamInfo> GetAllActiveTeamMasterUserList()
        {
            List<UserInTeamInfo> mInfo;
            UserInTeamData mData;
            try
            {
                mInfo = new List<UserInTeamInfo>();
                mData = new UserInTeamData();

                mInfo = mData.GetAllActiveTeamMasterUserList();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        public Int32 UpdateFavouriteDocument(String strFavList)
        {
            FavouriteDocument mData;
            Int32 returnVal;
            List<FavouriteDocumentInfo> mFav;
            FavouriteDocumentInfo objFav;
            try
            {
                mData = new FavouriteDocument();
                mFav = new List<FavouriteDocumentInfo>();
                if (strFavList.Length > 0)
                {
                    String[] strFileLink = strFavList.Split('|');
                    for (int i = 0; i < strFileLink.Length; i++)
                    {
                        String[] strLink = strFileLink[i].Split('^');
                        objFav = new FavouriteDocumentInfo();
                        objFav.DocId = Convert.ToInt32(strLink[0]);
                        objFav.Label = strLink[1];
                        objFav.ModifiedBy = Convert.ToInt32(strLink[2]);
                        mFav.Add(objFav);
                        objFav = null;
                    }
                }
                returnVal = mData.UpdateFavouriteDocument(mFav);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return returnVal;
        }

        public FreeTextSearchFiles AdvanceSearch(String SearchText, String IsConfidential, Int32 ContentTypeId, Int32 LibId, Int32 TeamId, Int32 UserId, Boolean IsUserMapped,Boolean IsGroupSpecific,Int32 LoggedId)
        {
            FileMaster mData;
            DataTable dt;
            FreeTextSearchFiles list;
            try
            {
                list = new FreeTextSearchFiles();
                mData = new FileMaster();
                dt = new DataTable();
                dt = mData.AdvanceSearch(SearchText, IsConfidential, ContentTypeId, LibId, TeamId, UserId, IsUserMapped,IsGroupSpecific,LoggedId);
                dt.TableName = "FileList";
                list.FreeTextSearchTable = dt;

                return list;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
                list = null;
            }
        }

        public FreeTextSearchFiles AdvanceSearchByContentType(String SearchText, String IsConfidential, Int32 ContentTypeId, Int32 LibId, Int32 TeamId, Int32 UserId, Boolean IsUserMapped, Boolean IsGroupSpecific, Int32 LoggedId)
        {
            FileMaster mData;
            DataTable dt;
            FreeTextSearchFiles list;
            try
            {
                list = new FreeTextSearchFiles();
                mData = new FileMaster();
                dt = new DataTable();
                dt = mData.AdvanceSearchByContentType(SearchText, IsConfidential, ContentTypeId, LibId, TeamId, UserId, IsUserMapped, IsGroupSpecific, LoggedId);
                dt.TableName = "FileList";
                list.FreeTextSearchTable = dt;

                return list;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
                list = null;
            }
        }

        public void InsertTeamInLibraryMaster(String UsrTmDtl)
        {
            TeamInLibrary mData;
            List<TeamInLibraryInfo> mInfo;
            TeamInLibraryInfo uList;
            try
            {
                mData = new TeamInLibrary();
                mInfo = new List<TeamInLibraryInfo>();
                if (UsrTmDtl.Length > 0)
                {
                    String[] strUsrTmDtl = UsrTmDtl.Split('|');
                    for (int i = 0; i < strUsrTmDtl.Length; i++)
                    {
                        String[] strLink = strUsrTmDtl[i].Split(',');
                        uList = new TeamInLibraryInfo();
                        uList.TeamId = Convert.ToInt32(strLink[0]);
                        uList.LibId = Convert.ToInt32(strLink[1]);
                        uList.CreatedBy = Convert.ToInt32(strLink[2]);
                        uList.IPAddress = Convert.ToString(strLink[3]);
                        mInfo.Add(uList);
                        strLink = null;
                    }
                }
                mData.InsertTeamInLibraryMaster(mInfo);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
        }

        public List<TeamInLibraryInfo> GetAllActiveTeamInLibrary()
        {
            List<TeamInLibraryInfo> mInfo;
            TeamInLibrary mData;
            try
            {
                mInfo = new List<TeamInLibraryInfo>();
                mData = new TeamInLibrary();

                mInfo = mData.GetAllActiveTeamInLibrary();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<UserNotificationInfo> GetUserNotification(Int32 TeamId, Int32 VisiterUserId, Int32 LibId)
        {
            List<UserNotificationInfo> mInfo;
            UserNotification mData;
            try
            {
                mInfo = new List<UserNotificationInfo>();
                mData = new UserNotification();

                mInfo = mData.GetUserNotification(TeamId, VisiterUserId, LibId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<TeamInPrivilegeInfo> GetTeamInPrivilegePrivilegeAllTeamId(Int32 TeamId, Int32 LibId, Int32 ContentTypeId)
        {
            List<TeamInPrivilegeInfo> mInfo;
            TeamInPrivilege mData;
            try
            {
                mInfo = new List<TeamInPrivilegeInfo>();
                mData = new TeamInPrivilege();

                mInfo = mData.GetTeamInPrivilegePrivilegeAllByTeamId(TeamId, LibId, ContentTypeId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 InsertUserNotification(Int32 UserId, Int32 TeamId, Int32 DocId, Int32 LibId, String NotificationType)
        {
            UserNotification mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new UserNotification();
                _returnValue = mData.InsertUserNotification( UserId,  TeamId, DocId, LibId, NotificationType);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public FreeTextSearchFiles UserNotificationList(Int32 LibId, Int32 UserId, String NotificationType)
        {
            UserNotification mData;
            DataTable dt;
            FreeTextSearchFiles list;
            try
            {
                list = new FreeTextSearchFiles();
                mData = new UserNotification();
                dt = new DataTable();
                dt = mData.UserNotificationList(LibId, UserId, NotificationType);
                dt.TableName = "FileList";
                list.FreeTextSearchTable = dt;

                return list;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
                list = null;
            }
        }

        public Int32 UpdateUserNotification(Int32 UserId, Int32 TeamId, Int32 LibId, String NotificationType)
        {
            UserNotification mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new UserNotification();
                _returnValue = mData.UpdateUserNotification(UserId, TeamId, LibId, NotificationType);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<TeamInLibraryInfo> GetAllTeamInLibrary()
        {
            List<TeamInLibraryInfo> mInfo;
            TeamInLibrary mData;
            try
            {
                mInfo = new List<TeamInLibraryInfo>();
                mData = new TeamInLibrary();

                mInfo = mData.GetAllTeamInLibrary();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 ActivateDeactivateTeamInLibrary(TeamInLibraryInfo mObj)
        {
            TeamInLibrary mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new TeamInLibrary();
                _returnValue = mData.ActivateDeactivateTeamInLibrary(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }
        public List<TeamInLibraryInfo> GetTeamInLibrarySearch(String SearchString)
        {
            List<TeamInLibraryInfo> mInfo;
            TeamInLibrary mData;
            try
            {
                mInfo = new List<TeamInLibraryInfo>();
                mData = new TeamInLibrary();

                mInfo = mData.GetTeamInLibrarySearch(SearchString);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<UserInTeamInfo> GetAllUserInTeamList(String SearchString)
        {
            List<UserInTeamInfo> mInfo;
            UserInTeamData mData;
            try
            {
                mInfo = new List<UserInTeamInfo>();
                mData = new UserInTeamData();

                mInfo = mData.GetAllUserInTeamSearch(SearchString);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<TeamMasterInfo> GetAllTeamNotInLibraryById(Int32 LibId)
        {
            List<TeamMasterInfo> mInfo;
            TeamMasterData mData;
            try
            {
                mInfo = new List<TeamMasterInfo>();
                mData = new TeamMasterData();

                mInfo = mData.GetAllTeamNotInLibraryByLibId(LibId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<LookupMasterInfo> GetAttributeMasterLookupListSearch(String SearchString)
        {
            List<LookupMasterInfo> mInfo;
            LookupMaster mData;
            try
            {
                mInfo = new List<LookupMasterInfo>();
                mData = new LookupMaster();

                mInfo = mData.GetSelectAttributeMasterLookupSearch(SearchString);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 InsertSaveSearch(SaveSearchInfo mObj)
        {
            SaveSearch mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new SaveSearch();
                _returnValue = mData.InsertSaveSearch(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<SaveSearchInfo> GetSaveSearch(Int32 UserId, Int32 LibId, Int32 TeamId)
        {
            List<SaveSearchInfo> mInfo;
            SaveSearch mData;
            try
            {
                mInfo = new List<SaveSearchInfo>();
                mData = new SaveSearch();

                mInfo = mData.GetSaveSearch(UserId, LibId, TeamId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<LabelMasterInfo> GetLabelByUserId(Int32 UserId)
        {
            List<LabelMasterInfo> mInfo;
            FavouriteDocument mData;
            try
            {
                mInfo = new List<LabelMasterInfo>();
                mData = new FavouriteDocument();

                mInfo = mData.GetLabelByUserId(UserId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 InsertLabelMaster(String Label, Int32 UserId)
        {
            FavouriteDocument mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new FavouriteDocument();
                _returnValue = mData.InsertLabelMaster(Label, UserId);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 DeleteSaveSearch(Int32 SaveSearchId)
        {
            SaveSearch mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new SaveSearch();
                _returnValue = mData.DeleteSaveSearch(SaveSearchId);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }


        public Int32 DeleteFile(Int32 FileInfoId, Int32 UserId)
        {
            FileMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new FileMaster();
                _returnValue = mData.DeleteFile(FileInfoId, UserId);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        #region LocationMaster
        public List<LocationMasterInfo> GetAllLocationMaster()
        {
            List<LocationMasterInfo> mInfo;
            LocationMaster mData;
            try
            {
                mInfo = new List<LocationMasterInfo>();
                mData = new LocationMaster();

                mInfo = mData.GetAllLocationMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<LocationMasterInfo> GetLocationMasterById(Int32 LocationId)
        {
            List<LocationMasterInfo> mInfo;
            LocationMaster mData;
            try
            {
                mInfo = new List<LocationMasterInfo>();
                mData = new LocationMaster();

                mInfo = mData.GetLocationMasterById(LocationId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 InsertLocationMaster(LocationMasterInfo mObj)
        {
            LocationMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new LocationMaster();
                _returnValue = mData.InsertLocationMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 UpdateLocationMaster(LocationMasterInfo mObj)
        {
            LocationMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new LocationMaster();
                _returnValue = mData.UpdateLocationMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 ActivateDeactivateLocationMaster(LocationMasterInfo mObj)
        {
            LocationMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new LocationMaster();
                _returnValue = mData.ActivateDeactivateLocationMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<LocationMasterInfo> GetAllActiveLocationMaster()
        {
            List<LocationMasterInfo> mInfo;
            LocationMaster mData;
            try
            {
                mInfo = new List<LocationMasterInfo>();
                mData = new LocationMaster();

                mInfo = mData.GetAllActiveLocationMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<LocationMasterInfo> GetLocationMasterSearch(String Location)
        {
            List<LocationMasterInfo> mInfo;
            LocationMaster mData;
            try
            {
                mInfo = new List<LocationMasterInfo>();
                mData = new LocationMaster();

                mInfo = mData.SearchLocation(Location);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        #endregion

        #region DesignationMaster
        public List<DesignationMasterInfo> GetAllDesignationMaster()
        {
            List<DesignationMasterInfo> mInfo;
            DesignationMaster mData;
            try
            {
                mInfo = new List<DesignationMasterInfo>();
                mData = new DesignationMaster();

                mInfo = mData.GetAllDesignationMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<DesignationMasterInfo> GetDesignationMasterById(Int32 DesignationId)
        {
            List<DesignationMasterInfo> mInfo;
            DesignationMaster mData;
            try
            {
                mInfo = new List<DesignationMasterInfo>();
                mData = new DesignationMaster();

                mInfo = mData.GetDesignationMasterById(DesignationId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 InsertDesignationMaster(DesignationMasterInfo mObj)
        {
            DesignationMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new DesignationMaster();
                _returnValue = mData.InsertDesignationMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 UpdateDesignationMaster(DesignationMasterInfo mObj)
        {
            DesignationMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new DesignationMaster();
                _returnValue = mData.UpdateDesignationMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 ActivateDeactivateDesignationMaster(DesignationMasterInfo mObj)
        {
            DesignationMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new DesignationMaster();
                _returnValue = mData.ActivateDeactivateDesignationMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<DesignationMasterInfo> GetAllActiveDesignationMaster()
        {
            List<DesignationMasterInfo> mInfo;
            DesignationMaster mData;
            try
            {
                mInfo = new List<DesignationMasterInfo>();
                mData = new DesignationMaster();

                mInfo = mData.GetAllActiveDesignationMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<DesignationMasterInfo> GetDesignationMasterSearch(String Designation)
        {
            List<DesignationMasterInfo> mInfo;
            DesignationMaster mData;
            try
            {
                mInfo = new List<DesignationMasterInfo>();
                mData = new DesignationMaster();

                mInfo = mData.SearchDesignation(Designation);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        #endregion

        #region DepartmentMaster
        public List<DepartmentMasterInfo> GetAllDepartmentMaster()
        {
            List<DepartmentMasterInfo> mInfo;
            DepartmentMaster mData;
            try
            {
                mInfo = new List<DepartmentMasterInfo>();
                mData = new DepartmentMaster();

                mInfo = mData.GetAllDepartmentMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<DepartmentMasterInfo> GetDepartmentMasterById(Int32 DepartmentId)
        {
            List<DepartmentMasterInfo> mInfo;
            DepartmentMaster mData;
            try
            {
                mInfo = new List<DepartmentMasterInfo>();
                mData = new DepartmentMaster();

                mInfo = mData.GetDepartmentMasterById(DepartmentId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 InsertDepartmentMaster(DepartmentMasterInfo mObj)
        {
            DepartmentMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new DepartmentMaster();
                _returnValue = mData.InsertDepartmentMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 UpdateDepartmentMaster(DepartmentMasterInfo mObj)
        {
            DepartmentMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new DepartmentMaster();
                _returnValue = mData.UpdateDepartmentMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 ActivateDeactivateDepartmentMaster(DepartmentMasterInfo mObj)
        {
            DepartmentMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new DepartmentMaster();
                _returnValue = mData.ActivateDeactivateDepartmentMaster(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<DepartmentMasterInfo> GetAllActiveDepartmentMaster()
        {
            List<DepartmentMasterInfo> mInfo;
            DepartmentMaster mData;
            try
            {
                mInfo = new List<DepartmentMasterInfo>();
                mData = new DepartmentMaster();

                mInfo = mData.GetAllActiveDepartmentMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<DepartmentMasterInfo> GetDepartmentMasterSearch(String Department)
        {
            List<DepartmentMasterInfo> mInfo;
            DepartmentMaster mData;
            try
            {
                mInfo = new List<DepartmentMasterInfo>();
                mData = new DepartmentMaster();

                mInfo = mData.SearchDepartment(Department);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        #endregion

        public Int32 ActivateDeactivateAttributeMasterAll(AttributeFieldsInfo mObj)
        {
            AttributeMasterData mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new AttributeMasterData();
                _returnValue = mData.ActivateDeactivateAttributeMasterAll(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<DocomentMasterInfo> GetContentTypeIdByDocId(Int32 DocId)
        {
            List<DocomentMasterInfo> mInfo;
            DocomentMaster mData;
            try
            {
                mInfo = new List<DocomentMasterInfo>();
                mData = new DocomentMaster();

                mInfo = mData.GetContentTypeIdByDocId(DocId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<DocSerialNoInfo> GetNextSerialNoByLibId(Int32 LibId)
        {
            List<DocSerialNoInfo> mInfo;
            DocomentMaster mData;
            try
            {
                mInfo = new List<DocSerialNoInfo>();
                mData = new DocomentMaster();

                mInfo = mData.GetNextSerialNoByLibId(LibId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        #region EmailSettingsMaster
        public List<EmailSettingsInfo> GetAllEmailSettingsMaster(Int32 TeamId)
        {
            List<EmailSettingsInfo> mInfo;
            EmailSettingsMaster mData;
            try
            {
                mInfo = new List<EmailSettingsInfo>();
                mData = new EmailSettingsMaster();

                mInfo = mData.GetAllEmailSettingsMaster(TeamId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public void InsertEmailSettingsMaster(String EmSetDtl, Int32 TeamId)
        {
            EmailSettingsMaster mData;
            List<EmailSettingsInfo> mInfo;
            EmailSettingsInfo uList;
            try
            {
                mData = new EmailSettingsMaster();
                mInfo = new List<EmailSettingsInfo>();
                if (EmSetDtl.Length > 0)
                {
                    String[] strEmSetDtl = EmSetDtl.Split('|');
                    for (int i = 0; i < strEmSetDtl.Length; i++)
                    {
                        String[] strLink = strEmSetDtl[i].Split(',');
                        uList = new EmailSettingsInfo();
                        uList.TeamId = TeamId;
                        uList.AppAdminId = Convert.ToInt32(strLink[0]);
                        uList.UserId = Convert.ToInt32(strLink[1]);
                        uList.IsUpload = Convert.ToBoolean(strLink[2]);
                        uList.IsEdit = Convert.ToBoolean(strLink[3]);
                        uList.IsDelete = Convert.ToBoolean(strLink[4]);
                        uList.IsOnExpiry = Convert.ToBoolean(strLink[5]);
                        uList.CreatedBy = Convert.ToInt32(strLink[6]);
                        uList.IPAddress = Convert.ToString(strLink[7]);
                        mInfo.Add(uList);
                        strLink = null;
                    }
                }
                mData.InsertEmailSettingsMaster(mInfo);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
        }

        public List<EmailSettingsInfo> GetEmailSettingsMasterSearch(String SearchText)
        {
            List<EmailSettingsInfo> mInfo;
            EmailSettingsMaster mData;
            try
            {
                mInfo = new List<EmailSettingsInfo>();
                mData = new EmailSettingsMaster();

                mInfo = mData.GetEmailSettingsSearch(SearchText);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        #endregion

        public Int32 DeleteDocFile(Int32 FileInfoId, Int32 UserId, String IPAddress)
        {
            FileMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new FileMaster();
                _returnValue = mData.DeleteDocFile(FileInfoId, UserId, IPAddress);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<ContentTypeInfo> GetContentTypeNotInTeamPrivilegeByLibId(Int32 TeamId, Int32 LibId)
        {
            List<ContentTypeInfo> mInfo;
            TeamInPrivilege mData;
            try
            {
                mInfo = new List<ContentTypeInfo>();
                mData = new TeamInPrivilege();
                mInfo = mData.GetContentTypeNotInTeamPrivilegeByLibId(TeamId, LibId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 InsertEmailTemplate(String TemplateName, String Subject, String Body)
        {
            Int32 returnValue;
            EmailTemplate mData;
            try
            {
                mData = new EmailTemplate();
                returnValue = mData.InsertEmailTemplate(TemplateName, Subject, Body);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return returnValue;
        }

        public Int32 UpdateEmailTemplate(Int32 TemplateId, String TemplateName, String Subject, String Body)
        {
            Int32 returnValue;
            EmailTemplate mData;
            try
            {
                mData = new EmailTemplate();
                returnValue = mData.UpdateEmailTemplate(TemplateId, TemplateName, Subject, Body);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return returnValue;
        }

        public List<EmailTemplateInfo> GetAllEmailTemplate()
        {
            List<EmailTemplateInfo> mInfo;
            EmailTemplate mData;
            try
            {
                mInfo = new List<EmailTemplateInfo>();
                mData = new EmailTemplate();
                mInfo = mData.GetAllEmailTemplate();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<EmailTemplateInfo> GetAllEmailTemplateById(Int32 TemplateId)
        {
            List<EmailTemplateInfo> mInfo;
            //List<EmailTemplateInfo> mInfoReturn;
            EmailTemplate mData;
            try
            {
                mInfo = new List<EmailTemplateInfo>();
                //mInfoReturn = new List<EmailTemplateInfo>();
                mData = new EmailTemplate();
                mInfo = mData.GetAllEmailTemplateById(TemplateId);
                //for(int i=0;i<mInfo.Count();i++)
                //{
                //    mInfoReturn.Add(new EmailTemplateInfo
                //    {
                //        Body = HttpContext.Current.Server.HtmlDecode(mInfo[i].Body),
                //        Subject = HttpContext.Current.Server.HtmlDecode(mInfo[i].Subject),
                //        TemplateId = mInfo[i].TemplateId,
                //        TemplateName = mInfo[i].TemplateName,
                //    });
                //}
                //return mInfoReturn;
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<ContentTypeMasterInfo> GetContentTypeMaster()
        {
            List<ContentTypeMasterInfo> mInfo;
            ContentType mData;
            try
            {
                mInfo = new List<ContentTypeMasterInfo>();
                mData = new ContentType();
                mInfo = mData.GetContentTypeMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }


        public Int32 InsertEventMaster(String EventName, Int32 CreatedBy)
        {
            EventMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new EventMaster();
                _returnValue = mData.InsertEventMaster(EventName,CreatedBy);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 UpdateEventMaster(Int32 EventId, String EventName, Int32 ModifiedBy)
        {
            EventMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new EventMaster();
                _returnValue = mData.UpdateEventMaster(EventId, EventName, ModifiedBy);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 ActivateDeactivateEventMaster(Int32 EventId, Boolean IsActive, Int32 ModifiedBy)
        {
            EventMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new EventMaster();
                _returnValue = mData.ActivateDeactivateEventMaster(EventId, IsActive, ModifiedBy);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<EventMasterInfo> GetAllActiveEventMaster()
        {
            List<EventMasterInfo> mInfo;
            EventMaster mData;
            try
            {
                mInfo = new List<EventMasterInfo>();
                mData = new EventMaster();

                mInfo = mData.GetAllActiveEventMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<EventMasterInfo> GetAllEventMaster()
        {
            List<EventMasterInfo> mInfo;
            EventMaster mData;
            try
            {
                mInfo = new List<EventMasterInfo>();
                mData = new EventMaster();

                mInfo = mData.GetAllEventMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<EventMasterInfo> GetAllEventMasterById(Int32 EventId)
        {
            List<EventMasterInfo> mInfo;
            EventMaster mData;
            try
            {
                mInfo = new List<EventMasterInfo>();
                mData = new EventMaster();

                mInfo = mData.GetAllEventMasterById(EventId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<EventMasterInfo> SearchEvent(String SearchText)
        {
            List<EventMasterInfo> mInfo;
            EventMaster mData;
            try
            {
                mInfo = new List<EventMasterInfo>();
                mData = new EventMaster();

                mInfo = mData.SearchEvent(SearchText);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }


        public Int32 InsertEventInTemplate(Int32 EventId, Int32 TemplateId, Int32 LibId, Int32 CreatedBy)
        {
            EventInTemplate mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new EventInTemplate();
                _returnValue = mData.InsertEventInTemplate(EventId,TemplateId,LibId, CreatedBy);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<EventInTemplateInfo> GetAllActiveEventInTemplate()
        {
            List<EventInTemplateInfo> mInfo;
            EventInTemplate mData;
            try
            {
                mInfo = new List<EventInTemplateInfo>();
                mData = new EventInTemplate();

                mInfo = mData.GetAllActiveEventInTemplate();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<EventInTemplateInfo> GetAllEventInTemplate()
        {
            List<EventInTemplateInfo> mInfo;
            EventInTemplate mData;
            try
            {
                mInfo = new List<EventInTemplateInfo>();
                mData = new EventInTemplate();

                mInfo = mData.GetAllEventInTemplate();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<EventInTemplateInfo> GetEventInTemplateSearch(Int32 LibId, String SearchText)
        {
            List<EventInTemplateInfo> mInfo;
            EventInTemplate mData;
            try
            {
                mInfo = new List<EventInTemplateInfo>();
                mData = new EventInTemplate();

                mInfo = mData.GetEventInTemplateSearch(LibId,SearchText);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 ActivateDeactivateEventInTemplate(Int32 EventInTemplateId, Boolean IsActive, Int32 ModifiedBy)
        {
            EventInTemplate mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new EventInTemplate();
                _returnValue = mData.ActivateDeactivateEventInTemplate(EventInTemplateId, IsActive, ModifiedBy);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        /////////////////////////////////

        public void InsertEventObjectMapping(String UsrTmDtl)
        {
            EventObjectMapping mData;
            List<EventObjectMappingInfo> mInfo;
            EventObjectMappingInfo uList;
            try
            {
                mData = new EventObjectMapping();
                mInfo = new List<EventObjectMappingInfo>();
                if (UsrTmDtl.Length > 0)
                {
                    String[] strUsrTmDtl = UsrTmDtl.Split('|');
                    for (int i = 0; i < strUsrTmDtl.Length; i++)
                    {
                        String[] strLink = strUsrTmDtl[i].Split(',');
                        uList = new EventObjectMappingInfo();
                        uList.EventId = Convert.ToInt32(strLink[0]);
                        uList.FieldId = Convert.ToInt32(strLink[1]);
                        uList.CreatedBy = Convert.ToInt32(strLink[2]);
                        mInfo.Add(uList);
                        strLink = null;
                    }
                }
                mData.InsertEventObjectMapping(mInfo);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
        }

        public List<EventObjectMappingInfo> GetAllActiveEventObjectMapping()
        {
            List<EventObjectMappingInfo> mInfo;
            EventObjectMapping mData;
            try
            {
                mInfo = new List<EventObjectMappingInfo>();
                mData = new EventObjectMapping();

                mInfo = mData.GetAllActiveEventObjectMapping();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<EventObjectMappingInfo> GetEventObjectMappingByEventId(Int32 EventId)
        {
            List<EventObjectMappingInfo> mInfo;
            EventObjectMapping mData;
            try
            {
                mInfo = new List<EventObjectMappingInfo>();
                mData = new EventObjectMapping();

                mInfo = mData.GetEventObjectMappingByEventId(EventId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<EventObjectMappingInfo> GetAllEventObjectMapping()
        {
            List<EventObjectMappingInfo> mInfo;
            EventObjectMapping mData;
            try
            {
                mInfo = new List<EventObjectMappingInfo>();
                mData = new EventObjectMapping();

                mInfo = mData.GetAllEventObjectMapping();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<EventObjectMappingInfo> GetEventObjectMappingSearch(String SearchText)
        {
            List<EventObjectMappingInfo> mInfo;
            EventObjectMapping mData;
            try
            {
                mInfo = new List<EventObjectMappingInfo>();
                mData = new EventObjectMapping();

                mInfo = mData.GetEventObjectMappingSearch(SearchText);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 ActivateDeactivateEventObjectMapping(Int32 EventObjectId, Boolean IsActive, Int32 ModifiedBy)
        {
            EventObjectMapping mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new EventObjectMapping();
                _returnValue = mData.ActivateDeactivateEventObjectMapping(EventObjectId, IsActive, ModifiedBy);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        ///////////////////////////////

        public Int32 InsertEventTrigger(Int32 EventId, Int32 Duration, Int32 CreatedBy)
        {
            EventTrigger mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new EventTrigger();
                _returnValue = mData.InsertEventTrigger(EventId,Duration, CreatedBy);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 UpdateEventTrigger(Int32 EventTriggerId, Int32 EventId, Int32 Duration, Int32 ModifiedBy)
        {
            EventTrigger mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new EventTrigger();
                _returnValue = mData.UpdateEventTrigger(EventTriggerId, EventId, Duration, ModifiedBy);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 ActivateDeactivateEventTrigger(Int32 EventTriggerId, Boolean IsActive, Int32 ModifiedBy)
        {
            EventTrigger mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new EventTrigger();
                _returnValue = mData.ActivateDeactivateEventTrigger(EventTriggerId, IsActive, ModifiedBy);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<EventTriggerInfo> GetAllActiveEventTrigger()
        {
            List<EventTriggerInfo> mInfo;
            EventTrigger mData;
            try
            {
                mInfo = new List<EventTriggerInfo>();
                mData = new EventTrigger();

                mInfo = mData.GetAllActiveEventTrigger();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<EventTriggerInfo> GetAllEventTrigger()
        {
            List<EventTriggerInfo> mInfo;
            EventTrigger mData;
            try
            {
                mInfo = new List<EventTriggerInfo>();
                mData = new EventTrigger();

                mInfo = mData.GetAllEventTrigger();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<EventTriggerInfo> GetAllEventTriggerById(Int32 EventTriggerId)
        {
            List<EventTriggerInfo> mInfo;
            EventTrigger mData;
            try
            {
                mInfo = new List<EventTriggerInfo>();
                mData = new EventTrigger();

                mInfo = mData.GetAllEventTriggerById(EventTriggerId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<EventTriggerInfo> SearchEventTrigger(String SearchText)
        {
            List<EventTriggerInfo> mInfo;
            EventTrigger mData;
            try
            {
                mInfo = new List<EventTriggerInfo>();
                mData = new EventTrigger();

                mInfo = mData.SearchEventTrigger(SearchText);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<TemplateFieldMappingInfo> GetAllTemplateFieldMapping()
        {
            List<TemplateFieldMappingInfo> mInfo;
            TemplateFieldMapping mData;
            try
            {
                mInfo = new List<TemplateFieldMappingInfo>();
                mData = new TemplateFieldMapping();

                mInfo = mData.GetAllTemplateFieldMapping();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<ExpiryMailInfo> GetOnExpiryDocumentList(String CurrentDate)
        {
            List<ExpiryMailInfo> mInfo;
            ExpiryMail mData;
            try
            {
                mInfo = new List<ExpiryMailInfo>();
                mData = new ExpiryMail();

                mInfo = mData.GetOnExpiryDocumentList(CurrentDate);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<ExpiryMailInfo> GetOn30DaysExpiryDocumentList(String CurrentDate)
        {
            List<ExpiryMailInfo> mInfo;
            ExpiryMail mData;
            try
            {
                mInfo = new List<ExpiryMailInfo>();
                mData = new ExpiryMail();

                mInfo = mData.GetOn30DaysExpiryDocumentList(CurrentDate);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<DocumentDetailInfo> GetUpdatedDocumentDetails(Int32 DocId)
        {
            List<DocumentDetailInfo> mInfo;
            DocomentMaster mData;
            try
            {
                mInfo = new List<DocumentDetailInfo>();
                mData = new DocomentMaster();

                mInfo = mData.GetUpdatedDocumentDetails(DocId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 UpdateDocumentInfoDetailClone(Int32 DocId)
        {
            DocomentMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new DocomentMaster();
                _returnValue = mData.UpdateDocumentInfoDetailClone(DocId);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        #region BrandCategoryMapping

        public List<BrandCategoryMappingInfo> GetBrandCategoryMapping(Int32 BrandId, Int32 CategoryId)
        {
            List<BrandCategoryMappingInfo> mInfo;
            BrandCategoryMapping mData;
            try
            {
                mInfo = new List<BrandCategoryMappingInfo>();
                mData = new BrandCategoryMapping();

                mInfo = mData.GetBrandCategoryMapping(BrandId, CategoryId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<BrandCategoryMappingInfo> GetUserNotInBrandCategory(Int32 BrandId, Int32 CategoryId)
        {
            List<BrandCategoryMappingInfo> mInfo;
            BrandCategoryMapping mData;
            try
            {
                mInfo = new List<BrandCategoryMappingInfo>();
                mData = new BrandCategoryMapping();

                mInfo = mData.GetUserNotInBrandCategory(BrandId, CategoryId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public void InsertBrandCategoryMapping(String brndCatgDtl)
        {
            BrandCategoryMapping mData;
            List<BrandCategoryMappingInfo> mInfo;
            BrandCategoryMappingInfo uList;
            try
            {
                mData = new BrandCategoryMapping();
                mInfo = new List<BrandCategoryMappingInfo>();
                if (brndCatgDtl.Length > 0)
                {
                    String[] strbrndCatgDtl = brndCatgDtl.Split('|');
                    for (int i = 0; i < strbrndCatgDtl.Length; i++)
                    {
                        String[] strLink = strbrndCatgDtl[i].Split(',');
                        uList = new BrandCategoryMappingInfo();
                        uList.BrandId = Convert.ToInt32(strLink[0]);
                        uList.CategoryId = Convert.ToInt32(strLink[1]);
                        uList.UserId = Convert.ToInt32(strLink[2]);
                        uList.EmailId = Convert.ToString(strLink[3]);
                        uList.Permission = Convert.ToInt16(strLink[4]);
                        uList.IsAppAdmin = Convert.ToBoolean(strLink[5]);
                        uList.CreatedBy = Convert.ToInt32(strLink[6]);
                        mInfo.Add(uList);
                        strLink = null;
                    }
                }
                mData.InsertBrandCategoryMapping(mInfo);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
        }

        public Int32 ActivateDeactivateBrandCategoryMapping(BrandCategoryMappingInfo mObj)
        {
            BrandCategoryMapping mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new BrandCategoryMapping();
                _returnValue = mData.ActivateDeactivateBrandCategoryMapping(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 UpdateBrandCategoryMapping(BrandCategoryMappingInfo mObj)
        {
            BrandCategoryMapping mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new BrandCategoryMapping();
                _returnValue = mData.UpdateBrandCategoryMapping(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<BrandCategoryMappingInfo> GetAllBrandCategoryMapping()
        {
            List<BrandCategoryMappingInfo> mInfo;
            BrandCategoryMapping mData;
            try
            {
                mInfo = new List<BrandCategoryMappingInfo>();
                mData = new BrandCategoryMapping();

                mInfo = mData.GetAllBrandCategoryMapping();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<BrandCategoryMappingInfo> BrandCategoryMappingInfoSearch(String SearchString)
        {
            List<BrandCategoryMappingInfo> mInfo;
            BrandCategoryMapping mData;
            try
            {
                mInfo = new List<BrandCategoryMappingInfo>();
                mData = new BrandCategoryMapping();

                mInfo = mData.BrandCategoryMappingInfoSearch(SearchString);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }


        public List<BrandCategoryMappingInfo> GetUserEmailByDocId(Int32 DocId)
        {
            List<BrandCategoryMappingInfo> mInfo;
            BrandCategoryMapping mData;
            try
            {
                mInfo = new List<BrandCategoryMappingInfo>();
                mData = new BrandCategoryMapping();

                mInfo = mData.GetUserEmailByDocId(DocId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        #endregion

        public Int32 InsertEmailLog(EmailLogInfo mObj)
        {
            EmailLog mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new EmailLog();
                _returnValue = mData.InsertEmailLog(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<EmailLogInfo> EmailLogSearch(String EmailEvent, String FromDate, String ToDate)
        {
            List<EmailLogInfo> mInfo;
            EmailLog mData;
            try
            {
                mInfo = new List<EmailLogInfo>();
                mData = new EmailLog();

                mInfo = mData.EmailLogSearch(EmailEvent, FromDate, ToDate);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public void InsertLookupMasterOther(String details)
        {
            LookupMaster mData;
            List<LookupMasterInfo> mInfo;
            LookupMasterInfo uList;
            try
            {
                mData = new LookupMaster();
                mInfo = new List<LookupMasterInfo>();
                if (details.Length > 0)
                {
                    String[] strDetails = details.Split('|');
                    for (int i = 0; i < strDetails.Length; i++)
                    {
                        String[] strLink = strDetails[i].Split(',');
                        uList = new LookupMasterInfo();
                        uList.FieldId = Convert.ToInt32(strLink[0]);
                        uList.FieldValue = strLink[1];
                        uList.LibId = Convert.ToInt32(strLink[2]);
                        uList.CreatedBy = Convert.ToInt32(strLink[3]);
                        mInfo.Add(uList);
                        strLink = null;
                    }
                }
                mData.InsertLookupMasterOther(mInfo);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
        }

        public List<LookupMasterInfo> GetAllOthersValue()
        {
            List<LookupMasterInfo> mInfo;
            LookupMaster mData;
            try
            {
                mInfo = new List<LookupMasterInfo>();
                mData = new LookupMaster();

                mInfo = mData.GetAllOthersValue();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<ActivityLogInfo> GetActivityInfo(Int32 UserId, DateTime FromDate, DateTime ToDate)
        {
            List<ActivityLogInfo> mInfo;
            ActivityLog mData;
            try
            {
                mInfo = new List<ActivityLogInfo>();
                mData = new ActivityLog();

                mInfo = mData.GetActivityInfo(UserId, FromDate, ToDate);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public String GetActivityDetail(Int64 ReferenceId, Boolean IsOriginal, String TableName)
        {
            ActivityLog mData;
            DataTable dt;
            StringBuilder html = new StringBuilder();
            //int colCount = 0;
            try
            {
                if (ReferenceId > 0)
                {
                    mData = new ActivityLog();
                    dt = mData.GetActivityDetail(ReferenceId, IsOriginal, TableName);
                    if (dt.Rows.Count > 0)
                    {
                        html.Append("<div><fieldset><legend>Activity Details</legend><table width='100%'>");

                        for (int i = 0; i < dt.Columns.Count; i++)
                        {
                            html.AppendFormat("<tr><td>{0}</td><td><label>{1}</label></td></tr>",dt.Columns[i].ColumnName,dt.Rows[0][i].ToString());
                        }
                        html.Append("</table></fieldset></div>");
                    }
                }
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return html.ToString();
        }

        public List<ExpiryReportInfo> ExpiryReport(String FromDate, String ToDate)
        {
            List<ExpiryReportInfo> mInfo;
            EmailLog mData;
            try
            {
                mInfo = new List<ExpiryReportInfo>();
                mData = new EmailLog();

                mInfo = mData.ExpiryReport(FromDate, ToDate);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<EmailLogInfo> EmailLogById(Int32 EmailLogId)
        {
            List<EmailLogInfo> mInfo;
            EmailLog mData;
            try
            {
                mInfo = new List<EmailLogInfo>();
                mData = new EmailLog();

                mInfo = mData.EmailLogById(EmailLogId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<DocLogDetailsInfo> DocLogDetailsSearch(String FromDate, String ToDate)
        {
            List<DocLogDetailsInfo> mInfo;
            DocomentMaster mData;
            try
            {
                mInfo = new List<DocLogDetailsInfo>();
                mData = new DocomentMaster();

                mInfo = mData.DocLogDetailsSearch(FromDate, ToDate);
                return mInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }


        /// <summary>
        /// New Added
        /// </summary>
        /// <returns></returns>
        public List<UserBrandCategoryMappingInfo> GetUserForBrandCategoryMapping()
        {
            List<UserBrandCategoryMappingInfo> mInfo;
            UserBrandCategoryMapping mData;
            try
            {
                mInfo = new List<UserBrandCategoryMappingInfo>();
                mData = new UserBrandCategoryMapping();

                mInfo = mData.GetUserForBrandCategoryMapping();
                return mInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<UserBrandCategoryMappingInfo> GetUserBrandCategoryMappingByUserId(Int32 UserId)
        {
            List<UserBrandCategoryMappingInfo> mInfo;
            UserBrandCategoryMapping mData;
            try
            {
                mInfo = new List<UserBrandCategoryMappingInfo>();
                mData = new UserBrandCategoryMapping();

                mInfo = mData.GetUserBrandCategoryMappingByUserId(UserId);
                return mInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 ActivateDeactivateUserBrandCategoryMapping(UserBrandCategoryMappingInfo mObj)
        {
            UserBrandCategoryMapping mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new UserBrandCategoryMapping();
                _returnValue = mData.ActivateDeactivateUserBrandCategoryMapping(mObj);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public void InsertUserBrandCategoryMapping(String brndCatgDtl)
        {
            UserBrandCategoryMapping mData;
            List<UserBrandCategoryMappingInfo> mInfo;
            UserBrandCategoryMappingInfo uList;
            try
            {
                mData = new UserBrandCategoryMapping();
                mInfo = new List<UserBrandCategoryMappingInfo>();
                if (brndCatgDtl.Length > 0)
                {
                    String[] strbrndCatgDtl = brndCatgDtl.Split('|');
                    for (int i = 0; i < strbrndCatgDtl.Length; i++)
                    {
                        String[] strLink = strbrndCatgDtl[i].Split(',');
                        uList = new UserBrandCategoryMappingInfo();
                        uList.BrandId = Convert.ToInt32(strLink[0]);
                        uList.CategoryId = Convert.ToInt32(strLink[1]);
                        uList.UserId = Convert.ToInt32(strLink[2]);
                        uList.CreatedBy = Convert.ToInt32(strLink[3]);
                        mInfo.Add(uList);
                        strLink = null;
                    }
                }
                mData.InsertUserBrandCategoryMapping(mInfo);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
        }

        public List<UserBrandCategoryMappingInfo> GetAllUserBrandCategoryMapping()
        {
            List<UserBrandCategoryMappingInfo> mInfo;
            UserBrandCategoryMapping mData;
            try
            {
                mInfo = new List<UserBrandCategoryMappingInfo>();
                mData = new UserBrandCategoryMapping();

                mInfo = mData.GetAllUserBrandCategoryMapping();
                return mInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<UserBrandCategoryMappingInfo> UserBrandCategoryMappingSearch(String SearchString)
        {
            List<UserBrandCategoryMappingInfo> mInfo;
            UserBrandCategoryMapping mData;
            try
            {
                mInfo = new List<UserBrandCategoryMappingInfo>();
                mData = new UserBrandCategoryMapping();

                mInfo = mData.UserBrandCategoryMappingSearch(SearchString);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<LookupMasterInfo> GetUserBrandCategoryByFieldId(Int32 FieldId, Int32 UserId)
        {
            List<LookupMasterInfo> mInfo;
            LookupMaster mData;
            try
            {
                mInfo = new List<LookupMasterInfo>();
                mData = new LookupMaster();
                mInfo = mData.GetUserBrandCategoryByFieldId(FieldId, UserId);
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        #region "Content Type Master"

        public List<ContentTypeMasterInfo> GetAllContentType()
        {
            List<ContentTypeMasterInfo> mInfo;
            ContentTypeMaster mData;
            try
            {
                mInfo = new List<ContentTypeMasterInfo>();
                mData = new ContentTypeMaster();

                mInfo = mData.GetAllContentType();
                return mInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mInfo = null;
                mData = null;
            }

        }

        public List<ContentTypeMasterInfo> GetContentTypeSearch(String ContentType)
        {
            List<ContentTypeMasterInfo> mInfo;
            ContentTypeMaster mData;
            try
            {
                mInfo = new List<ContentTypeMasterInfo>();
                mData = new ContentTypeMaster();

                mInfo = mData.SearchContent(ContentType);
                return mInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 InsertContentType(ContentTypeMasterInfo mObj)
        {
            ContentTypeMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new ContentTypeMaster();
                _returnValue = mData.InsertContentType(mObj); 
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 UpdateContentType(ContentTypeMasterInfo mObj)
        {
            ContentTypeMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new ContentTypeMaster();
                _returnValue = mData.UpdateContentType(mObj);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<ContentTypeMasterInfo> GetContentTypeMasterById(Int32 ContentTypeId)
        {
            List<ContentTypeMasterInfo> mInfo;
            ContentTypeMaster mData;
            try
            {
                mInfo = new List<ContentTypeMasterInfo>();
                mData = new ContentTypeMaster();

                mInfo = mData.GetContentTypeById(ContentTypeId);
                return mInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 ActivateDeactivateContentType(ContentTypeMasterInfo mObj)
        {
            ContentTypeMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new ContentTypeMaster();
                _returnValue = mData.ActivateDeactivateContentType(mObj);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        #endregion

        #region GroupMaster
        public List<GroupMasterInfo> GetAllGroupMaster()
        {
            List<GroupMasterInfo> mInfo;
            GroupMaster mData;
            try
            {
                mInfo = new List<GroupMasterInfo>();
                mData = new GroupMaster();

                mInfo = mData.GetAllGroupMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<GroupMasterInfo> GetGroupMasterById(Int32 GroupId)
        {
            List<GroupMasterInfo> mInfo;
            GroupMaster mData;
            try
            {
                mInfo = new List<GroupMasterInfo>();
                mData = new GroupMaster();

                mInfo = mData.GetGroupMasterById(GroupId);
                return mInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 InsertGroupMaster(GroupMasterInfo mObj)
        {
            GroupMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new GroupMaster();
                _returnValue = mData.InsertGroupMaster(mObj);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 UpdateGroupMaster(GroupMasterInfo mObj)
        {
            GroupMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new GroupMaster();
                _returnValue = mData.UpdateGroupMaster(mObj);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 ActivateDeactivateGroupMaster(GroupMasterInfo mObj)
        {
            GroupMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new GroupMaster();
                _returnValue = mData.ActivateDeactivateGroupMaster(mObj);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<GroupMasterInfo> GetAllActiveGroupMaster()
        {
            List<GroupMasterInfo> mInfo;
            GroupMaster mData;
            try
            {
                mInfo = new List<GroupMasterInfo>();
                mData = new GroupMaster();

                mInfo = mData.GetAllActiveGroupMaster();
                return mInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<GroupMasterInfo> SearchGroupMaster(String SearchText)
        {
            List<GroupMasterInfo> mInfo;
            GroupMaster mData;
            try
            {
                mInfo = new List<GroupMasterInfo>();
                mData = new GroupMaster();

                mInfo = mData.SearchGroupMaster(SearchText);
                return mInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        #endregion

        #region UserInGroup
        public List<UserInGroupInfo> GetGroupMasterUserListByGroupId(Int32 GroupId)
        {
            List<UserInGroupInfo> mInfo;
            UserInGroup mData;
            try
            {
                mInfo = new List<UserInGroupInfo>();
                mData = new UserInGroup();

                mInfo = mData.GetGroupMasterUserListByGroupId(GroupId);
                return mInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<UserInGroupInfo> GetUserListNotInParticularGroup(Int32 GroupId)
        {
            List<UserInGroupInfo> mInfo;
            UserInGroup mData;
            try
            {
                mInfo = new List<UserInGroupInfo>();
                mData = new UserInGroup();

                mInfo = mData.GetUserListNotInParticularGroup(GroupId);
                return mInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public void InsertUserInGroup(String UsrTmDtl)
        {
            UserInGroup mData;
            List<UserInGroupInfo> mInfo;
            UserInGroupInfo uList;
            try
            {
                mData = new UserInGroup();
                mInfo = new List<UserInGroupInfo>();
                if (UsrTmDtl.Length > 0)
                {
                    String[] strUsrTmDtl = UsrTmDtl.Split('|');
                    for (int i = 0; i < strUsrTmDtl.Length; i++)
                    {
                        String[] strLink = strUsrTmDtl[i].Split(',');
                        uList = new UserInGroupInfo();
                        uList.UserId = Convert.ToInt32(strLink[0]);
                        uList.GroupId = Convert.ToInt32(strLink[1]);
                        uList.CreatedBy = Convert.ToInt32(strLink[2]);
                        mInfo.Add(uList);
                        strLink = null;
                    }
                }
                mData.InsertUserInGroup(mInfo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mData = null;
            }
        }

        public Int32 ActivateDeactivateUserInGroupMaster(UserInGroupInfo mObj)
        {
            UserInGroup mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new UserInGroup();
                _returnValue = mData.ActivateDeactivateUserInGroupMaster(mObj);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<UserInGroupInfo> GetAllActiveGroupMasterUserList()
        {
            List<UserInGroupInfo> mInfo;
            UserInGroup mData;
            try
            {
                mInfo = new List<UserInGroupInfo>();
                mData = new UserInGroup();

                mInfo = mData.GetAllActiveGroupMasterUserList();
                return mInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public List<UserInGroupInfo> GetAllUserInGroupSearch(String SearchText)
        {
            List<UserInGroupInfo> mInfo;
            UserInGroup mData;
            try
            {
                mInfo = new List<UserInGroupInfo>();
                mData = new UserInGroup();

                mInfo = mData.GetAllUserInGroupSearch(SearchText);
                return mInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }
        #endregion
        public List<DocumentInGroupInfo> DocumentInGroupByDocId(Int32 DocId)
        {
            List<DocumentInGroupInfo> mInfo;
            FileMaster mData;
            try
            {
                mInfo = new List<DocumentInGroupInfo>();
                mData = new FileMaster();

                mInfo = mData.DocumentInGroupByDocId(DocId);
                return mInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 DeactivateDocumentInGroup(Int32 DocId)
        {
            FileMaster mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new FileMaster();
                _returnValue = mData.DeactivateDocumentInGroup(DocId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public Int32 DocumentInGroupUpdate(String strDocInGroups)
        {
            FileMaster mData;
            Int32 returnVal;
            List<DocumentInGroupInfo> mDocInGroup;
            DocumentInGroupInfo objDocInGroup;
            try
            {
                mData = new FileMaster();
                mDocInGroup = new List<DocumentInGroupInfo>();
                if (strDocInGroups.Length > 0)
                {
                    String[] strDocInGroup = strDocInGroups.Split('|');
                    for (int i = 0; i < strDocInGroup.Length; i++)
                    {
                        String[] strGroup = strDocInGroup[i].Split(',');
                        objDocInGroup = new DocumentInGroupInfo();
                        objDocInGroup.DocId = Convert.ToInt32(strGroup[0]);
                        objDocInGroup.GroupId = Convert.ToInt32(strGroup[1]);
                        objDocInGroup.CreatedBy = Convert.ToInt32(strGroup[2]);
                        mDocInGroup.Add(objDocInGroup);
                        objDocInGroup = null;
                    }
                }
                returnVal = mData.DocumentInGroupUpdate(mDocInGroup);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mData = null;
            }
            return returnVal;
        }

        public void DocGroupLog(Int32 DocId, String ChangeField, String FieldName, String ValueBefore, String ValueAfter, Int32 ChangedBy)
        {
            GroupMaster mData;
            try
            {
                mData = new GroupMaster();
                mData.DocGroupLog(DocId, ChangeField, FieldName, ValueBefore, ValueAfter, ChangedBy);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mData = null;
            }
        }

        public Int32 DeactivateLibraryAttributeSet(Int32 ContentTypeId)
        {
            LibraryAttributeSet mData;
            Int32 _returnValue = 0;
            try
            {
                mData = new LibraryAttributeSet();
                _returnValue = mData.DeactivateLibraryAttributeSet(ContentTypeId);
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }

        public List<ConfigurationInfo> GetAllConfiguration()
        {
            List<ConfigurationInfo> mInfo;
            Configuration mData;
            try
            {
                mInfo = new List<ConfigurationInfo>();
                mData = new Configuration();

                mInfo = mData.GetAllConfiguration();
                return mInfo;
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                mInfo = null;
                mData = null;
            }
        }

        public Int32 ActivateDeactivateConfiguration(ConfigurationInfo mData)
        {
            Configuration obj;
            Int32 _returnValue = 0;
            try
            {
                obj = new Configuration();
                _returnValue = obj.ActivateDeactivateConfiguration(mData);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mData = null;
            }
            return _returnValue;
        }
    }
}
