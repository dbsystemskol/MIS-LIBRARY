﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAM.Apps.Utility
{
    public class FileVersion
    {
        protected static ILog log = LogManager.GetLogger(typeof(FileVersion));

        public List<FileVersionInfo> GetFileVersionByDocId(Int32 DocId)
        {
            List<FileVersionInfo> mList = new List<FileVersionInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GetFileVersionByDocId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new FileVersionInfo
                        {
                            FileInfoId = mCmd.GetFieldValue<Int32>("FileInfoId"),
                            VersionNo = mCmd.GetFieldValue<Int32>("VersionNo"),
                            VersionName = mCmd.GetFieldValue<String>("VersionName"),
                            DefaultFlag = mCmd.GetFieldValue<Boolean>("DefaultFlag"),
                            FileSize = mCmd.GetFieldValue<Int32>("FileSize"),
                            CreatedOn = mCmd.GetFieldValue<DateTime>("CreatedOn"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 UpdateFileVersion(Int32 DocId, Int32 FileInfoId, Int32 ModifiedBy)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "FileVersionUpdate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
            mCmd.AddParameter("@FileInfoId", SqlDbType.Int, DataParameterDirection.Input, 4, FileInfoId);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, ModifiedBy);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }
    }
}
