﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAM.Apps.Utility
{
    public class UserMasterData
    {

        protected static ILog log = LogManager.GetLogger(typeof(UserMasterData));

        public Int32 InsertUserMaster(UserMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "UserMasterInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@UserName", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.UserName);
            mCmd.AddParameter("@FirstName", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.FirstName);
            mCmd.AddParameter("@LastName", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.LastName);
            mCmd.AddParameter("@EmailId", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.EmailId);
            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.CreatedBy);
            mCmd.AddParameter("@LocationId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.LocationId);
            mCmd.AddParameter("@DepartmentId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.DepartmentId);
            mCmd.AddParameter("@DesignationId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.DesignationId);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 UpdateUserMaster(UserMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "UserMasterUpdate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.UserId);
            mCmd.AddParameter("@FirstName", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.FirstName);
            mCmd.AddParameter("@LastName", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.LastName);
            mCmd.AddParameter("@EmailId", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.EmailId);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.CreatedBy);
            mCmd.AddParameter("@LocationId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.LocationId);
            mCmd.AddParameter("@DepartmentId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.DepartmentId);
            mCmd.AddParameter("@DesignationId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.DesignationId);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<UserMasterInfo> GetAllUserMaster(String LoginUserTeam)
        {
            List<UserMasterInfo> mList = new List<UserMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "UserMasterSelectAll";
                mCmd.AddParameter("@LoginUserTeam", SqlDbType.VarChar, DataParameterDirection.Input, 100, LoginUserTeam);
                mCmd.CommandType = DataCommandType.StoredProcedure;

                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new UserMasterInfo
                        {
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            FirstName = mCmd.GetFieldValue<String>("FirstName"),
                            LastName = mCmd.GetFieldValue<String>("LastName"),
                            EmailId = mCmd.GetFieldValue<String>("EmailId"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            Location = mCmd.GetFieldValue<String>("Location"),
                            Department = mCmd.GetFieldValue<String>("Department"),
                            Designation = mCmd.GetFieldValue<String>("Designation"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<UserMasterInfo> GetAllActiveUserMaster()
        {
            List<UserMasterInfo> mList = new List<UserMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "UserMasterSelectActiveAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;

                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new UserMasterInfo
                        {
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<UserMasterInfo> GetUserMasterById(Int32 UserId)
        {
            List<UserMasterInfo> mList = new List<UserMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "UserMasterSelectRow";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);

                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new UserMasterInfo
                        {
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            FirstName = mCmd.GetFieldValue<String>("FirstName"),
                            LastName = mCmd.GetFieldValue<String>("LastName"),
                            EmailId = mCmd.GetFieldValue<String>("EmailId"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            LocationId = mCmd.GetFieldValue<Int32>("LocationId"),
                            DepartmentId = mCmd.GetFieldValue<Int32>("DepartmentId"),
                            DesignationId = mCmd.GetFieldValue<Int32>("DesignationId"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<UserMasterInfo> GetUserMasterByUserName(String UserName)
        {
            List<UserMasterInfo> mList = new List<UserMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "UserMasterByUserName";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@UserName", SqlDbType.VarChar, DataParameterDirection.Input, 50, UserName);

                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new UserMasterInfo
                        {
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            FirstName = mCmd.GetFieldValue<String>("FirstName"),
                            LastName = mCmd.GetFieldValue<String>("LastName"),
                            EmailId = mCmd.GetFieldValue<String>("EmailId"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            Location = mCmd.GetFieldValue<String>("Location"),
                            Department = mCmd.GetFieldValue<String>("Department"),
                            Designation = mCmd.GetFieldValue<String>("Designation"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 ActivateDeactivateUserMaster(UserMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "UserMasterActivateDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.UserId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<UserMasterInfo> SearchUser(String SearchText, String LoginUserTeam)
        {
            List<UserMasterInfo> mList = new List<UserMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "UserMasterSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@UserName", SqlDbType.VarChar, DataParameterDirection.Input, 100, SearchText);
                mCmd.AddParameter("@LoginUserTeam", SqlDbType.VarChar, DataParameterDirection.Input, 100, LoginUserTeam);
                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new UserMasterInfo
                        {
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            FirstName = mCmd.GetFieldValue<String>("FirstName"),
                            LastName = mCmd.GetFieldValue<String>("LastName"),
                            EmailId = mCmd.GetFieldValue<String>("EmailId"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            Location = mCmd.GetFieldValue<String>("Location"),
                            Department = mCmd.GetFieldValue<String>("Department"),
                            Designation = mCmd.GetFieldValue<String>("Designation"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 InsertUserLoginHistory(Int32 UserId)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "UserLoginHistoryInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 100, UserId);
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 UpdateUserLogoutHistory(Int32 LoginHistoryId)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "UserLoginHistoryUpdate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@LoginHistoryId", SqlDbType.Int, DataParameterDirection.Input, 4, LoginHistoryId);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }
    }
}
