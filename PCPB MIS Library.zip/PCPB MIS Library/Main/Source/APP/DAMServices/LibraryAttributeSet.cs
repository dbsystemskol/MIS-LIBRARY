﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;


namespace DAM.Apps.Utility
{
    public class LibraryAttributeSet
    {
        protected static ILog log = LogManager.GetLogger(typeof(LibraryAttributeSet));

        public List<LibraryAttributeSetInfo> GetLibraryAttributeSetByContentTypeId(Int32 ContentTypeId)
        {
            List<LibraryAttributeSetInfo> mList = new List<LibraryAttributeSetInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "LibraryAttributeSetByContentTypeId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, ContentTypeId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LibraryAttributeSetInfo
                        {
                            FieldId = mCmd.GetFieldValue<Int32>("FieldId"),
                            AttributeType = mCmd.GetFieldValue<String>("AttributeType"),
                            IsMandatory = mCmd.GetFieldValue<Boolean>("IsMandatory"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            FieldName = mCmd.GetFieldValue<String>("FieldName"),
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                            FieldType = mCmd.GetFieldValue<String>("FieldType"),
                            DefaultValue = mCmd.GetFieldValue<String>("DefaultValue"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<LibraryAttributeSetInfo> GetCommonLibraryAttributeSet(Int32 LibId)
        {
            List<LibraryAttributeSetInfo> mList = new List<LibraryAttributeSetInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "LibraryAttributeSetCommon";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LibraryAttributeSetInfo
                        {
                            FieldId = mCmd.GetFieldValue<Int32>("FieldId"),
                            AttributeType = mCmd.GetFieldValue<String>("AttributeType"),
                            IsMandatory = mCmd.GetFieldValue<Boolean>("IsMandatory"),                            
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                            FieldType = mCmd.GetFieldValue<String>("FieldType"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<LibraryAttributeSetInfo> GetLibraryAttributeSetByLibId(Int32 LibId)
        {
            List<LibraryAttributeSetInfo> mList = new List<LibraryAttributeSetInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "LibraryAttributeSetByLibId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LibraryAttributeSetInfo
                        {
                            FieldId = mCmd.GetFieldValue<Int32>("FieldId"),
                            AttributeType = mCmd.GetFieldValue<String>("AttributeType"),
                            //IsMandatory = mCmd.GetFieldValue<Boolean>("IsMandatory"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            FieldName = mCmd.GetFieldValue<String>("FieldName"),
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                            FieldType = mCmd.GetFieldValue<String>("FieldType"),
                            DefaultValue = mCmd.GetFieldValue<String>("DefaultValue"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 DeactivateLibraryAttributeSet(Int32 ContentTypeId)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "LibraryAttributeSetDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, ContentTypeId);
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }
    }
}
