﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAM.Apps.Utility
{
    public class DesignationMaster
    {
        protected static ILog log = LogManager.GetLogger(typeof(DesignationMaster));

        public List<DesignationMasterInfo> GetAllDesignationMaster()
        {
            List<DesignationMasterInfo> mList = new List<DesignationMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "DesignationMasterSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new DesignationMasterInfo
                        {
                            DesignationId = mCmd.GetFieldValue<Int32>("DesignationId"),
                            Designation = mCmd.GetFieldValue<String>("Designation"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<DesignationMasterInfo> GetDesignationMasterById(Int32 DesignationId)
        {
            List<DesignationMasterInfo> mList = new List<DesignationMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "DesignationMasterSelectRow";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@DesignationId", SqlDbType.Int, DataParameterDirection.Input, 4, DesignationId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new DesignationMasterInfo
                        {
                            DesignationId = mCmd.GetFieldValue<Int32>("DesignationId"),
                            Designation = mCmd.GetFieldValue<String>("Designation"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 InsertDesignationMaster(DesignationMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "DesignationMasterInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@Designation", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.Designation);
            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.CreatedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 UpdateDesignationMaster(DesignationMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "DesignationMasterUpdate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@DesignationId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.DesignationId);
            mCmd.AddParameter("@Designation", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.Designation);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.CreatedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<DesignationMasterInfo> GetAllActiveDesignationMaster()
        {
            List<DesignationMasterInfo> mList = new List<DesignationMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "DesignationMasterSelectAllActiveRows";
                mCmd.CommandType = DataCommandType.StoredProcedure;

                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new DesignationMasterInfo
                        {
                            DesignationId = mCmd.GetFieldValue<Int32>("DesignationId"),
                            Designation = mCmd.GetFieldValue<String>("Designation"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 ActivateDeactivateDesignationMaster(DesignationMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "DesignationMasterActivateDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@DesignationId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.DesignationId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<DesignationMasterInfo> SearchDesignation(String SearchText)
        {
            List<DesignationMasterInfo> mList = new List<DesignationMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "DesignationMasterSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@Designation", SqlDbType.VarChar, DataParameterDirection.Input, 100, SearchText);
                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new DesignationMasterInfo
                        {
                            DesignationId = mCmd.GetFieldValue<Int32>("DesignationId"),
                            Designation = mCmd.GetFieldValue<String>("Designation"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
