﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;
using System.Data.SqlClient;

namespace DAM.Apps.Utility
{
    public class FavouriteDocument
    {
        protected static ILog log = LogManager.GetLogger(typeof(FavouriteDocument));

        public Int32 AddRemoveFavourite(Int32 DocId, Boolean IsFavourite, Int32 CreatedBy)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "FavouriteDocumentInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
            mCmd.AddParameter("@IsFavourite", SqlDbType.Bit, DataParameterDirection.Input, 1, IsFavourite);
            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, CreatedBy);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<FavouriteDocumentInfo> GetFavouriteDocumentByDocId(Int32 DocId, Int32 CreatedBy)
        {
            List<FavouriteDocumentInfo> mList = new List<FavouriteDocumentInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "FavouriteDocumentSelectByDocId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
                mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, CreatedBy);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new FavouriteDocumentInfo
                        {
                            Label = mCmd.GetFieldValue<String>("Label"),
                            IsFavourite = mCmd.GetFieldValue<Boolean>("IsFavourite"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<LabelMasterInfo> GetLabelByUserId(Int32 UserId)
        {
            List<LabelMasterInfo> mList = new List<LabelMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "LabelMasterByUserId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LabelMasterInfo
                        {
                            LabelMasterId = mCmd.GetFieldValue<Int32>("LabelMasterId"),
                            Label = mCmd.GetFieldValue<String>("Label"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 InsertLabelMaster(String Label, Int32 UserId)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            try
            {
                mCmd = null;
                mCmd = new DataCommand();
                mCmd.CommandText = "LabelMasterInsert";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                mCmd.AddParameter("@Label", SqlDbType.VarChar, DataParameterDirection.Input, 100, Label);
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public DataTable GetFavouriteDocumentByUserId(Int32 LibId, Int32 UserId)
        {
            SqlDataReader mList;
            DataTable dt = new DataTable();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "FavouriteDocumentByUserId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
                // execute
                try
                {
                    mList = mCmd.ExecuteReaderWithSqlReader();
                    dt.Load(mList);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return dt;
        }

        public Int32 UpdateFavouriteDocument(List<FavouriteDocumentInfo> mFav)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            try
            {
                foreach (FavouriteDocumentInfo item in mFav)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandText = "FavouriteDocumentUpdate";
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, item.DocId);
                    mCmd.AddParameter("@Label", SqlDbType.VarChar, DataParameterDirection.Input, 100, item.Label);
                    mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, item.ModifiedBy);
                    mCmd.ExecuteNonQuery();
                    _ReturnValue = mCmd.GetParameterValue<Int32>("@ReturnValue");
                    _ReturnValue = _ReturnValue + 1;
                    mCmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }
    }
}
