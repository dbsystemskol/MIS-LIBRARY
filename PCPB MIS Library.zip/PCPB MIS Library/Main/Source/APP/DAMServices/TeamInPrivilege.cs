﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAM.Apps.Utility
{
    public class TeamInPrivilege
    {
        protected static ILog log = LogManager.GetLogger(typeof(TeamInPrivilege));

        public List<TeamInPrivilegeInfo> GetAllTeamInPrivilege(Int32 ContentTypeId)
        {
            List<TeamInPrivilegeInfo> mList = new List<TeamInPrivilegeInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TeamInPrivilegeSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, ContentTypeId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new TeamInPrivilegeInfo
                        {
                            //TeamInPrivilegeId = mCmd.GetFieldValue<Int32>("TeamInPrivilegeId"),
                            TeamId = mCmd.GetFieldValue<Int32>("TeamId"),
                            PrivilegeId = mCmd.GetFieldValue<Int32>("PrivilegeId"),
                            TeamName = mCmd.GetFieldValue<String>("TeamName"),
                            Permission = mCmd.GetFieldValue<Int32>("Permission"),
                            IsBrandCategoryMapped = mCmd.GetFieldValue<Boolean>("IsBrandCategoryMapped"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<TeamInPrivilegeInfo> GetAllTeamMasterRowsNotInTeamInPrivilege()
        {
            List<TeamInPrivilegeInfo> mList = new List<TeamInPrivilegeInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TeamInPrivilegeTeamMasterRows";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new TeamInPrivilegeInfo
                        {
                            TeamId = mCmd.GetFieldValue<Int32>("TeamId"),
                            TeamName = mCmd.GetFieldValue<String>("TeamName"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<TeamInPrivilegeInfo> GetAllPrivilegeMasterRowsNotInTeamInPrivilege(Int32 ContentTypeId, Int32 TeamId)
        {
            List<TeamInPrivilegeInfo> mList = new List<TeamInPrivilegeInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TeamInPrivilegePrivilegeMasterRows";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, ContentTypeId);
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new TeamInPrivilegeInfo
                        {
                            PrivilegeId = mCmd.GetFieldValue<Int32>("PrivilegeId"),
                            PrivilegeName = mCmd.GetFieldValue<String>("PrivilegeName"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<TeamInPrivilegeInfo> GetTeamInPrivilegeByTeamId(Int32 TeamId, Int32 LibId)
        {
            List<TeamInPrivilegeInfo> mList = new List<TeamInPrivilegeInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TeamInPrivilegeByTeamId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new TeamInPrivilegeInfo
                        {
                            PrivilegeId = mCmd.GetFieldValue<Int32>("PrivilegeId"),
                            PrivilegeName = mCmd.GetFieldValue<String>("PrivilegeName"),
                            Permission = mCmd.GetFieldValue<Int32>("Permission"),
                            ContentTypeId = mCmd.GetFieldValue<Int32>("ContentTypeId"),
                            Description = mCmd.GetFieldValue<String>("Description"),
                            IsBrandCategoryMapped = mCmd.GetFieldValue<Boolean>("IsBrandCategoryMapped"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public void InsertTeamInPrivilege(List<TeamInPrivilegeInfo> mInfo)
        {
            DataCommand mCmd = null;
            try
            {
                foreach (var uList in mInfo)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, uList.TeamId);
                    mCmd.AddParameter("@PrivilegeId", SqlDbType.VarChar, DataParameterDirection.Input, 100, uList.PrivilegeId);
                    mCmd.AddParameter("@Permission", SqlDbType.VarChar, DataParameterDirection.Input, 100, uList.Permission);
                    mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, uList.ContentTypeId);
                    mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, uList.LibId);
                    mCmd.AddParameter("@IsBrandCategoryMapped", SqlDbType.Bit, DataParameterDirection.Input, 1, uList.IsBrandCategoryMapped);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, uList.CreatedBy);
                    mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, uList.IPAddress);
                    mCmd.CommandText = "TeamInPrivilegeInsert";
                    mCmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
        }

        public List<TeamInPrivilegeInfo> GetTeamInPrivilegePrivilegeAllByTeamId(Int32 TeamId, Int32 LibId, Int32 ContentTypeId)
        {
            List<TeamInPrivilegeInfo> mList = new List<TeamInPrivilegeInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TeamInPrivilegePrivilegeAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, ContentTypeId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new TeamInPrivilegeInfo
                        {
                            PrivilegeId = mCmd.GetFieldValue<Int32>("PrivilegeId"),
                            PrivilegeName = mCmd.GetFieldValue<String>("PrivilegeName"),
                            Permission = mCmd.GetFieldValue<Int32>("Permission"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<ContentTypeInfo> GetContentTypeNotInTeamPrivilegeByLibId(Int32 TeamId,Int32 LibId)
        {
            List<ContentTypeInfo> mList = new List<ContentTypeInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "ContentTypeNotInTeamPrivilegeByLibId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new ContentTypeInfo
                        {
                            ContentTypeId = mCmd.GetFieldValue<Int32>("ContentTypeId"),
                            Description = mCmd.GetFieldValue<String>("Description"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
