﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAM.Apps.Utility
{
    public class ContentType
    {
        protected static ILog log = LogManager.GetLogger(typeof(ContentType));

        public List<ContentTypeInfo> GetContentTypeById(Int32 ContentTypeId)
        {
            List<ContentTypeInfo> mList = new List<ContentTypeInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "ContentTypeById";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, ContentTypeId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new ContentTypeInfo
                        {
                            ContentTypeId = mCmd.GetFieldValue<Int32>("ContentTypeId"),
                            LibId = mCmd.GetFieldValue<Int32>("LibId"),
                            Description = mCmd.GetFieldValue<String>("Description"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<ContentTypeInfo> GetContentTypeByLibId(Int32 LibId)
        {
            List<ContentTypeInfo> mList = new List<ContentTypeInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "ContentTypeByLibId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new ContentTypeInfo
                        {
                            ContentTypeId = mCmd.GetFieldValue<Int32>("ContentTypeId"),
                            LibId = mCmd.GetFieldValue<Int32>("LibId"),
                            Description = mCmd.GetFieldValue<String>("Description"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<ContentTypeInfo> GetContentTypeParticularRows(String Description)
        {
            List<ContentTypeInfo> mList = new List<ContentTypeInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "ContentTypeParticularRows";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@Description", SqlDbType.VarChar, DataParameterDirection.Input, 100, Description);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new ContentTypeInfo
                        {
                            Description = mCmd.GetFieldValue<String>("Description"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }


        public List<ContentTypeMasterInfo> GetContentTypeMaster()
        {
            List<ContentTypeMasterInfo> mList = new List<ContentTypeMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "ContentTypeMasterAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new ContentTypeMasterInfo
                        {
                            ContentTypeMasterId = mCmd.GetFieldValue<Int32>("ContentTypeMasterId"),
                            Description = mCmd.GetFieldValue<String>("Description"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
