﻿using System;

namespace DAM.Apps.Utility.Crypto
{
    public class Hasher
    {
        public String GetPasswordHash(String clearText)
        {
            String _ClearText = clearText.Trim();
            String _HashValue = String.Empty;
            try
            {
                _HashValue = EncryptMD5.GetHash(_ClearText);
            }
            catch
            {
                _HashValue = String.Empty;
            }
            return _HashValue.ToUpper();
        }
    }
}
