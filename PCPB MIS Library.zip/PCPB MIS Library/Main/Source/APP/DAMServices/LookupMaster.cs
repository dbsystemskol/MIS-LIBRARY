﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAM.Apps.Utility
{
    public class LookupMaster
    {
        protected static ILog log = LogManager.GetLogger(typeof(LookupMaster));

        public List<LookupMasterInfo> GetSelectAllActiveAttributeMasterLookupList()
        {
            List<LookupMasterInfo> mList = new List<LookupMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "AttributeFieldsLookupListSelectAllActive";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LookupMasterInfo
                        {
                            FieldId = mCmd.GetFieldValue<Int32>("FieldId"),
                            FieldName = mCmd.GetFieldValue<String>("FieldName"),
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                            FieldType = mCmd.GetFieldValue<String>("FieldType"),
                            LookupId = mCmd.GetFieldValue<Int32>("LookupId"),
                            FieldCode = mCmd.GetFieldValue<String>("FieldCode"),
                            FieldValue = mCmd.GetFieldValue<String>("FieldValue"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            LibId = mCmd.GetFieldValue<Int32>("LibId"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<LookupMasterInfo> GetLookupMasterByFieldId(Int32 FieldId, Int32 LibId)
        {
            List<LookupMasterInfo> mList = new List<LookupMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "LookupMasterByFieldId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@FieldId", SqlDbType.Int, DataParameterDirection.Input, 4, FieldId);
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LookupMasterInfo
                        {
                            LookupId = mCmd.GetFieldValue<Int32>("LookupId"),
                            FieldValue = mCmd.GetFieldValue<String>("FieldValue"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<LookupMasterInfo> GetAttributeMasterLookupListByFieldId(Int32 FieldId)
        {
            List<LookupMasterInfo> mList = new List<LookupMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "AttributeFieldsLookupList";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@FieldId", SqlDbType.Int, DataParameterDirection.Input, 4, FieldId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LookupMasterInfo
                        {
                            LookupId = mCmd.GetFieldValue<Int32>("LookupId"),
                            FieldCode = mCmd.GetFieldValue<String>("FieldCode"),
                            FieldValue = mCmd.GetFieldValue<String>("FieldValue"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<LookupMasterInfo> GetLookupMasterByLookupId(Int32 LookupId)
        {
            List<LookupMasterInfo> mList = new List<LookupMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "LookupMasterSelectRow";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@LookupId", SqlDbType.Int, DataParameterDirection.Input, 4, LookupId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LookupMasterInfo
                        {
                            LookupId = mCmd.GetFieldValue<Int32>("LookupId"),
                            FieldId = mCmd.GetFieldValue<Int32>("FieldId"),
                            FieldCode = mCmd.GetFieldValue<String>("FieldCode"),
                            FieldValue = mCmd.GetFieldValue<String>("FieldValue"),
                            LibId = mCmd.GetFieldValue<Int32>("LibId"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 InsertLookupMaster(LookupMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "LookupMasterInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@FieldId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.FieldId);
            mCmd.AddParameter("@FieldCode", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.FieldCode);
            mCmd.AddParameter("@FieldValue", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.FieldValue);
            mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.LibId);
            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.CreatedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 UpdateLookupMaster(LookupMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "LookupMasterUpdate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@LookupId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.LookupId);
            mCmd.AddParameter("@FieldId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.FieldId);
            mCmd.AddParameter("@FieldCode", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.FieldCode);
            mCmd.AddParameter("@FieldValue", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.FieldValue);
            mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.LibId);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 ActivateDeactivateLookupMaster(LookupMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "LookupMasterActivateDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@LookupId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.LookupId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 ActivateDeactivateLookupMasterAll(LookupMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "LookupMasterActivateDeactivateAll";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            //mCmd.AddParameter("@LookupId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.LookupId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<LookupMasterInfo> GetSelectAttributeMasterLookupSearch(String SearchString)
        {
            List<LookupMasterInfo> mList = new List<LookupMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "AttributeFieldsLookupListSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@SearchString", SqlDbType.VarChar, DataParameterDirection.Input, 100, SearchString);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LookupMasterInfo
                        {
                            FieldId = mCmd.GetFieldValue<Int32>("FieldId"),
                            FieldName = mCmd.GetFieldValue<String>("FieldName"),
                            FieldType = mCmd.GetFieldValue<String>("FieldType"),
                            LookupId = mCmd.GetFieldValue<Int32>("LookupId"),
                            FieldCode = mCmd.GetFieldValue<String>("FieldCode"),
                            FieldValue = mCmd.GetFieldValue<String>("FieldValue"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            LibId = mCmd.GetFieldValue<Int32>("LibId"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<LookupMasterInfo> GetAllOthersValue()
        {
            List<LookupMasterInfo> mList = new List<LookupMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GetAllOthersValue";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LookupMasterInfo
                        {
                            FieldId = mCmd.GetFieldValue<Int32>("FieldId"),
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                            FieldValue = mCmd.GetFieldValue<String>("FieldValue"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public void InsertLookupMasterOther(List<LookupMasterInfo> mInfo)
        {
            DataCommand mCmd = null;
            try
            {
                foreach (var uList in mInfo)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandText = "LookupMasterInsertOther";
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@FieldId", SqlDbType.Int, DataParameterDirection.Input, 4, uList.FieldId);            
                    mCmd.AddParameter("@FieldValue", SqlDbType.VarChar, DataParameterDirection.Input, 100, uList.FieldValue);
                    mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, uList.LibId);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, uList.CreatedBy);
                    mCmd.ExecuteNonQuery();
                    mCmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
        }

        public List<LookupMasterInfo> GetUserBrandCategoryByFieldId(Int32 FieldId, Int32 UserId)
        {
            List<LookupMasterInfo> mList = new List<LookupMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "UserBrandCategoryByFieldId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@FieldId", SqlDbType.Int, DataParameterDirection.Input, 4, FieldId);
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new LookupMasterInfo
                        {
                            LookupId = mCmd.GetFieldValue<Int32>("LookupId"),
                            FieldValue = mCmd.GetFieldValue<String>("FieldValue"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
