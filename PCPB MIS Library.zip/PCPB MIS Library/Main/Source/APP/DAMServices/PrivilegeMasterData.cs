﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using System.Data;
using DAMServices;

namespace DAM.Apps.Utility
{
    public class PrivilegeMasterData
    {
        protected static ILog log = LogManager.GetLogger(typeof(PrivilegeMasterData));

        public List<PrivilegeMasterInfo> GetAllPrivilegeMaster()
        {
            List<PrivilegeMasterInfo> mList = new List<PrivilegeMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "PrivilegeMasterSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new PrivilegeMasterInfo
                        {
                            PrivilegeId = mCmd.GetFieldValue<Int32>("PrivilegeId"),
                            PrivilegeName = mCmd.GetFieldValue<String>("PrivilegeName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<PrivilegeMasterInfo> GetPrivilegeMasterById(Int32 PrivilegeId)
        {
            List<PrivilegeMasterInfo> mList = new List<PrivilegeMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "PrivilegeMasterById";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@PrivilegeId", SqlDbType.Int, DataParameterDirection.Input, 4, PrivilegeId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new PrivilegeMasterInfo
                        {
                            PrivilegeId = mCmd.GetFieldValue<Int32>("PrivilegeId"),
                            PrivilegeName = mCmd.GetFieldValue<String>("PrivilegeName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 InsertPrivilegeMaster(PrivilegeMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "PrivilegeMasterInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@PrivilegeName", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.PrivilegeName);
            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.CreatedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 UpdatePrivilegeMaster(PrivilegeMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "PrivilegeMasterUpdate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@PrivilegeId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.PrivilegeId);
            mCmd.AddParameter("@PrivilegeName", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.PrivilegeName);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.CreatedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<PrivilegeMasterInfo> GetAllActivePrivilegeMaster()
        {
            List<PrivilegeMasterInfo> mList = new List<PrivilegeMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "PrivilegeMasterSelectActiveAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;

                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new PrivilegeMasterInfo
                        {
                            PrivilegeId = mCmd.GetFieldValue<Int32>("PrivilegeId"),
                            PrivilegeName = mCmd.GetFieldValue<String>("PrivilegeName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 ActivateDeactivatePrivilegeMaster(PrivilegeMasterInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "PrivilegeMasterActivateDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@PrivilegeId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.PrivilegeId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<PrivilegeMasterInfo> SearchPrivilege(String SearchText)
        {
            List<PrivilegeMasterInfo> mList = new List<PrivilegeMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "PrivilegeMasterSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@PrivilegeName", SqlDbType.VarChar, DataParameterDirection.Input, 100, SearchText);
                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new PrivilegeMasterInfo
                        {
                            PrivilegeId = mCmd.GetFieldValue<Int32>("PrivilegeId"),
                            PrivilegeName = mCmd.GetFieldValue<String>("PrivilegeName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
