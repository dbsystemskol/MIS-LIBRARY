﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAM.Apps.Utility
{
    public class UserInGroup
    {
        protected static ILog log = LogManager.GetLogger(typeof(UserInGroup));

        public List<UserInGroupInfo> GetGroupMasterUserListByGroupId(Int32 GroupId)
        {
            List<UserInGroupInfo> mList = new List<UserInGroupInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GroupMasterUserList";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@GroupId", SqlDbType.Int, DataParameterDirection.Input, 4, GroupId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new UserInGroupInfo
                        {
                            UserGroupId = mCmd.GetFieldValue<Int32>("UserGroupId"),
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                            GroupId = mCmd.GetFieldValue<Int32>("GroupId"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<UserInGroupInfo> GetUserListNotInParticularGroup(Int32 GroupId)
        {
            List<UserInGroupInfo> mList = new List<UserInGroupInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "UserListNotInParticularGroup";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@GroupId", SqlDbType.Int, DataParameterDirection.Input, 4, GroupId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new UserInGroupInfo
                        {
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public void InsertUserInGroup(List<UserInGroupInfo> mInfo)
        {
            DataCommand mCmd = null;
            try
            {
                foreach (var uList in mInfo)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@UserId", SqlDbType.VarChar, DataParameterDirection.Input, 100, uList.UserId);
                    mCmd.AddParameter("@GroupId", SqlDbType.VarChar, DataParameterDirection.Input, 100, uList.GroupId);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, uList.CreatedBy);
                    mCmd.CommandText = "UserInGroupInsert";
                    mCmd.ExecuteNonQuery();
                    mCmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
        }

        public Int32 ActivateDeactivateUserInGroupMaster(UserInGroupInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "UserInGroupActivateDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@UserGroupId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.UserGroupId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<UserInGroupInfo> GetAllActiveGroupMasterUserList()
        {
            List<UserInGroupInfo> mList = new List<UserInGroupInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GroupMasterUserListSelectAllActive";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new UserInGroupInfo
                        {
                            UserGroupId = mCmd.GetFieldValue<Int32>("UserGroupId"),
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                            GroupId = mCmd.GetFieldValue<Int32>("GroupId"),
                            GroupName = mCmd.GetFieldValue<String>("GroupName"),
                            DefaultType = mCmd.GetFieldValue<Boolean>("DefaultType"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<UserInGroupInfo> GetAllUserInGroupSearch(String SearchText)
        {
            List<UserInGroupInfo> mList = new List<UserInGroupInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "UserInGroupListSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@SearchText", SqlDbType.VarChar, DataParameterDirection.Input, 100, SearchText);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new UserInGroupInfo
                        {
                            UserGroupId = mCmd.GetFieldValue<Int32>("UserGroupId"),
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            Name = mCmd.GetFieldValue<String>("Name"),
                            GroupId = mCmd.GetFieldValue<Int32>("GroupId"),
                            GroupName = mCmd.GetFieldValue<String>("GroupName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
