﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAM.Apps.Utility
{
    public class EventTrigger
    {
        protected static ILog log = LogManager.GetLogger(typeof(EventTrigger));

        public Int32 InsertEventTrigger(Int32 EventId,Int32 Duration, Int32 CreatedBy)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "EventTriggerInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@EventId", SqlDbType.Int, DataParameterDirection.Input, 4, EventId);
            mCmd.AddParameter("@Duration", SqlDbType.Int, DataParameterDirection.Input, 4, Duration);
            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, CreatedBy);
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 UpdateEventTrigger(Int32 EventTriggerId, Int32 EventId, Int32 Duration, Int32 ModifiedBy)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "EventMasterUpdate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@EventTriggerId", SqlDbType.Int, DataParameterDirection.Input, 4, EventTriggerId);
            mCmd.AddParameter("@EventId", SqlDbType.Int, DataParameterDirection.Input, 4, EventId);
            mCmd.AddParameter("@Duration", SqlDbType.Int, DataParameterDirection.Input, 4, Duration);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, ModifiedBy);
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<EventTriggerInfo> GetAllEventTrigger()
        {
            List<EventTriggerInfo> mList = new List<EventTriggerInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "EventMasterSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;

                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new EventTriggerInfo
                        {
                            EventTriggerId = mCmd.GetFieldValue<Int32>("EventTriggerId"),
                            EventId = mCmd.GetFieldValue<Int32>("EventId"),
                            EventName = mCmd.GetFieldValue<String>("EventName"),
                            Duration = mCmd.GetFieldValue<Int32>("Duration"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<EventTriggerInfo> GetAllActiveEventTrigger()
        {
            List<EventTriggerInfo> mList = new List<EventTriggerInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "EventTriggerSelectAllActive";
                mCmd.CommandType = DataCommandType.StoredProcedure;

                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new EventTriggerInfo
                        {
                            EventTriggerId = mCmd.GetFieldValue<Int32>("EventTriggerId"),
                            EventId = mCmd.GetFieldValue<Int32>("EventId"),
                            EventName = mCmd.GetFieldValue<String>("EventName"),
                            Duration = mCmd.GetFieldValue<Int32>("Duration"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<EventTriggerInfo> GetAllEventTriggerById(Int32 EventTriggerId)
        {
            List<EventTriggerInfo> mList = new List<EventTriggerInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "EventMasterSelectById";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@EventTriggerId", SqlDbType.Int, DataParameterDirection.Input, 4, EventTriggerId);
                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new EventTriggerInfo
                        {
                            EventTriggerId = mCmd.GetFieldValue<Int32>("EventTriggerId"),
                            EventId = mCmd.GetFieldValue<Int32>("EventId"),
                            EventName = mCmd.GetFieldValue<String>("EventName"),
                            Duration = mCmd.GetFieldValue<Int32>("Duration"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 ActivateDeactivateEventTrigger(Int32 EventTriggerId, Boolean IsActive, Int32 ModifiedBy)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "EventMasterActivateDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@EventTriggerId", SqlDbType.Int, DataParameterDirection.Input, 4, EventTriggerId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, ModifiedBy);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<EventTriggerInfo> SearchEventTrigger(String SearchText)
        {
            List<EventTriggerInfo> mList = new List<EventTriggerInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "EventMasterSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@SearchText", SqlDbType.VarChar, DataParameterDirection.Input, 200, SearchText);
                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new EventTriggerInfo
                        {
                            EventTriggerId = mCmd.GetFieldValue<Int32>("EventTriggerId"),
                            EventId = mCmd.GetFieldValue<Int32>("EventId"),
                            EventName = mCmd.GetFieldValue<String>("EventName"),
                            Duration = mCmd.GetFieldValue<Int32>("Duration"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
