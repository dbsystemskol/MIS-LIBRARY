﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAM.Apps.Utility
{
    public class DocomentMaster
    {
        protected static ILog log = LogManager.GetLogger(typeof(DocomentMaster));

        public Int32 DocumentInfoDetailUpdate(List<DocumentDetailInfo> mList)
        {
            Int32 _ReturnValue = 0;
            Int32 returnvalues = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            try
            {
                foreach (DocumentDetailInfo item in mList)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandText = "DocumentInfoDetailUpdate";
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, item.DocId);
                    mCmd.AddParameter("@FieldId", SqlDbType.Int, DataParameterDirection.Input, 4, item.FieldId);
                    if (item.LoopupId > 0)
                        mCmd.AddParameter("@LoopupId", SqlDbType.Int, DataParameterDirection.Input, 4, item.LoopupId);
                    else
                        mCmd.AddParameter("@LoopupId", SqlDbType.Int, DataParameterDirection.Input, 4, null);
                    mCmd.AddParameter("@FieldValue", SqlDbType.VarChar, DataParameterDirection.Input, 100, item.FieldValue);
                    mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, item.ModifiedBy);
                    mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, item.IPAddress);
                    mCmd.ExecuteNonQuery();
                    returnvalues = returnvalues + mCmd.GetParameterValue<Int32>("@ReturnValue");
                    mCmd.Dispose();
                }
                _ReturnValue = returnvalues;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 UpdateDocomentInfoMaster(Int32 DocId, String Keywords, Int32 ModifiedBy, String IPAddress)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "DocomentInfoMasterUpdate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
            mCmd.AddParameter("@Keywords", SqlDbType.VarChar, DataParameterDirection.Input, 4000, Keywords);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, ModifiedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<DocomentMasterInfo> GetContentTypeIdByDocId(Int32 DocId)
        {
            List<DocomentMasterInfo> mList = new List<DocomentMasterInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GetContentTypeIdByDocId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new DocomentMasterInfo
                        {
                            ContentTypeId = mCmd.GetFieldValue<Int32>("ContentTypeId"),
                            ContentType = mCmd.GetFieldValue<String>("ContentType"),
                            SerialNo = mCmd.GetFieldValue<Int64>("SerialNo"),
                            UserName = mCmd.GetFieldValue<String>("UserName"),
                            CreatedBy = mCmd.GetFieldValue<Int32>("CreatedBy"),
                            CreatedOn = mCmd.GetFieldValue<DateTime>("CreatedOn"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<DocSerialNoInfo> GetNextSerialNoByLibId(Int32 LibId)
        {
            List<DocSerialNoInfo> mList = new List<DocSerialNoInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GetNextSerialNoByLibId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new DocSerialNoInfo
                        {
                            NextSerialNo = mCmd.GetFieldValue<Int64>("NextSerialNo"),
                            
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<DocumentDetailInfo> GetUpdatedDocumentDetails(Int32 DocId)
        {
            List<DocumentDetailInfo> mList = new List<DocumentDetailInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "GetUpdatedDocumentDetails";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new DocumentDetailInfo
                        {
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                            FieldValue = mCmd.GetFieldValue<String>("FieldValue"),

                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 UpdateDocumentInfoDetailClone(Int32 DocId)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "UpdateDocumentInfoDetailClone";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<DocLogDetailsInfo> DocLogDetailsSearch(String FromDate, String ToDate)
        {
            List<DocLogDetailsInfo> mList = new List<DocLogDetailsInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "DocLogDetailsSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                if (FromDate != "")
                    mCmd.AddParameter("@FromDate", SqlDbType.VarChar, DataParameterDirection.Input, 10, FromDate);
                else
                    mCmd.AddParameter("@FromDate", SqlDbType.VarChar, DataParameterDirection.Input, 10, null);
                if (ToDate != "")
                    mCmd.AddParameter("@ToDate", SqlDbType.VarChar, DataParameterDirection.Input, 10, ToDate);
                else
                    mCmd.AddParameter("@ToDate", SqlDbType.VarChar, DataParameterDirection.Input, 10, null);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new DocLogDetailsInfo
                        {
                            DocNo = mCmd.GetFieldValue<Int32>("DocNo"),
                            //Title = mCmd.GetFieldValue<String>("Title"),
                            ChangeField = mCmd.GetFieldValue<String>("ChangeField"),
                            FieldName = mCmd.GetFieldValue<String>("FieldName"),
                            ValueBefore = mCmd.GetFieldValue<String>("ValueBefore"),
                            ValueAfter = mCmd.GetFieldValue<String>("ValueAfter"),
                            ChangedById = mCmd.GetFieldValue<String>("ChangedById"),
                            ChangedByName = mCmd.GetFieldValue<String>("ChangedByName"),
                            ChangedOn = mCmd.GetFieldValue<DateTime>("ChangedOn"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
