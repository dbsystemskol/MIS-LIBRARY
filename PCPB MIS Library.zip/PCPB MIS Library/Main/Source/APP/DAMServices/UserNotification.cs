﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;
using System.Data.SqlClient;

namespace DAM.Apps.Utility
{
    public class UserNotification
    {
        protected static ILog log = LogManager.GetLogger(typeof(UserNotification));

        public List<UserNotificationInfo> GetUserNotification(Int32 TeamId, Int32 VisiterUserId, Int32 LibId)
        {
            List<UserNotificationInfo> mList = new List<UserNotificationInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "UserNotificationSelect";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                mCmd.AddParameter("@VisiterUserId", SqlDbType.Int, DataParameterDirection.Input, 4, VisiterUserId);
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new UserNotificationInfo
                        {
                            UserNotificationId = mCmd.GetFieldValue<Int64>("UserNotificationId"),
                            UserId = mCmd.GetFieldValue<Int32>("UserId"),
                            TeamId = mCmd.GetFieldValue<Int32>("TeamId"),
                            DocId = mCmd.GetFieldValue<Int32>("DocId"),
                            LibId = mCmd.GetFieldValue<Int32>("LibId"),
                            NotificationType = mCmd.GetFieldValue<String>("NotificationType"),
                            VisiterUserId = mCmd.GetFieldValue<Int32>("VisiterUserId"),
                            IsVisited = mCmd.GetFieldValue<Boolean>("IsVisited"),
                            ActivityDate = mCmd.GetFieldValue<DateTime>("ActivityDate"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 InsertUserNotification(Int32 UserId, Int32 TeamId,Int32 DocId,Int32 LibId,String NotificationType)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "UserNotificationInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
            mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
            mCmd.AddParameter("@DocId", SqlDbType.Int, DataParameterDirection.Input, 4, DocId);
            mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
            mCmd.AddParameter("@NotificationType", SqlDbType.VarChar, DataParameterDirection.Input, 200, NotificationType);            
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 UpdateUserNotification(Int32 UserId, Int32 TeamId, Int32 LibId, String NotificationType)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "UserNotificationUpdate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
            mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
            mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
            mCmd.AddParameter("@NotificationType", SqlDbType.VarChar, DataParameterDirection.Input, 200, NotificationType);
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public DataTable UserNotificationList(Int32 LibId, Int32 UserId, String NotificationType)
        {
            SqlDataReader mList;
            DataTable dt = new DataTable();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "UserNotificationList";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
                mCmd.AddParameter("@NotificationType", SqlDbType.VarChar, DataParameterDirection.Input, 200, NotificationType);
                // execute
                try
                {
                    mList = mCmd.ExecuteReaderWithSqlReader();
                    dt.Load(mList);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return dt;
        }
    }
}
