﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAM.Apps.Utility
{
    public class TemplateFieldMapping
    {
        protected static ILog log = LogManager.GetLogger(typeof(TemplateFieldMapping));

        public List<TemplateFieldMappingInfo> GetAllTemplateFieldMapping()
        {
            List<TemplateFieldMappingInfo> mList = new List<TemplateFieldMappingInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "TemplateFieldMappingSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new TemplateFieldMappingInfo
                        {
                            TemplateFieldId = mCmd.GetFieldValue<Int32>("TemplateFieldId"),
                            TemplateField = mCmd.GetFieldValue<String>("TemplateField"),
                            FieldId = mCmd.GetFieldValue<Int32>("FieldId"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
