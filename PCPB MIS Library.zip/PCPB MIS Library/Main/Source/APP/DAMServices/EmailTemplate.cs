﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAM.Apps.Utility
{
    public class EmailTemplate
    {
        protected static ILog log = LogManager.GetLogger(typeof(EmailTemplate));

        public Int32 InsertEmailTemplate(String TemplateName, String Subject, String Body)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "EmailTemplateInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@TemplateName", SqlDbType.VarChar, DataParameterDirection.Input, 200, TemplateName);
            mCmd.AddParameter("@Subject", SqlDbType.VarChar, DataParameterDirection.Input, 4000, Subject);
            mCmd.AddParameter("@Body", SqlDbType.VarChar, DataParameterDirection.Input, 4000, Body);
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 UpdateEmailTemplate(Int32 TemplateId, String TemplateName, String Subject, String Body)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "EmailTemplateUpdate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@TemplateId", SqlDbType.Int, DataParameterDirection.Input, 4, TemplateId);
            mCmd.AddParameter("@TemplateName", SqlDbType.VarChar, DataParameterDirection.Input, 200, TemplateName);
            mCmd.AddParameter("@Subject", SqlDbType.VarChar, DataParameterDirection.Input, 4000, Subject);
            mCmd.AddParameter("@Body", SqlDbType.VarChar, DataParameterDirection.Input, 4000, Body);
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<EmailTemplateInfo> GetAllEmailTemplate()
        {
            List<EmailTemplateInfo> mList = new List<EmailTemplateInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "EmailTemplateSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;

                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new EmailTemplateInfo
                        {
                            TemplateId = mCmd.GetFieldValue<Int32>("TemplateId"),
                            TemplateName = mCmd.GetFieldValue<String>("TemplateName"),
                            Subject = mCmd.GetFieldValue<String>("Subject"),
                            Body = mCmd.GetFieldValue<String>("Body"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<EmailTemplateInfo> GetAllEmailTemplateById(Int32 TemplateId)
        {
            List<EmailTemplateInfo> mList = new List<EmailTemplateInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "EmailTemplateSelectById";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@TemplateId", SqlDbType.Int, DataParameterDirection.Input, 4, TemplateId);
                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new EmailTemplateInfo
                        {
                            TemplateId = mCmd.GetFieldValue<Int32>("TemplateId"),
                            TemplateName = mCmd.GetFieldValue<String>("TemplateName"),
                            Subject = mCmd.GetFieldValue<String>("Subject"),
                            Body = mCmd.GetFieldValue<String>("Body"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }
    }
}
