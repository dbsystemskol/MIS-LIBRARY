﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAM.Apps.Utility
{
    public class SaveSearch
    {
        protected static ILog log = LogManager.GetLogger(typeof(SaveSearch));

        public Int32 InsertSaveSearch(SaveSearchInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "SaveSearchInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.UserId);
            mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.LibId);
            mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.TeamId);
            mCmd.AddParameter("@WhereText", SqlDbType.VarChar, DataParameterDirection.Input, 4000, mData.WhereText);
            mCmd.AddParameter("@SearchText", SqlDbType.VarChar, DataParameterDirection.Input, 4000, mData.SearchText);
            mCmd.AddParameter("@BindText", SqlDbType.VarChar, DataParameterDirection.Input, 4000, mData.BindText);
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<SaveSearchInfo> GetSaveSearch(Int32 UserId, Int32 LibId, Int32 TeamId)
        {
            List<SaveSearchInfo> mList = new List<SaveSearchInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "SaveSearchSelect";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@UserId", SqlDbType.Int, DataParameterDirection.Input, 4, UserId);
                mCmd.AddParameter("@LibId", SqlDbType.Int, DataParameterDirection.Input, 4, LibId);
                mCmd.AddParameter("@TeamId", SqlDbType.Int, DataParameterDirection.Input, 4, TeamId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new SaveSearchInfo
                        {
                            SaveSearchId = mCmd.GetFieldValue<Int32>("SaveSearchId"),
                            SearchText = mCmd.GetFieldValue<String>("SearchText"),
                            WhereText = mCmd.GetFieldValue<String>("WhereText"),
                            BindText = mCmd.GetFieldValue<String>("BindText"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 DeleteSaveSearch(Int32 SaveSearchId)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "SaveSearchDelete";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@SaveSearchId", SqlDbType.Int, DataParameterDirection.Input, 4, SaveSearchId);
            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }
    }
}
