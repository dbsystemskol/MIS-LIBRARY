﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DAMServices;
using log4net;
using log4net.Config;

namespace DAM.Apps.Utility
{
    public class FileExtensionMaster
    {
        protected static ILog log = LogManager.GetLogger(typeof(FileExtensionMaster));
        public List<FileExtensionInfo> GetAllFileExtension()
        {
            List<FileExtensionInfo> mList = new List<FileExtensionInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "FileExtensionMasterSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;

                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new FileExtensionInfo
                        {
                            FileExtensionId = mCmd.GetFieldValue<Int32>("FileExtensionId"),
                            FileExtension = mCmd.GetFieldValue<String>("FileExtension"),
                            Description = mCmd.GetFieldValue<String>("Description"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            CreatedOn = mCmd.GetFieldValue<DateTime>("CreatedOn"),
                            CreatedBy = mCmd.GetFieldValue<Int32>("CreatedBy"),
                            //ModifiedBy = mCmd.GetFieldValue<Int32>("ModifiedBy"),
                            //ModifiedOn = mCmd.GetFieldValue<DateTime>("ModifiedOn"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<FileExtensionInfo> GetPreviewImageByFileExtension(String FileExtension)
        {
            List<FileExtensionInfo> mList = new List<FileExtensionInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.AddParameter("@FileExtension", SqlDbType.VarChar, DataParameterDirection.Input, 10, FileExtension);
                mCmd.CommandText = "GetPreviewImageByFileExtension";
                mCmd.CommandType = DataCommandType.StoredProcedure;

                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new FileExtensionInfo
                        {
                            PreviewImage = mCmd.GetFieldValue<String>("Description"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<FileExtensionInfo> FileExtensionByExtension(String Extension)
        {
            List<FileExtensionInfo> mList = new List<FileExtensionInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "FileExtensionMasterByExtension";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@FileExtension", SqlDbType.VarChar, DataParameterDirection.Input, 100, Extension);
                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new FileExtensionInfo
                        {
                            FileExtensionId = mCmd.GetFieldValue<Int32>("FileExtensionId"),
                            FileExtension = mCmd.GetFieldValue<String>("FileExtension"),
                            Description = mCmd.GetFieldValue<String>("Description"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            CreatedOn = mCmd.GetFieldValue<DateTime>("CreatedOn"),
                            CreatedBy = mCmd.GetFieldValue<Int32>("CreatedBy"),
                            PreviewImage = mCmd.GetFieldValue<String>("PreviewImage"),
                            //ModifiedBy = mCmd.GetFieldValue<Int32>("ModifiedBy"),
                            //ModifiedOn = mCmd.GetFieldValue<DateTime>("ModifiedOn"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<FileExtensionInfo> GetFileExtensionMasterById(Int32 FileExtensionId)
        {
            List<FileExtensionInfo> mList = new List<FileExtensionInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "FileExtensionMasterSelectById";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@FileExtensionId", SqlDbType.Int, DataParameterDirection.Input, 4, FileExtensionId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new FileExtensionInfo
                        {
                            FileExtensionId = mCmd.GetFieldValue<Int32>("FileExtensionId"),
                            FileExtension = mCmd.GetFieldValue<String>("FileExtension"),
                            Description = mCmd.GetFieldValue<String>("Description"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            CreatedOn = mCmd.GetFieldValue<DateTime>("CreatedOn"),
                            CreatedBy = mCmd.GetFieldValue<Int32>("CreatedBy"),
                            PreviewImage = mCmd.GetFieldValue<String>("PreviewImage"),
                            //ModifiedBy = mCmd.GetFieldValue<Int32>("ModifiedBy"),
                            //ModifiedOn = mCmd.GetFieldValue<DateTime>("ModifiedOn"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 InsertFileExtensionMaster(FileExtensionInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "FileExtensionMasterInsert";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@FileExtension", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.FileExtension);
            mCmd.AddParameter("@Description", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.Description);
            mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.CreatedBy);
            mCmd.AddParameter("@PreviewImage", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.PreviewImage);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public Int32 UpdateFileExtensionMaster(FileExtensionInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "FileExtensionMasterUpdate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@FileExtensionId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.FileExtensionId);
            mCmd.AddParameter("@FileExtension", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.FileExtension);
            mCmd.AddParameter("@Description", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.Description);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);
            mCmd.AddParameter("@PreviewImage", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.PreviewImage);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }

        public List<FileExtensionInfo> GetAllActiveFileExtensionMaster()
        {
            List<FileExtensionInfo> mList = new List<FileExtensionInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "FileExtensionMasterSelectActiveAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;

                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new FileExtensionInfo
                        {
                            FileExtensionId = mCmd.GetFieldValue<Int32>("FileExtensionId"),
                            FileExtension = mCmd.GetFieldValue<String>("FileExtension"),
                            Description = mCmd.GetFieldValue<String>("Description"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            CreatedOn = mCmd.GetFieldValue<DateTime>("CreatedOn"),
                            CreatedBy = mCmd.GetFieldValue<Int32>("CreatedBy"),
                            //ModifiedBy = mCmd.GetFieldValue<Int32>("ModifiedBy"),
                            //ModifiedOn = mCmd.GetFieldValue<DateTime>("ModifiedOn"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<FileExtensionInfo> SearchFileExtension(String SearchText)
        {
            List<FileExtensionInfo> mList = new List<FileExtensionInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "FileExtensionMasterSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@FileExtension", SqlDbType.VarChar, DataParameterDirection.Input, 100, SearchText);
                // execute
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new FileExtensionInfo
                        {
                            FileExtensionId = mCmd.GetFieldValue<Int32>("FileExtensionId"),
                            FileExtension = mCmd.GetFieldValue<String>("FileExtension"),
                            Description = mCmd.GetFieldValue<String>("Description"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            CreatedOn = mCmd.GetFieldValue<DateTime>("CreatedOn"),
                            CreatedBy = mCmd.GetFieldValue<Int32>("CreatedBy"),
                            //ModifiedBy = mCmd.GetFieldValue<Int32>("ModifiedBy"),
                            //ModifiedOn = mCmd.GetFieldValue<DateTime>("ModifiedOn"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 ActivateDeactivateFileExtensionMaster(FileExtensionInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "FileExtensionMasterActivateDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@FileExtensionId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.FileExtensionId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);
            mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }
    }
}
