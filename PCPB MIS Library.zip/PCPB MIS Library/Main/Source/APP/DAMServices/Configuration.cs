﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;
using System.Data.SqlClient;
using DAM.Apps.Utility;

namespace DAMServices
{
    public class Configuration
    {
        protected static ILog log = LogManager.GetLogger(typeof(Configuration));

        public List<ConfigurationInfo> GetAllConfiguration()
        {
            List<ConfigurationInfo> mList = new List<ConfigurationInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "ConfigurationMasterSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new ConfigurationInfo
                        {
                            ConfigurationId = mCmd.GetFieldValue<Int32>("ConfigurationId"),
                            ConfigurationName = mCmd.GetFieldValue<String>("ConfigurationName"),
                            ConfigurationAlias = mCmd.GetFieldValue<String>("ConfigurationAlias"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 ActivateDeactivateConfiguration(ConfigurationInfo mData)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "ConfigurationMasterActivateDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@ConfigurationId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ConfigurationId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.IsActive);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }
    }
}