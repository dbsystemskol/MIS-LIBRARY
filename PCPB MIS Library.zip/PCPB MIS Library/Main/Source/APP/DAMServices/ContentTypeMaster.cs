﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAM.Apps.Utility
{
  public class ContentTypeMaster
    {

      protected static ILog log = LogManager.GetLogger(typeof(ContentTypeMaster));

      public List<ContentTypeMasterInfo> GetAllContentType()
      {
          List<ContentTypeMasterInfo> mList = new List<ContentTypeMasterInfo>();
          using (DataCommand mCmd = new DataCommand())
          {
              mCmd.CommandText = "ContentTypeSelectAll";
              mCmd.CommandType = DataCommandType.StoredProcedure;
              try
              {
                  mCmd.ExecuteReader();
                  while (mCmd.ReadNext())
                  {
                      mList.Add(new ContentTypeMasterInfo
                      {
                          ContentTypeMasterId = mCmd.GetFieldValue<Int32>("ContentTypeMasterId"),
                          Description = mCmd.GetFieldValue<String>("Description"),
                          IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                      });
                  }
              }
              catch (Exception ex)
              {
                  throw ex;
              }
          }
          return mList;
      }

      public List<ContentTypeMasterInfo> SearchContent(String SearchText)
      {
          List<ContentTypeMasterInfo> mList = new List<ContentTypeMasterInfo>();
          using (DataCommand mCmd = new DataCommand())
          {
              mCmd.CommandText = "ContentTypeSearch";
              mCmd.CommandType = DataCommandType.StoredProcedure;
              mCmd.AddParameter("@ContentType", SqlDbType.VarChar, DataParameterDirection.Input, 100, SearchText);
           
              try
              {
                  mCmd.ExecuteReader();
                  while (mCmd.ReadNext())
                  {
                      mList.Add(new ContentTypeMasterInfo
                      {
                          ContentTypeMasterId = mCmd.GetFieldValue<Int32>("ContentTypeMasterId"),
                          Description = mCmd.GetFieldValue<String>("Description"),
                          IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                      });
                  }
              }
              catch (Exception ex)
              {
                  throw ex;
              }
          }
          return mList;
      }

      public Int32 InsertContentType(ContentTypeMasterInfo mData)
      {
          Int32 _ReturnValue = 0;
          DataCommand mCmd = null;
          try
          {
              mCmd = new DataCommand();
          }
          catch (Exception ex)
          {
              throw ex;
          }
          mCmd.CommandText = "ContentTypeMasterInsert";
          mCmd.CommandType = DataCommandType.StoredProcedure;
          mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
          mCmd.AddParameter("@Description", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.Description);
          mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.CreatedBy);
          mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

          try
          {
              mCmd.ExecuteNonQuery();
              _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
          }
          catch (Exception ex)
          {
              throw ex;
          }
          finally
          {
              mCmd.Dispose();
              mCmd = null;
          }
          return _ReturnValue;
      }

      public Int32 UpdateContentType(ContentTypeMasterInfo mData)
      {
          Int32 _ReturnValue = 0;
          DataCommand mCmd = null;
          try
          {
              mCmd = new DataCommand();
          }
          catch (Exception ex)
          {
              throw ex;
          }
          mCmd.CommandText = "ContentTypeUpdate";
          mCmd.CommandType = DataCommandType.StoredProcedure;
          mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
          mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ContentTypeMasterId);
          mCmd.AddParameter("@Description", SqlDbType.VarChar, DataParameterDirection.Input, 100, mData.Description);
          mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.CreatedBy);
          mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

          try
          {
              mCmd.ExecuteNonQuery();
              _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
          }
          catch (Exception ex)
          {
              throw ex;
          }
          finally
          {
              mCmd.Dispose();
              mCmd = null;
          }
          return _ReturnValue;
      }

      public List<ContentTypeMasterInfo> GetContentTypeById(Int32 ContentTypeID)
      {
          List<ContentTypeMasterInfo> mList = new List<ContentTypeMasterInfo>();
          using (DataCommand mCmd = new DataCommand())
          {
              mCmd.CommandText = "ContentTypeMasterById";
              mCmd.CommandType = DataCommandType.StoredProcedure;
              mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, ContentTypeID);
              try
              {
                  mCmd.ExecuteReader();
                  while (mCmd.ReadNext())
                  {
                      mList.Add(new ContentTypeMasterInfo
                      {
                          ContentTypeMasterId = mCmd.GetFieldValue<Int32>("ContentTypeMasterId"),
                          Description = mCmd.GetFieldValue<String>("Description"),
                          IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                      });
                  }
              }
              catch (Exception ex)
              {
                  throw ex;
              }
          }
          return mList;
      }

      public Int32 ActivateDeactivateContentType(ContentTypeMasterInfo mData)
      {
          Int32 _ReturnValue = 0;
          DataCommand mCmd = null;
          try
          {
              mCmd = new DataCommand();
          }
          catch (Exception ex)
          {
              throw ex;
          }
          mCmd.CommandText = "ContentTypeMasterActivateDeactivate";
          mCmd.CommandType = DataCommandType.StoredProcedure;
          mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
          mCmd.AddParameter("@ContentTypeId", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ContentTypeMasterId);
          mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, mData.IsActive);
          mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, mData.ModifiedBy);
          mCmd.AddParameter("@IPAddress", SqlDbType.VarChar, DataParameterDirection.Input, 20, mData.IPAddress);

          try
          {
              mCmd.ExecuteNonQuery();
              _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
          }
          catch (Exception ex)
          {
              throw ex;
          }
          finally
          {
              mCmd.Dispose();
              mCmd = null;
          }
          return _ReturnValue;
      }

    }
}
