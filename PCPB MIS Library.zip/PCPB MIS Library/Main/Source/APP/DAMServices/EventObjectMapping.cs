﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using DAMServices;
using System.Data;

namespace DAM.Apps.Utility
{
    public class EventObjectMapping
    {
        protected static ILog log = LogManager.GetLogger(typeof(EventInTemplate));

        public void InsertEventObjectMapping(List<EventObjectMappingInfo> mInfo)
        {
            DataCommand mCmd = null;
            try
            {
                foreach (var uList in mInfo)
                {
                    mCmd = null;
                    mCmd = new DataCommand();
                    mCmd.CommandType = DataCommandType.StoredProcedure;
                    mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
                    mCmd.AddParameter("@EventId", SqlDbType.Int, DataParameterDirection.Input, 4, uList.EventId);
                    mCmd.AddParameter("@FieldId", SqlDbType.Int, DataParameterDirection.Input, 100, uList.FieldId);
                    mCmd.AddParameter("@CreatedBy", SqlDbType.Int, DataParameterDirection.Input, 4, uList.CreatedBy);
                    mCmd.CommandText = "EventObjectMappingInsert";
                    mCmd.ExecuteNonQuery();
                    mCmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
        }

        public List<EventObjectMappingInfo> GetAllActiveEventObjectMapping()
        {
            List<EventObjectMappingInfo> mList = new List<EventObjectMappingInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "EventObjectMappingSelectAllActive";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new EventObjectMappingInfo
                        {
                            EventObjectId = mCmd.GetFieldValue<Int32>("EventObjectId"),
                            EventName = mCmd.GetFieldValue<String>("EventName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<EventObjectMappingInfo> GetEventObjectMappingByEventId(Int32 EventId)
        {
            List<EventObjectMappingInfo> mList = new List<EventObjectMappingInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "EventObjectMappingByEventId";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@EventId", SqlDbType.Int, DataParameterDirection.Input, 4, EventId);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new EventObjectMappingInfo
                        {
                            FieldId = mCmd.GetFieldValue<Int32>("FieldId"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                            FieldType = mCmd.GetFieldValue<String>("FieldType"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<EventObjectMappingInfo> GetAllEventObjectMapping()
        {
            List<EventObjectMappingInfo> mList = new List<EventObjectMappingInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "EventObjectMappingSelectAll";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new EventObjectMappingInfo
                        {
                            EventObjectId = mCmd.GetFieldValue<Int32>("EventObjectId"),
                            EventName = mCmd.GetFieldValue<String>("EventName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public List<EventObjectMappingInfo> GetEventObjectMappingSearch(String SearchString)
        {
            List<EventObjectMappingInfo> mList = new List<EventObjectMappingInfo>();
            using (DataCommand mCmd = new DataCommand())
            {
                mCmd.CommandText = "EventObjectMappingSearch";
                mCmd.CommandType = DataCommandType.StoredProcedure;
                mCmd.AddParameter("@SearchString", SqlDbType.VarChar, DataParameterDirection.Input, 100, SearchString);
                try
                {
                    mCmd.ExecuteReader();
                    while (mCmd.ReadNext())
                    {
                        mList.Add(new EventObjectMappingInfo
                        {
                            EventObjectId = mCmd.GetFieldValue<Int32>("EventObjectId"),
                            EventName = mCmd.GetFieldValue<String>("EventName"),
                            IsActive = mCmd.GetFieldValue<Boolean>("IsActive"),
                            FieldCaption = mCmd.GetFieldValue<String>("FieldCaption"),
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return mList;
        }

        public Int32 ActivateDeactivateEventObjectMapping(Int32 EventObjectId, Boolean IsActive, Int32 ModifiedBy)
        {
            Int32 _ReturnValue = 0;
            DataCommand mCmd = null;
            try
            {
                mCmd = new DataCommand();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            mCmd.CommandText = "EventObjectMappingActivateDeactivate";
            mCmd.CommandType = DataCommandType.StoredProcedure;
            mCmd.AddParameter("@ReturnValue", SqlDbType.Int, DataParameterDirection.ReturnValue, 4, 5, 0);
            mCmd.AddParameter("@EventObjectId", SqlDbType.Int, DataParameterDirection.Input, 4, EventObjectId);
            mCmd.AddParameter("@IsActive", SqlDbType.Bit, DataParameterDirection.Input, 1, IsActive);
            mCmd.AddParameter("@ModifiedBy", SqlDbType.Int, DataParameterDirection.Input, 4, ModifiedBy);

            try
            {
                mCmd.ExecuteNonQuery();
                _ReturnValue = mCmd.GetParameterValue<Int16>("@ReturnValue");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mCmd.Dispose();
                mCmd = null;
            }
            return _ReturnValue;
        }
    }
}
