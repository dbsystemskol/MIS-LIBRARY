
delete from ActivityLog
dbcc checkident(ActivityLog,reseed,0)

delete from UserLoginHistory
dbcc checkident(UserLoginHistory,reseed,0)

delete from UserNotification
dbcc checkident(UserNotification,reseed,0)

delete from FavouriteDocument
dbcc checkident(FavouriteDocument,reseed,0)

delete from DocLogDetails
dbcc checkident(DocLogDetails,reseed,0)

delete from DocumentInFile
dbcc checkident(DocumentInFile,reseed,0)

delete from DocumentInfoDetailClone
dbcc checkident(DocumentInfoDetailClone,reseed,0)

delete from DocumentInGroup
dbcc checkident(DocumentInGroup,reseed,0)

delete from FileLinkDetail
dbcc checkident(FileLinkDetail,reseed,0)

delete from FileVersion
dbcc checkident(FileVersion,reseed,0)

delete from DocumentInfoDetail
dbcc checkident(DocumentInfoDetail,reseed,0)

delete from DocomentInfoMaster
dbcc checkident(DocomentInfoMaster,reseed,0)


update DocSerialNo set NextSerialNo = 0





